(function(g) {
    var window = this;
    'use strict';
    var Zgb = function(a, b) {
            return b ? a.captionsInitialState : "CAPTIONS_INITIAL_STATE_UNKNOWN"
        },
        $gb = function(a) {
            return g.TM(a) ? g.AL(a.experiments, "web_player_caption_language_preference_stickiness_duration") : 0
        },
        ahb = function(a, b) {
            var c = new g.kN;
            c.languageCode = a.languageCode;
            c.languageName = a.languageName;
            c.name = a.name;
            c.kind = a.kind;
            c.isDefault = !1;
            c.j = a.j;
            c.isTranslateable = a.isTranslateable;
            c.vssId = a.vssId;
            c.url = a.url;
            c.translationLanguage = b;
            a.xtags && (c.xtags = a.xtags);
            a.captionId && (c.captionId = a.captionId);
            return c
        },
        bhb = function(a, b) {
            var c, d, e;
            return g.Ga(function(f) {
                if (1 == f.j) return c = a + "|" + b, g.z(f, g.LC(), 2);
                if (3 != f.j) {
                    d = f.u;
                    if (!d) throw g.$B("gct");
                    return g.z(f, g.YN(d), 3)
                }
                e = f.u;
                return f.return(e.get("captions", c))
            })
        },
        chb = function(a, b, c) {
            bhb(a, b).then(function(d) {
                d && c(d.trackData, new g.kN(d.metadata))
            })
        },
        fhb = function(a) {
            if (!dhb.test(a)) throw Error("'" + a + "' is not a valid hex color");
            4 == a.length && (a = a.replace(ehb, "#$1$1$2$2$3$3"));
            a = a.toLowerCase();
            a = parseInt(a.slice(1), 16);
            return [a >> 16, a >> 8 & 255, a & 255]
        },
        ghb = function() {
            return g.mB("yt-player-caption-display-settings")
        },
        p5 = function() {
            this.segments = []
        },
        hhb = function(a, b) {
            var c = g.Ub(a.segments, b);
            0 <= c || 0 > c && 1 === (-c - 1) % 2 || (c = -c - 1, 0 < c && 1 === b - a.segments[c - 1] && c < a.segments.length && 1 === a.segments[c] - b ? (g.Ib(a.segments, c), g.Ib(a.segments, c - 1)) : 0 < c && 1 === b - a.segments[c - 1] ? a.segments[c - 1] = b : c < a.segments.length && 1 === a.segments[c] - b ? a.segments[c] = b : (g.Rb(a.segments, c, 0, b), g.Rb(a.segments, c + 1, 0, b)))
        },
        ihb = function(a, b, c, d, e, f) {
            g.D.call(this);
            this.policy = a;
            this.player = b;
            this.ma = c;
            this.onLoadCallback = d;
            this.D = e;
            this.V = f;
            this.C = new p5;
            this.J = -1;
            this.B = this.u = this.j = null;
            this.K = new g.Dq(this.KW, 1E3, this);
            this.events = new g.LK(this);
            g.H(this, this.K);
            g.H(this, this.events);
            this.events.T(b, "SEEK_COMPLETE", this.Vz);
            this.Vz();
            this.KW()
        },
        jhb = function(a) {
            return a.j && a.j.B ? a.j.B + a.player.Kd() < a.player.getCurrentTime() : !1
        },
        khb = function(a, b) {
            var c = g.GJ(b, a.policy, {}).kf(),
                d = {
                    format: "RAW",
                    withCredentials: !0
                };
            if (a.policy.Ba) {
                d.method = "POST";
                var e = b.ot(),
                    f = (0, g.uY)([120, 0]);
                e && g.LN(e, g.ZMa);
                d.postBody = f
            }
            a.D && (d.responseType = "arraybuffer");
            a.B = g.fA(c, d, 3, 100).then(function(h) {
                a: {
                    h = h.xhr;a.isDisposed();
                    if (a.u) {
                        var l = !(a.D ? h.response : h.responseText) || 400 <= h.status,
                            m = g.Jua(h);
                        if (m) {
                            h = g.GJ(a.u, a.policy, {});
                            a.u.Wk(h, m);
                            khb(a, a.u);
                            break a
                        }
                        if (l) a.player.ya("capfail", {
                            status: h.status
                        });
                        else if (a.player.di().Fi("fcb_r"), m = a.u.gb[0].Pa, null != a.onLoadCallback && a.J !== m) {
                            l = a.u.gb[0];
                            if (a.D) a.onLoadCallback(h.response,
                                1E3 * (l.startTime + a.player.Kd()));
                            else a.onLoadCallback(h.responseText, 1E3 * (l.startTime + a.player.Kd()));
                            a.J = m
                        }
                    }
                    a.u = null;a.B = null
                }
            }).Dk(function(h) {
                a.u = null;
                a.B = null;
                var l;
                a.player.ya("capfail", {
                    status: null == (l = h.xhr) ? void 0 : l.status
                })
            });
            a.u = b;
            hhb(a.C, a.u.gb[0].Pa)
        },
        q5 = function(a, b) {
            g.ZT.call(this, b.W());
            this.u = a;
            this.I = b;
            this.B = null;
            this.D = !1;
            this.J = g.VM(this.I.W()) && !this.u.isManifestless
        },
        mhb = function(a, b) {
            var c = [],
                d;
            for (d in a.u.j)
                if (a.u.j.hasOwnProperty(d)) {
                    var e = a.u.j[d];
                    if (g.zNa(e, b || null)) {
                        var f = e.info.id,
                            h = f,
                            l = "." + f,
                            m = "",
                            n = "",
                            p = "";
                        if (e = e.info.captionTrack) f = e.languageCode, h = e.displayName, l = e.vssId, m = e.kind, a.I.W().N("html5_expose_xtags_through_caption_track") && (n = e.xtags), p = e.id;
                        else {
                            e = f;
                            var q = g.Yeb.get(e);
                            null == q && (q = lhb[e] || lhb[e.replace(/-/g, "_")], g.Yeb.set(e, q));
                            h = q || h
                        }
                        c.push(new g.kN({
                            id: d,
                            languageCode: f,
                            languageName: h,
                            is_servable: !0,
                            is_default: !0,
                            is_translateable: !1,
                            vss_id: l,
                            kind: m,
                            xtags: n,
                            captionId: p
                        }))
                    }
                }
            return c
        },
        nhb = function(a, b) {
            return null != b && b in a.u.j ? a.u.j[b] : null
        },
        ohb = function(a, b, c) {
            var d = [],
                e;
            for (e in a.u.j)
                if (a.u.j.hasOwnProperty(e)) {
                    var f = a.u.j[e];
                    if (g.zNa(f, c || null)) {
                        var h = f.info.captionTrack;
                        h && h.languageCode === b && d.push(f)
                    }
                }
            return d.length ? d[0] : null
        },
        qhb = function() {
            var a = void 0;
            a = void 0 === a ? {} : a;
            var b = "suggest_correction" in phb ? phb.suggest_correction : "Edit caption";
            b = b || "";
            var c = {},
                d;
            for (d in a) {
                c.bB = d;
                var e = function(f) {
                    return function() {
                        return String(a[f.bB])
                    }
                }(c);
                b = b.replace(new RegExp("\\$\\{" + c.bB + "\\}", "gi"), e);
                b = b.replace(new RegExp("\\$" + c.bB, "gi"), e);
                c = {
                    bB: c.bB
                }
            }
            return b
        },
        r5 = function(a, b, c, d, e, f, h, l, m, n) {
            var p = {};
            Object.assign(p, b);
            Object.assign(p, a.params);
            Object.assign(p, c);
            var q = {};
            Object.assign(q, b.Xe);
            a.params.Xe && Object.assign(q, a.params.Xe);
            Object.assign(q, c.Xe);
            p.Xe = q;
            var r = 1 === p.Ei,
                v = [{
                    G: "span",
                    S: "captions-text",
                    Y: {
                        style: "word-wrap: normal; display: block;"
                    }
                }],
                y, A, F;
            (l = l.rb("caption_edit_on_hover") && (null == (y = n.getVideoData().getPlayerResponse()) ? void 0 : null == (A = y.captions) ? void 0 : null == (F = A.playerCaptionsTracklistRenderer) ? void 0 : F.openTranscriptCommand)) && v.unshift({
                G: "button",
                S: "caption-edit",
                Y: {
                    tabindex: "0",
                    "aria-label": qhb()
                },
                X: [{
                    G: "svg",
                    Y: {
                        fill: "#e3e3e3",
                        height: "100%",
                        viewBox: "5 5 38 38",
                        width: "100%"
                    },
                    X: [{
                        G: "path",
                        Y: {
                            d: "M9 39h2.2l24.25-24.25-1.1-1.1-1.1-1.1L9 36.8Zm-3 3v-6.4L35.4 6.2q.85-.85 2.12-.82 1.27.02 2.12.87L41.8 8.4q.85.85.85 2.1t-.85 2.1L12.4 42Zm33.5-31.55L37.45 8.4Zm-4.05 4.3-1.1-1.1-1.1-1.1 2.2 2.2Z"
                        }
                    }]
                }]
            });
            g.X.call(this, {
                G: "div",
                S: "caption-window",
                Y: {
                    id: "caption-window-" + a.id,
                    dir: r ? "rtl" : "ltr",
                    tabindex: "0",
                    lang: p.lang
                },
                X: v
            });
            var M = this;
            this.J = [];
            this.Fa = !1;
            this.u = a;
            this.Oa =
                this.Na = null;
            this.playerWidth = f;
            this.playerHeight = h;
            this.K = null;
            this.maxWidth = .96 * f;
            this.maxHeight = .96 * h;
            this.j = p;
            this.td = c;
            this.Ba = b;
            this.C = this.Ha("captions-text");
            this.Fc = "" !== this.C.style.getPropertyValue("box-decoration-break") || "" !== this.C.style.getPropertyValue("-webkit-box-decoration-break");
            this.Va = rhb(d, e, f, h);
            this.Qc = m;
            l && (this.D = this.Ha("caption-edit"), this.T(this.D, "click", function() {
                M.Qc()
            }));
            this.type = 0;
            this.kb = this.Va * shb(q);
            a = new g.zT(this.element, !0);
            g.H(this, a);
            a.subscribe("dragstart", this.t0, this);
            a.subscribe("dragmove", this.s0, this);
            a.subscribe("dragend", this.r0, this);
            this.sb = this.ob = this.Eb = this.wb = 0;
            a = "";
            this.j.windowOpacity && (a = fhb(this.j.windowColor), a = "rgba(" + a[0] + "," + a[1] + "," + a[2] + "," + this.j.windowOpacity + ")");
            b = {
                "background-color": a,
                display: !1 === this.j.isVisible ? "none" : "",
                "text-align": thb[this.j.textAlign]
            };
            this.Fc && (b["border-radius"] = a ? this.kb / 8 + "px" : "");
            (this.B = 2 === this.u.params.Ei ||
                3 === this.u.params.Ei) && uhb(this, this.element);
            g.Nn(this.element, b);
            switch (this.j.Ul) {
                case 0:
                case 1:
                case 2:
                    g.Lq(this.element, "ytp-caption-window-top");
                    break;
                case 6:
                case 7:
                case 8:
                    g.Lq(this.element, "ytp-caption-window-bottom")
            }
        },
        uhb = function(a, b) {
            var c = "vertical-rl";
            1 === a.j.NQ && (c = "vertical-lr");
            g.Ze && (c = "vertical-lr" === c ? "tb-lr" : "tb-rl");
            g.Nn(b, "-o-writing-mode", c);
            g.Nn(b, "-webkit-writing-mode", c);
            g.Nn(b, "writing-mode", c);
            g.Nn(b, "text-orientation", "upright");
            g.Lq(b, "ytp-vertical-caption");
            3 === a.u.params.Ei && (g.Nn(b, "text-orientation", ""), g.Nn(b, "transform", "rotate(180deg)"))
        },
        shb = function(a) {
            var b = 1 + .25 * (a.fontSizeIncrement || 0);
            if (0 === a.offset || 2 === a.offset) b *= .8;
            return b
        },
        vhb = function(a, b) {
            var c = {},
                d = b.background ? b.background : a.j.Xe.background;
            if (null != b.backgroundOpacity || b.background) {
                var e = null != b.backgroundOpacity ? b.backgroundOpacity : a.j.Xe.backgroundOpacity;
                d = fhb(d);
                c.background = "rgba(" + d[0] + "," + d[1] + "," + d[2] + "," + e + ")";
                a.Fc && (c["box-decoration-break"] = "clone", c["border-radius"] = a.kb / 8 + "px")
            }
            if (null != b.fontSizeIncrement || null != b.offset) c["font-size"] = a.Va * shb(b) + "px";
            d = 1;
            e = b.color || a.j.Xe.color;
            if (b.color || null != b.textOpacity) e = fhb(e), d = null == b.textOpacity ? a.j.Xe.textOpacity : b.textOpacity, e = "rgba(" + e[0] + "," + e[1] + "," + e[2] + "," + d + ")",
                c.color = e, c.fill = e;
            var f = b.charEdgeStyle;
            0 === f && (f = void 0);
            if (f) {
                e = "rgba(34, 34, 34, " + d + ")";
                var h = "rgba(204, 204, 204, " + d + ")";
                b.ML && (h = e = b.ML);
                var l = a.Va / 16 / 2,
                    m = Math.max(l, 1),
                    n = Math.max(2 * l, 1),
                    p = Math.max(3 * l, 1),
                    q = Math.max(5 * l, 1);
                d = [];
                switch (f) {
                    case 4:
                        for (; p <= q; p += l) d.push(n + "px " + n + "px " + p + "px " + e);
                        break;
                    case 1:
                        n = 2 <= window.devicePixelRatio ? .5 : 1;
                        for (f = m; f <= p; f += n) d.push(f + "px " + f + "px " + e);
                        break;
                    case 2:
                        d.push(m + "px " + m + "px " + h);
                        d.push("-" + m + "px -" + m + "px " + e);
                        break;
                    case 3:
                        for (p = 0; 5 > p; p++) d.push("0 0 " +
                            n + "px " + e)
                }
                c["text-shadow"] = d.join(", ")
            }
            e = "";
            switch (b.fontFamily) {
                case 1:
                    e = '"Courier New", Courier, "Nimbus Mono L", "Cutive Mono", monospace';
                    break;
                case 2:
                    e = '"Times New Roman", Times, Georgia, Cambria, "PT Serif Caption", serif';
                    break;
                case 3:
                    e = '"Deja Vu Sans Mono", "Lucida Console", Monaco, Consolas, "PT Mono", monospace';
                    break;
                case 5:
                    e = '"Comic Sans MS", Impact, Handlee, fantasy';
                    break;
                case 6:
                    e = '"Monotype Corsiva", "URW Chancery L", "Apple Chancery", "Dancing Script", cursive';
                    break;
                case 7:
                    e = g.tA() ?
                        '"Carrois Gothic SC", sans-serif-smallcaps' : '"Arial Unicode Ms", Arial, Helvetica, Verdana, "Marcellus SC", sans-serif';
                    break;
                case 0:
                case 4:
                    e = '"YouTube Noto", Roboto, "Arial Unicode Ms", Arial, Helvetica, Verdana, "PT Sans Caption", sans-serif'
            }
            e && (c["font-family"] = e);
            e = b.offset;
            null == e && (e = a.j.Xe.offset);
            switch (e) {
                case 0:
                    c["vertical-align"] = "sub";
                    break;
                case 2:
                    c["vertical-align"] = "super"
            }
            7 === b.fontFamily && (c["font-variant"] = "small-caps");
            b.bold && (c["font-weight"] = "bold");
            b.italic && (c["font-style"] =
                "italic");
            b.underline && (c["text-decoration"] = "underline");
            b.x5 && (c.visibility = "hidden");
            1 === b.aW && a.B && (c["text-combine-upright"] = "all", c["text-orientation"] = "mixed", e = g.XM || g.YB, 3 === a.u.params.Ei ? c.transform = e ? "rotate(90deg)" : "rotate(180deg)" : e && (c.transform = "rotate(-90deg)"));
            if (1 === b.Xn || 2 === b.Xn || 3 === b.Xn || 4 === b.Xn || 5 === b.Xn)
                if (g.XM) c["font-weight"] = "bold";
                else switch (c["text-emphasis-style"] = "filled circle", c["text-emphasis-color"] = "currentcolor", c["webkit-text-emphasis"] = "filled circle", b.Xn) {
                    case 4:
                    case 3:
                        c["text-emphasis-position"] =
                            "under left";
                        c["webkit-text-emphasis-position"] = "under left";
                        break;
                    case 5:
                    case 2:
                        c["text-emphasis-position"] = "over right", c["webkit-text-emphasis-position"] = "over right"
                }
            return c
        },
        whb = function(a) {
            a.K = g.cf("SPAN");
            g.Nn(a.K, {
                display: "block"
            });
            g.Lq(a.K, "caption-visual-line");
            a.C.appendChild(a.K)
        },
        xhb = function(a, b) {
            var c = g.cf("SPAN");
            g.Nn(c, {
                display: "inline-block",
                "white-space": "pre-wrap"
            });
            g.Nn(c, vhb(a, b));
            c.classList.add("ytp-caption-segment");
            a.K.appendChild(c);
            c.previousElementSibling && (g.Nn(c.previousElementSibling, {
                "border-top-right-radius": "0",
                "border-bottom-right-radius": "0"
            }), g.Nn(c, {
                "border-top-left-radius": "0",
                "border-bottom-left-radius": "0"
            }));
            return c
        },
        yhb = function(a, b, c) {
            a.Fa = a.Fa || !!c;
            var d = {};
            Object.assign(d, a.j.Xe);
            Object.assign(d, c || b.j);
            Object.assign(d, a.td.Xe);
            (c = !a.K) && whb(a);
            for (var e = a.Na && a.Oa && g.od(d, a.Oa) ? a.Na : xhb(a, d), f = "string" === typeof b.text, h = f ? b.text.split("\n") : [b.text], l = 0; l < h.length; l++) {
                var m = 0 < l || !b.append,
                    n = h[l];
                m && !c ? (whb(a), e = xhb(a, d)) : m && c && (c = !1);
                n && (e.appendChild(f ? g.df(n) : n), f || "RUBY" !== n.tagName || 4 !== n.childElementCount || g.XM || !g.Pn(n.children[2], "text-emphasis") || (m = a.B ? "padding-right" : "padding-top", g.Pn(n.children[2], "text-emphasis-position") && (m =
                    a.B ? "padding-left" : "padding-bottom"), g.Vc ? g.Nn(e, m, "1em") : g.Nn(e, m, "0.5em")))
            }
            a.Oa = d;
            a.Na = e;
            a.J.push(b)
        },
        rhb = function(a, b, c, d) {
            var e = b / 360 * 16;
            b >= a && (a = 640, d > 1.3 * c && (a = 480), e = c / a * 16);
            return e
        },
        s5 = function(a, b, c, d) {
            g.ZT.call(this, a);
            this.videoData = b;
            this.audioTrack = c;
            this.bb = d;
            this.C = b.JL
        },
        t5 = function(a, b, c, d, e, f, h, l, m, n) {
            r5.call(this, a, b, c, d, e, f, h, l, m, n);
            this.type = 1
        },
        u5 = function(a, b, c, d, e, f, h, l, m, n) {
            r5.call(this, a, b, c, d, e, f, h, l, m, n);
            var p = this;
            this.type = 2;
            this.V = [];
            this.qa = this.oa = this.Ya = 0;
            this.Ga = NaN;
            this.hc = 0;
            this.vc = null;
            this.fb = new g.Dq(this.q8, 433, this);
            this.D && (n.xb(this.D, this, 167342), this.T(this.D, "click", function() {
                n.ub(p.D)
            }), a = new g.zT(this.element, !0), g.H(this, a), a.subscribe("hoverstart", function() {
                n.Za(p.D, !0)
            }, this));
            g.Lq(this.element, "ytp-caption-window-rollup");
            g.H(this, this.fb);
            g.Nn(this.element, "overflow", "hidden")
        },
        zhb = function(a, b) {
            if (!b) return "";
            a.B && 1 !== a.u.params.NQ && (b *= -1);
            return "translate" + (a.B ? "X" : "Y") + "(" + b + "px)"
        },
        Ahb = function(a) {
            a.V = Array.from(document.getElementsByClassName("caption-visual-line"));
            for (var b = a.u.params.Er, c = 0, d = 0, e = a.V.length - 1; c < b && -1 < e;) {
                var f = a.V[e];
                d += a.B ? f.offsetWidth : f.offsetHeight;
                c++;
                e--
            }
            a.V.length < b && (d *= b / a.V.length);
            a.oa = d;
            b = Math;
            c = b.max;
            isNaN(a.Ga) && ((d = a.j.Hs) ? (e = g.cf("SPAN"), g.tf(e, "\u2013".repeat(d)), g.Nn(e, vhb(a, a.j.Xe)), a.C.appendChild(e), a.Ga = e.offsetWidth, a.C.removeChild(e)) : a.Ga = 0);
            d = a.C;
            a.qa = c.call(b, a.Ga, a.hc, (a.B ? d.offsetHeight : d.offsetWidth) + 1)
        },
        Bhb = function(a, b) {
            Ahb(a);
            var c = a.V.reduce(function(e, f) {
                return (a.B ? f.offsetWidth : f.offsetHeight) + e
            }, 0);
            c = a.oa - c;
            if (c !== a.Ya) {
                var d = 0 < c && 0 === a.Ya;
                b || isNaN(c) || d || (g.Lq(a.element, "ytp-rollup-mode"), g.Eq(a.fb));
                g.Nn(a.C, "transform", zhb(a, c));
                a.Ya = c
            }
            Ahb(a)
        },
        v5 = function(a, b, c, d, e, f, h) {
            f = void 0 === f ? !1 : f;
            h = void 0 === h ? null : h;
            g.HG.call(this, a, a + b, {
                priority: c,
                namespace: "captions"
            });
            this.windowId = d;
            this.text = e;
            this.append = f;
            this.j = h
        },
        w5 = function(a, b, c, d, e) {
            g.HG.call(this, a, a + b, {
                priority: c,
                namespace: "captions"
            });
            this.id = d;
            this.params = e;
            this.j = []
        },
        Chb = function(a) {
            var b = "_" + x5++;
            return new w5(0, 0x8000000000000, 0, b, a)
        },
        Ehb = function(a, b, c, d, e, f, h) {
            var l = f[0],
                m = h[l.getAttribute("p")];
            if (1 === m.gg) {
                var n = f[1],
                    p = f[2];
                f = f[3];
                l.getAttribute("t");
                n.getAttribute("t");
                p.getAttribute("t");
                f.getAttribute("t");
                l.getAttribute("p");
                n.getAttribute("p");
                f.getAttribute("p");
                h = h[p.getAttribute("p")];
                l = Dhb(l.textContent, n.textContent, p.textContent, f.textContent, h);
                return new v5(a, b, e, c, l, d, m)
            }
            switch (m.gg) {
                case 9:
                case 10:
                    m.Xn = 1;
                    break;
                case 11:
                    m.Xn = 2;
                    break;
                case 12:
                    m.Xn = 3;
                    break;
                case 13:
                    m.Xn = 4;
                    break;
                case 14:
                    m.Xn = 5
            }
            return new v5(a, b, e, c, l.textContent || "", d, m)
        },
        Dhb = function(a, b, c, d, e) {
            var f = g.tA(),
                h =
                f ? g.cf("DIV") : g.cf("RUBY"),
                l = g.cf("SPAN");
            l.textContent = a;
            h.appendChild(l);
            a = f ? g.cf("DIV") : g.cf("RP");
            a.textContent = b;
            h.appendChild(a);
            b = f ? g.cf("DIV") : g.cf("RT");
            b.textContent = c;
            h.appendChild(b);
            c = e.gg;
            if (10 === c || 11 === c || 12 === c || 13 === c || 14 === c)
                if (g.Nn(b, "text-emphasis-style", "filled circle"), g.Nn(b, "text-emphasis-color", "currentcolor"), g.Nn(b, "webkit-text-emphasis", "filled circle"), 11 === e.gg || 13 === e.gg) g.Nn(b, "webkit-text-emphasis-position", "under left"), g.Nn(b, "text-emphasis-position", "under left");
            c = !0;
            if (4 === e.gg || 7 === e.gg || 12 === e.gg ||
                14 === e.gg) g.Nn(h, "ruby-position", "over"), g.Nn(h, "-webkit-ruby-position", "before");
            else if (5 === e.gg || 6 === e.gg || 11 === e.gg || 13 === e.gg) g.Nn(h, "ruby-position", "under"), g.Nn(h, "-webkit-ruby-position", "after"), c = !1;
            e = f ? g.cf("DIV") : g.cf("RP");
            e.textContent = d;
            h.appendChild(e);
            f && (d = c, g.Nn(h, {
                display: "inline-block",
                position: "relative"
            }), f = h.firstElementChild.nextElementSibling, g.Nn(f, "display", "none"), f = f.nextElementSibling, g.Nn(f, {
                "font-size": "0.5em",
                "line-height": "1.2em",
                "text-align": "center",
                position: "absolute",
                left: "50%",
                transform: "translateX(-50%)",
                width: "400%"
            }), g.Nn(h.lastElementChild, "display", "none"), d ? (g.Nn(h, "padding-top", "0.6em"), g.Nn(f, "top", "0")) : (g.Nn(h, "padding-bottom", "0.6em"), g.Nn(f, "bottom", "0")));
            return h
        },
        y5 = function() {
            g.D.apply(this, arguments)
        },
        z5 = function(a) {
            y5.call(this);
            this.C = a;
            this.pens = {};
            this.V = {};
            this.ma = {};
            this.D = "_" + x5++;
            this.K = {};
            this.B = this.j = null;
            this.J = !0
        },
        A5 = function(a, b) {
            a = a.getAttribute(b);
            if (null != a) return Number(a)
        },
        B5 = function(a, b) {
            a = a.getAttribute(b);
            if (null != a) return "1" === a
        },
        C5 = function(a, b) {
            a = A5(a, b);
            return void 0 !== a ? a : null
        },
        E5 = function(a, b) {
            a = a.getAttribute(b);
            if (null != a) return D5.test(a), a
        },
        Fhb = function(a, b) {
            var c = {},
                d = b.getAttribute("ws");
            Object.assign(c, d ? a.ma[d] : a.C);
            a = C5(b, "mh");
            null != a && (c.Lz = a);
            a = C5(b, "ju");
            null != a && (c.textAlign = a);
            a = C5(b, "pd");
            null != a && (c.Ei = a);
            a = C5(b, "sd");
            null != a && (c.NQ = a);
            a = E5(b, "wfc");
            null != a && (c.windowColor = a);
            b = A5(b, "wfo");
            void 0 !== b && (c.windowOpacity = b / 255);
            return c
        },
        Ghb = function(a, b) {
            var c = {},
                d = b.getAttribute("wp");
            d && Object.assign(c, a.V[d]);
            a = C5(b, "ap");
            null != a && (c.Ul = a);
            a = A5(b, "cc");
            null != a && (c.Hs = a);
            a = A5(b, "ah");
            null != a && (c.hk = a);
            a = A5(b, "rc");
            null != a && (c.Er = a);
            b = A5(b, "av");
            null != b && (c.Yn = b);
            return c
        },
        Hhb = function(a, b, c, d) {
            var e = {};
            Object.assign(e, Ghb(a, b));
            Object.assign(e, Fhb(a, b));
            d ? g.od(e, a.C) ? (d = a.D, e = a.C) : d = "_" + x5++ : d = b.getAttribute("id") || "_" + x5++;
            a = A5(b, "t") + c;
            b = A5(b, "d") || 0x8000000000000;
            if (2 === e.Ei || 3 === e.Ei) c = e.Er, e.Er = e.Hs, e.Hs = c;
            return new w5(a, b, 0, d, e)
        },
        F5 = function(a) {
            y5.call(this);
            this.J = a;
            this.j = new Map;
            this.C = new Map;
            this.D = new Map;
            this.B = new Map
        },
        G5 = function(a) {
            a = g.qe(Math.round(a), 0, 16777215).toString(16).toUpperCase();
            return "#000000".substr(0, 7 - a.length) + a
        },
        Ihb = function(a, b, c, d, e) {
            0 === d && (d = 0x8000000000000);
            var f = {};
            b.wpWinPosId && Object.assign(f, a.C.get(b.wpWinPosId));
            b.wsWinStyleId && Object.assign(f, a.D.get(b.wsWinStyleId));
            a = b.rcRowCount;
            void 0 !== a && (f.Er = a);
            b = b.ccColCount;
            void 0 !== b && (f.Hs = b);
            if (2 === f.Ei || 3 === f.Ei) b = f.Er, f.Er = f.Hs, f.Hs = b;
            return new w5(c, d, 0, e, f)
        },
        Khb = function() {
            this.B = this.time = this.mode = this.u = 0;
            this.C = new Jhb(this);
            this.D = new Jhb(this);
            this.j = [];
            this.clear()
        },
        Mhb = function(a, b, c) {
            if (255 === a && 255 === b || !a && !b) return {
                Zu: a,
                Ds: b,
                result: 0
            };
            a = Lhb[a];
            b = Lhb[b];
            if (a & 128) {
                var d;
                if (d = !(b & 128)) d = b, d = c.Ge() && c.Ds === d;
                if (d) return {
                    Zu: a,
                    Ds: b,
                    result: 1
                }
            } else if (b & 128 && 1 <= a && 31 >= a) return {
                Zu: a,
                Ds: b,
                result: 2
            };
            return {
                Zu: a,
                Ds: b,
                result: 3
            }
        },
        Ohb = function(a, b, c, d) {
            255 === b && 255 === c || !b && !c ? (45 === ++a.B && a.reset(), a.C.u.clear(), a.D.u.clear()) : (a.B = 0, Nhb(a.C, b, c, d))
        },
        Phb = function(a, b) {
            a.j.sort(function(e, f) {
                var h = e.time - f.time;
                return 0 === h ? e.order - f.order : h
            });
            for (var c = g.u(a.j), d = c.next(); !d.done; d = c.next()) d = d.value, a.time = d.time, 0 === d.type ? Ohb(a, d.gU, d.hU, b) : 1 === d.type && a.u & 496 && Nhb(a.D, d.gU, d.hU, b);
            a.j.length = 0
        },
        H5 = function() {
            this.type = 0
        },
        I5 = function() {
            this.state = this.Ds = this.Zu = 0
        },
        Qhb = function() {
            this.timestamp = this.j = 0
        },
        J5 = function(a) {
            this.D = a;
            this.B = [];
            this.j = this.u = this.row = 0;
            this.style = new H5;
            for (a = this.C = 0; 15 >= a; a++) {
                this.B[a] = [];
                for (var b = 0; 32 >= b; b++) this.B[a][b] = new Qhb
            }
        },
        K5 = function(a, b) {
            if (3 === a.style.type) {
                for (var c = 0, d = 0, e = a.D.time + 0, f = "", h = "", l = e, m = 1; 15 >= m; ++m) {
                    for (var n = !1, p = d ? d : 1; 32 >= p; ++p) {
                        var q = a.B[m][p];
                        if (0 !== q.j) {
                            0 === c && (c = m, d = p);
                            n = String.fromCharCode(q.j);
                            var r = q.timestamp;
                            r < e && (e = r);
                            q.timestamp = l;
                            h && (f += h, h = "");
                            f += n;
                            n = !0
                        }
                        if ((0 === q.j || 32 === p) && n) {
                            h = "\n";
                            break
                        } else if (d && !n) break
                    }
                    if (c && !n) break
                }
                f && b.C(c, d, e, l, f)
            } else
                for (d = c = 0, f = e = a.D.time + 0, h = 1; 15 >= h; ++h)
                    for (l = "", m = 1; 32 >= m; ++m)
                        if (p = a.B[h][m], q = p.j, 0 !== q && (0 === c && (c = h, d = m), n = String.fromCharCode(q), r = p.timestamp, r <= e && (e = r), l += n, p.reset()), 32 === m || 0 === q) l && b.C(c, d, e, f, l), e = f, l = "", d = c = 0
        },
        Vhb = function(a, b) {
            switch (a) {
                case 0:
                    return Rhb[(b & 127) - 32];
                case 1:
                    return Shb[b & 15];
                case 2:
                    return Thb[b & 31];
                case 3:
                    return Uhb[b & 31]
            }
            return 0
        },
        L5 = function(a) {
            return a.B[a.row][a.u]
        },
        M5 = function(a, b, c) {
            2 <= b && 1 < a.u && (--a.u, L5(a).j = 0);
            var d = L5(a);
            d.timestamp = a.D.time + 0;
            d.j = Vhb(b, c);
            32 > a.u && a.u++
        },
        Whb = function(a, b, c, d) {
            for (var e = 0; e < d; e++)
                for (var f = 0; 32 >= f; f++) {
                    var h = a.B[b + e][f],
                        l = a.B[c + e][f];
                    h.j = l.j;
                    h.timestamp = l.timestamp
                }
        },
        N5 = function(a, b, c) {
            for (var d = 0; d < c; d++)
                for (var e = 0; 32 >= e; e++) a.B[b + d][e].reset()
        },
        Xhb = function(a) {
            a.row = 0 < a.j ? a.j : 1;
            a.u = 1;
            N5(a, 0, 15)
        },
        Yhb = function(a) {
            this.B = a;
            this.D = 0;
            this.style = new H5;
            this.J = new J5(this.B);
            this.K = new J5(this.B);
            this.text = new J5(this.B);
            this.u = this.J;
            this.C = this.K;
            this.j = this.u
        },
        Zhb = function(a, b, c) {
            var d = a.u,
                e = !1;
            switch (a.style.get()) {
                case 4:
                case 1:
                case 2:
                    4 === a.style.get() && 0 < d.j || (K5(d, c), Xhb(a.u), Xhb(a.C), d.row = 15, d.j = b, e = !0)
            }
            a.style.set(3);
            a.j = d;
            a.j.style = a.style;
            a.B.mode = 1 << d.C;
            e ? d.u = 1 : d.j !== b && (d.j > b ? (K5(d, c), N5(d, d.row - d.j, b)) : d.row < b && (b = d.j), d.j = b)
        },
        $hb = function(a) {
            a.style.set(1);
            a.j = a.C;
            a.j.j = 0;
            a.j.style = a.style;
            a.B.mode = 1 << a.j.C
        },
        aib = function(a) {
            a.style.set(4);
            a.j = a.text;
            a.j.style = a.style;
            a.B.mode = 1 << a.j.C
        },
        Jhb = function(a) {
            this.j = a;
            this.D = 0;
            this.B = new Yhb(this.j);
            this.J = new Yhb(this.j);
            this.u = new I5;
            this.C = this.B
        },
        Nhb = function(a, b, c, d) {
            a.u.update();
            b = Mhb(b, c, a.u);
            switch (b.result) {
                case 0:
                    return;
                case 1:
                case 2:
                    return
            }
            var e = b.Zu;
            c = b.Ds;
            if (32 <= e || !e) a.j.mode & a.j.u && (b = e, b & 128 && (b = 127), c & 128 && (c = 127), a = a.C.j, b & 96 && M5(a, 0, b), c & 96 && M5(a, 0, c), 0 !== b && 0 !== c && 3 === a.style.type && K5(a, d));
            else if (e & 16) a: if (!a.u.matches(e, c) && (b = a.u, b.Zu = e, b.Ds = c, b.state = 2, b = e & 8 ? a.J : a.B, a.C = b, a.j.mode = 1 << (a.D << 2) + (b.D << 1) + (4 === b.style.type ? 1 : 0), (a.j.mode | 1 << (a.D << 2) + (b.D << 1) + (4 !== b.style.type ? 1 : 0)) & a.j.u))
                if (c & 64) {
                    d = [11, 11, 1, 2, 3, 4, 12, 13, 14, 15, 5, 6, 7, 8, 9, 10][(e & 7) << 1 | c >> 5 & 1];
                    a = c & 16 ? 4 * ((c & 14) >> 1) : 0;
                    c = b.j;
                    switch (b.style.get()) {
                        case 4:
                            d = c.row;
                            break;
                        case 3:
                            if (d !== c.row) {
                                if (d < c.j && (d = c.j, d === c.row)) break;
                                var f = 1 + c.row - c.j,
                                    h = 1 + d - c.j;
                                Whb(c, h, f, c.j);
                                b = f;
                                e = c.j;
                                h < f ? (f = h + e - f, 0 < f && (b += f, e -= f)) : (f = f + e - h, 0 < f && (e -= f));
                                N5(c, b, e)
                            }
                    }
                    c.row = d;
                    c.u = a + 1
                } else switch (e & 7) {
                    case 1:
                        switch (c & 112) {
                            case 32:
                                M5(b.j, 0, 32);
                                break a;
                            case 48:
                                57 === c ? (d = b.j, L5(d).j = 0, 32 > d.u && d.u++) : M5(b.j, 1, c & 15)
                        }
                        break;
                    case 2:
                        c & 32 && M5(b.j, 2, c & 31);
                        break;
                    case 3:
                        c & 32 && M5(b.j, 3, c & 31);
                        break;
                    case 4:
                    case 5:
                        if (32 <= c && 47 >= c) switch (c) {
                            case 32:
                                $hb(b);
                                break;
                            case 33:
                                d = b.j;
                                1 < d.u && (--d.u, L5(d).j = 0);
                                break;
                            case 36:
                                d = b.j;
                                b = L5(d);
                                for (a = 0; 15 >= a; a++)
                                    for (c = 0; 32 >= c; c++)
                                        if (d.B[a][c] === b) {
                                            for (; 32 >= c; c++) d.B[a][c].reset();
                                            break
                                        }
                                break;
                            case 37:
                                Zhb(b, 2, d);
                                break;
                            case 38:
                                Zhb(b, 3, d);
                                break;
                            case 39:
                                Zhb(b, 4, d);
                                break;
                            case 40:
                                M5(b.j, 0, 32);
                                break;
                            case 41:
                                b.style.set(2);
                                b.j = b.u;
                                b.j.j = 0;
                                b.j.style = b.style;
                                b.B.mode = 1 << b.j.C;
                                break;
                            case 42:
                                d = b.text;
                                d.j = 15;
                                d.style.set(4);
                                Xhb(d);
                                aib(b);
                                break;
                            case 43:
                                aib(b);
                                break;
                            case 44:
                                a = b.u;
                                switch (b.style.get()) {
                                    case 1:
                                    case 2:
                                    case 3:
                                        K5(a, d)
                                }
                                N5(a,
                                    0, 15);
                                break;
                            case 45:
                                b: {
                                    a = b.j;
                                    switch (b.style.get()) {
                                        default:
                                            case 2:
                                            case 1:
                                            break b;
                                        case 4:
                                                if (15 > a.row) {
                                                ++a.row;
                                                a.u = 1;
                                                break b
                                            }
                                        case 3:
                                    }
                                    2 > a.j && (a.j = 2, a.row < a.j && (a.row = a.j));b = a.row - a.j + 1;K5(a, d);Whb(a, b, b + 1, a.j - 1);N5(a, a.row, 1)
                                }
                                break;
                            case 46:
                                N5(b.C, 0, 15);
                                break;
                            case 47:
                                K5(b.u, d), b.C.updateTime(b.B.time + 0), d = b.C, b.C = b.u, b.u = d, $hb(b)
                        }
                        break;
                    case 7:
                        switch (c) {
                            case 33:
                            case 34:
                            case 35:
                                d = b.j, 32 < (d.u += c & 3) && (d.u = 32)
                        }
                }
        },
        bib = function() {},
        O5 = function(a, b, c) {
            this.trackData = a;
            this.J = c;
            this.version = this.D = this.B = this.byteOffset = 0;
            this.j = new DataView(this.trackData);
            this.u = []
        },
        P5 = function(a) {
            var b = a.byteOffset;
            a.byteOffset += 1;
            return a.j.getUint8(b)
        },
        Q5 = function(a) {
            var b = a.byteOffset;
            a.byteOffset += 4;
            return a.j.getUint32(b)
        },
        R5 = function(a, b) {
            y5.call(this);
            this.B = a;
            this.C = b;
            this.track = "CC3" === this.C.languageName ? 4 : 0;
            this.j = new Khb;
            this.j.u = 1 << this.track
        },
        dib = function(a) {
            if ("string" === typeof a) return !1;
            a = new O5(a, 8, 0);
            return cib(a)
        },
        cib = function(a) {
            if (!(a.byteOffset < a.j.byteLength) || 1380139777 !== Q5(a)) return !1;
            a.version = P5(a);
            if (1 < a.version) return !1;
            P5(a);
            P5(a);
            P5(a);
            return !0
        },
        S5 = function() {
            y5.call(this)
        },
        eib = function(a, b, c, d, e, f, h, l, m) {
            switch (h.tagName) {
                case "b":
                    l.bold = !0;
                    break;
                case "i":
                    l.italic = !0;
                    break;
                case "u":
                    l.underline = !0
            }
            for (var n = 0; n < h.childNodes.length; n++) {
                var p = h.childNodes[n];
                if (3 === p.nodeType) p = new v5(b, c, d, e.id, p.nodeValue, f || 0 < n, g.kd(l) ? void 0 : l), m.push(p), e.j.push(p);
                else {
                    var q = {};
                    Object.assign(q, l);
                    eib(a, b, c, d, e, !0, p, q, m)
                }
            }
        },
        fib = function(a) {
            var b = a.split(":");
            a = 0;
            b = g.u(b);
            for (var c = b.next(); !c.done; c = b.next()) a = 60 * a + Number(c.value);
            return 1E3 * a
        },
        gib = function(a, b, c, d) {
            d = Object.assign({
                Lz: 0
            }, d);
            return new w5(a, b, c, "_" + x5++, d)
        },
        T5 = function(a, b) {
            g.D.call(this);
            this.I = a;
            this.Z = b;
            this.parser = null;
            this.j = this.I.ez()
        },
        mib = function(a, b, c, d, e) {
            d = d || 0;
            e = e || 0;
            if (a.j && b) {
                var f = e,
                    h = hib(a, b, d),
                    l = [];
                try {
                    for (var m = g.u(h), n = m.next(); !n.done; n = m.next()) {
                        var p = n.value,
                            q = p.trackData,
                            r = p.FQ;
                        l = "string" !== typeof q ? l.concat(iib(a, c, q, r, f)) : "WEBVTT" === q.substring(0, 6) ? l.concat(jib(a, q, r)) : l.concat(kib(a, c, q, r))
                    }
                    var v = l
                } catch (y) {
                    g.mG(y), a.clear(), v = []
                }
                if (0 !== v.length) return v
            }
            b = lib(b);
            if (!b) return [];
            try {
                return "string" !== typeof b ? iib(a, c, b, d, e) : "WEBVTT" === b.substring(0, 6) ? jib(a, b, d) : kib(a, c, b, d)
            } catch (y) {
                return g.mG(y), a.clear(), []
            }
        },
        lib = function(a) {
            if ("string" ===
                typeof a || dib(a)) return a;
            var b = new DataView(a);
            if (8 >= b.byteLength || 1718909296 !== b.getUint32(4)) return "";
            b = g.RI(b, 0, 1835295092);
            if (!b || !b.size) return "";
            a = new Uint8Array(a, b.dataOffset, b.size - (b.dataOffset - b.offset));
            return g.CI(a)
        },
        hib = function(a, b, c) {
            if ("string" === typeof b || dib(b)) return [{
                trackData: b,
                FQ: c
            }];
            var d = new DataView(b);
            if (8 >= d.byteLength || 1718909296 !== d.getUint32(4)) return [];
            var e = g.zta(d);
            if (a.j && e) {
                var f = g.rta(e),
                    h = g.sta(e);
                e = e.j;
                f && e && a.j.aF(e, f, h)
            }
            a = g.$I(d, 1835295092);
            if (!a || !a.length || !a[0].size) return [];
            f = [];
            for (h = 0; h < a.length; h++) e = a[h], e = new Uint8Array(b, e.dataOffset, e.size - (e.dataOffset - e.offset)), e = g.CI(e), f.push({
                trackData: e,
                FQ: c + 1E3 * h
            });
            nib(d, f, c);
            return f = f.filter(function(l) {
                return !!l.trackData
            })
        },
        nib = function(a, b, c) {
            var d = g.RI(a, 0, 1836476516),
                e = 9E4;
            d && (e = g.SI(d) || 9E4);
            d = 0;
            for (var f = g.$I(a, 1836019558), h = 0; h < f.length; h++) {
                var l = f[h];
                h < b.length && (l = g.RI(a, l.dataOffset, 1953653094)) && (l = g.RI(a, l.dataOffset, 1952867444)) && (l = g.YI(l) / e * 1E3, 0 === h && (d = l), b[h].FQ = l - d + c || c * h * 1E3)
            }
        },
        iib = function(a, b, c, d, e) {
            if (!dib(c)) throw Error("Invalid binary caption track data");
            a.parser || (a.parser = new R5(e, b));
            return a.parser.u(c, d)
        },
        jib = function(a, b, c) {
            a.parser || (a.parser = new S5);
            a = a.parser.u(b, c);
            .01 > Math.random() && g.nG(Error("Deprecated subtitles format in web player: WebVTT"));
            return a
        },
        kib = function(a, b, c, d) {
            if ("{" === c[0]) try {
                return a.parser || (a.parser = new F5(oib(b))), a.parser.u(c, d)
            } catch (f) {
                return g.mG(f), []
            }
            var e = g.x$a(c);
            if (!e || !e.firstChild) throw a = Error("Invalid caption track data"), a.params = c, a;
            if ("timedtext" === e.firstChild.tagName) {
                if (3 === Number(e.firstChild.getAttribute("format"))) return a.parser || (a.parser = new z5(oib(b), a.Z)), a.parser.u(e, d);
                a = Error("Unsupported subtitles format in web player (Format2)");
                a.params = c;
                throw a;
            }
            if ("transcript" === e.firstChild.tagName) throw a = Error("Unsupported subtitles format in web player (Format1)"), a.params = c, a;
            a = Error("Invalid caption track data");
            a.params = c;
            throw a;
        },
        oib = function(a) {
            var b = {};
            if (a = g.nN(a)) b.lang = a, g.Cbb.test(a) && (b.Ei = 1);
            return b
        },
        U5 = function(a) {
            g.VT.call(this, a);
            var b = this;
            this.I = a;
            this.Z = this.I.W();
            this.videoData = this.I.getVideoData();
            this.wb = this.I.qb();
            this.B = {
                Xe: {}
            };
            this.D = {
                Xe: {}
            };
            this.Fa = [];
            this.qa = {};
            this.Ya = {};
            this.oa = !1;
            this.Fc = g.WO(this.videoData);
            this.ob = g.ANa(this.videoData, this.I);
            this.hc = !!this.videoData.captionTracks.length;
            this.vc = !!this.videoData.Hd;
            this.fb = "3" === this.Z.controlsType;
            this.j = this.K = this.V = this.Va = this.sb = null;
            this.kb = new T5(this.I, this.Z);
            this.u = null;
            this.Ga = new g.LK(this);
            this.J = new g.X({
                G: "div",
                S: "ytp-caption-window-container",
                Y: {
                    id: "ytp-caption-window-container"
                }
            });
            this.ma = {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0,
                width: 1,
                height: 1
            };
            var c = null,
                d = g.Jr("yt-html5-player-modules::subtitlesModuleData");
            d && (c = new g.hr(d));
            this.storage = c;
            var e;
            this.Eb = !(null == (e = a.Qe()) || !e.TE());
            this.C = pib(this);
            this.Ba = !this.C && this.fb && this.Eb && this.ob;
            g.H(this, this.kb);
            this.C ? this.Oa = this.Na = null : (this.Na = new g.Bq(this.fR, void 0, this), g.H(this, this.Na), this.Oa = new g.Dq(this.O9, 2E3, this), g.H(this, this.Oa));
            g.H(this, this.Ga);
            g.XS(this.player, this.J.element,
                4);
            g.H(this, this.J);
            this.C || this.Ga.T(a, "resize", this.hR);
            (this.Yb = g.EM(this.Z) && !g.UA() && !this.I.isFullscreen() && !this.C && !this.Ba) && this.Ga.T(a, "resize", this.B7);
            this.Ga.T(a, "onPlaybackAudioChange", this.T6);
            this.Ga.T(a, g.JG("captions"), function(f) {
                b.onCueRangeEnter(f)
            });
            this.Ga.T(a, g.KG("captions"), function(f) {
                b.onCueRangeExit(f)
            });
            qib(this, ghb() || {});
            this.player.Qa("onCaptionsModuleAvailable")
        },
        tib = function(a) {
            if (1 === a.Z.Yb || 1 === a.videoData.hD || "alwayson" === g.EO(a.videoData, "yt:cc")) return !0;
            if (a.videoData.captionTracks.length) var b = a.player.getAudioTrack().u;
            if (2 === a.Z.Yb) {
                if (g.TM(a.Z)) var c = rib(a);
                else if (a.storage) try {
                    c = a.storage.get("module-enabled")
                } catch (e) {
                    a.storage.remove("module-enabled")
                } else c = null;
                if (null != c) return !!c
            }
            c = Zgb(a.player.getAudioTrack(), g.TM(a.Z));
            var d = g.EO(a.videoData, "yt:cc");
            if (void 0 === sib(a)) {
                if ("CAPTIONS_INITIAL_STATE_ON_RECOMMENDED" === c) return d ? "on" === d : !0;
                if ("CAPTIONS_INITIAL_STATE_OFF_RECOMMENDED" === c) return "on" === d
            } else return "on" === d;
            return "ON" ===
                b || "on" === g.EO(a.videoData, "yt:cc")
        },
        V5 = function(a, b) {
            if (a.u && (void 0 === b || !b) || !a.videoData.captionTracks.length) return !1;
            a = a.player.getAudioTrack();
            return !!a.j || "FORCED_ON" === a.u
        },
        sib = function(a) {
            var b = void 0,
                c = g.tB(g.sB(), 65);
            if (g.TM(a.Z) && null != c) {
                if (null != rib(a)) return !1;
                b = !c
            }
            return b
        },
        uib = function(a) {
            return a.Z.N("html5_honor_caption_availabilities_in_audio_track") && !a.ob
        },
        vib = function(a) {
            var b;
            a.Fc ? b = new s5(a.Z, a.videoData, a.player.getAudioTrack(), a.player) : a.ob ? b = new q5(a.videoData.j, a.player) : a.hc ? b = new g.$T(a.Z, a.videoData, a.player.getAudioTrack()) : b = new g.bU(a.Z, a.videoData.Hd, a.videoData.videoId, g.Vza(a.videoData), a.videoData.Im, a.videoData.eventId);
            return b
        },
        X5 = function(a, b) {
            if (a.j) {
                if (a.K && a.K.C) return a.K.C;
                g.PO(a.videoData) && (b = !0);
                b || (b = a.vc ? !1 : a.hc ? !1 : !0);
                b = b || wib(a);
                b = g.WT(a.j.j, b);
                var c = null;
                if ($gb(a.Z)) {
                    var d = a.I.isInline() ? void 0 : g.mB("yt-player-caption-sticky-language");
                    for (var e = [d, a.videoData.captionsLanguagePreference, a.Z.captionsLanguagePreference, g.EO(a.videoData, "yt:cc_default_lang")], f = !1, h = 0; h < e.length; h++) {
                        var l = e[h];
                        if (l) {
                            f = !0;
                            for (var m = 0; m < b.length; m++)
                                if (g.nN(b[m]) === l) return b[m];
                            l = l.split("-")[0];
                            for (m = 0; m < b.length; m++)
                                if (g.nN(b[m]) === l) return b[m]
                        }
                    }
                    if (a.Z.N("web_player_always_enable_auto_translation") &&
                        f && a.j && (e = a.j.C, e.length))
                        for (e = g.u(e), f = e.next(); !f.done; f = e.next())
                            if (f = f.value, f.languageCode === d) {
                                c = f;
                                break
                            }
                } else
                    for (d = [a.videoData.captionsLanguagePreference, a.Z.captionsLanguagePreference, g.EO(a.videoData, "yt:cc_default_lang")], e = 0; e < d.length; e++)
                        for (f = 0; f < b.length; f++)
                            if (g.nN(b[f]) === d[e]) return b[f];
                d = null;
                a.K && a.K.B && (d = a.K.B);
                d || (d = b.find(function(n) {
                    return n.isDefault
                }) || null);
                d || (d = b[0] || W5(a));
                d && c && (d = ahb(d, c));
                return d
            }
            return null
        },
        W5 = function(a) {
            return a.K && a.K.j
        },
        Y5 = function(a) {
            var b = W5(a);
            return !!b && a.u === b
        },
        xib = function(a) {
            g.WT(a.j.j, !0);
            var b = Zgb(a.player.getAudioTrack(), g.TM(a.Z)),
                c;
            "CAPTIONS_INITIAL_STATE_ON_REQUIRED" === b ? c = X5(a, a.oa) : "CAPTIONS_INITIAL_STATE_OFF_REQUIRED" === b && V5(a) ? c = W5(a) : sib(a) || a.oa || tib(a) ? c = X5(a, a.oa) : V5(a) && (c = W5(a));
            if (a.C || a.Ba) {
                var d = g.WT(a.j.j, !0);
                b = [];
                for (var e = 0; e < d.length; e++) {
                    var f = d[e],
                        h = g.cf("TRACK");
                    h.setAttribute("kind", "subtitles");
                    h.setAttribute("label", g.lN(f));
                    h.setAttribute("srclang", g.nN(f));
                    h.setAttribute("id", f.toString());
                    a.Ba || h.setAttribute("src", a.j.Kv(f, "vtt"));
                    f === c && h.setAttribute("default",
                        "1");
                    b.push(h)
                }
                c = a.I.Qe();
                c.GB(b);
                c = c.Bb();
                a.Eb && a.Ga.T(c.textTracks, "change", a.Z8)
            } else !a.u && c && Z5(a, c), a.player.Qa("onCaptionsTrackListChanged"), a.player.Qa("onApiChange")
        },
        yib = function(a, b) {
            var c = a.I.Qe().Bb().textTracks;
            a = a.u.toString();
            for (var d = 0; d < c.length; d++) {
                var e = c[d];
                e.id === a && (b ? "showing" !== e.mode && (e.mode = "showing") : "showing" === e.mode && (e.mode = "disabled"))
            }
        },
        Z5 = function(a, b, c) {
            a.loaded && a.unload();
            null != c && (a.oa = c, a.oa && (g.TM(a.Z) ? $5(a, !!b) : a6(a, !!b)));
            a.u = b;
            V5(a) && (a.u = W5(a));
            var d;
            zib(a, null != (d = a.u) ? d : void 0);
            a.load()
        },
        Bib = function(a, b) {
            if (b instanceof w5) {
                var c = a.qa[b.id];
                c && c.u !== b && (c.dispose(), delete a.qa[b.id], c = null);
                c || (c = Aib(a, b)) && (a.qa[b.id] = c)
            } else c = b.windowId, a.Ya[c] || (a.Ya[c] = []), a.Ya[c].push(b)
        },
        Aib = function(a, b) {
            var c = Cib(a);
            if (!c) return null;
            var d = a.u ? g.nN(a.u) : null;
            d && g.Cbb.test(d) && (b.params.Ei = 1);
            var e = a.wb.getPlayerSize();
            d = e.height * a.ma.height;
            e = e.width * a.ma.width;
            "google-live" !== a.Z.playerStyle || a.B.isDefault || Object.assign(b.params, a.B);
            switch (null != b.params.Lz ? b.params.Lz : 1 < b.j.length ? 1 : 0) {
                case 1:
                    return new t5(b, a.B, a.D, c.width, c.height, e, d, a.Z.experiments, a.eK.bind(a), a.I);
                case 2:
                    return new u5(b, a.B, a.D, c.width, c.height, e, d, a.Z.experiments, a.eK.bind(a), a.I);
                default:
                    return new r5(b, a.B, a.D, c.width, c.height, e,
                        d, a.Z.experiments, a.eK.bind(a), a.I)
            }
        },
        qib = function(a, b, c) {
            c = void 0 === c ? !1 : c;
            var d = b6.Xe;
            a.B = {};
            Object.assign(a.B, b6);
            a.B.Xe = {};
            Object.assign(a.B.Xe, d);
            a.D = {
                Xe: {}
            };
            var e = b.backgroundOverride ? a.D : a.B,
                f = b.background || d.background;
            D5.test(f);
            e.Xe.background = f;
            e = b.colorOverride ? a.D : a.B;
            f = b.color || d.color;
            D5.test(f);
            e.Xe.color = f;
            e = b.windowColorOverride ? a.D : a.B;
            f = b.windowColor || b6.windowColor;
            D5.test(f);
            e.windowColor = f;
            e = b.backgroundOpacityOverride ? a.D : a.B;
            f = b.backgroundOpacity;
            null == f && (f = d.backgroundOpacity);
            e.Xe.backgroundOpacity = f;
            e = b.fontSizeIncrementOverride ? a.D : a.B;
            f = b.fontSizeIncrement;
            null == f && (f = d.fontSizeIncrement);
            e.Xe.fontSizeIncrement = f;
            f = b.fontStyleOverride ? a.D : a.B;
            e = b.fontStyle;
            null == e && (e = d.bold && d.italic ? 3 : d.bold ? 1 : d.italic ? 2 : 0);
            f = f.Xe;
            switch (e) {
                case 1:
                    f.bold = !0;
                    delete f.italic;
                    break;
                case 2:
                    delete f.bold;
                    f.italic = !0;
                    break;
                case 3:
                    f.bold = !0;
                    f.italic = !0;
                    break;
                default:
                    delete f.bold, delete f.italic
            }
            e = b.textOpacityOverride ? a.D : a.B;
            f = b.textOpacity;
            null == f && (f = d.textOpacity);
            e.Xe.textOpacity = f;
            e = b.windowOpacityOverride ? a.D : a.B;
            f = b.windowOpacity;
            null == f && (f = b6.windowOpacity);
            e.windowOpacity =
                f;
            e = b.charEdgeStyleOverride ? a.D : a.B;
            f = b.charEdgeStyle;
            null == f && (f = d.charEdgeStyle);
            e.Xe.charEdgeStyle = f;
            e = b.fontFamilyOverride ? a.D : a.B;
            f = b.fontFamily;
            null == f && (f = d.fontFamily);
            e.Xe.fontFamily = f;
            a.loaded && a.hR();
            c && g.lB("yt-player-caption-display-settings", b, 2592E3)
        },
        Eib = function(a, b, c) {
            b && !a.V ? (b = Chb({
                Ei: 0,
                lang: "en"
            }), a.V = [b, new v5(b.start, b.end - b.start, 0, b.id, null != c ? c : "Captions look like this")], a.player.hf(a.V)) : !b && a.V && (Dib(a, a.V), a.V = null)
        },
        Dib = function(a, b) {
            a.player.Kp(b);
            b = g.u(b);
            for (var c = b.next(); !c.done; c = b.next()) g.Jb(a.Fa, c.value);
            g.Cq(a.Na)
        },
        zib = function(a, b) {
            a.Z.N("html5_modify_caption_vss_logging") && (a.videoData.kF = b)
        },
        Cib = function(a) {
            var b = a.wb.getVideoContentRect(!0).height,
                c = a.wb.getVideoContentRect(!0).width;
            if (!b || !c) return null;
            b *= a.ma.height;
            c *= a.ma.width;
            return {
                width: c,
                height: b
            }
        },
        a6 = function(a, b) {
            if (a.storage) try {
                a.storage.set("module-enabled", b)
            } catch (c) {}
        },
        $5 = function(a, b) {
            a.I.isInline() || g.lB("yt-player-sticky-caption", b, 2592E3)
        },
        rib = function(a) {
            if (!a.I.isInline()) return g.mB("yt-player-sticky-caption")
        },
        pib = function(a) {
            var b, c = !(null == (b = a.I.Qe()) || !b.SE());
            return a.fb && c && !a.ob
        },
        wib = function(a) {
            return a.Z.N("web_deprecate_always_includes_asr_setting") && g.TM(a.Z) ? !0 : !!g.tB(g.sB(), 66)
        };
    g.YW.prototype.uC = g.da(41, function(a) {
        var b = 2;
        this.Ba.has(a) ? b = 0 : g.qTa(this, a) && (b = 1);
        return b
    });
    g.hZ.prototype.uC = g.da(40, function(a) {
        return this.xd.uC(a)
    });
    g.YW.prototype.aF = g.da(39, function(a, b, c) {
        this.Va.set(a, {
            Ls: b,
            iy: c
        })
    });
    g.hZ.prototype.aF = g.da(38, function(a, b, c) {
        this.xd.aF(a, b, c)
    });
    g.ZT.prototype.GP = g.da(31, function() {
        return !1
    });
    g.ZT.prototype.Ht = g.da(30, function() {});
    g.$T.prototype.Ht = g.da(29, function(a, b, c) {
        var d = this;
        this.isDisposed();
        b = this.Kv(a, b);
        this.Xr();
        this.u = g.bA(b, {
            format: "RAW",
            onSuccess: function(e) {
                d.u = null;
                c(e.responseText, a)
            },
            withCredentials: !0
        })
    });
    g.bU.prototype.Ht = g.da(28, function(a, b, c) {
        var d = this;
        this.isDisposed();
        b = this.Kv(a, b);
        this.Xr();
        this.u = g.bA(b, {
            format: "RAW",
            onSuccess: function(e) {
                d.u = null;
                c(e.responseText, a)
            },
            withCredentials: !0
        })
    });
    g.FT.prototype.Cy = g.da(27, function() {
        for (var a = g.Me(document, "track", void 0, this.j), b = 0; b < a.length; b++) g.qf(a[b])
    });
    g.LW.prototype.Cy = g.da(26, function() {
        this.mediaElement.Cy()
    });
    g.FT.prototype.TE = g.da(25, function() {
        return !(!this.j.textTracks || !this.j.textTracks.addEventListener)
    });
    g.LW.prototype.TE = g.da(24, function() {
        return this.mediaElement.TE()
    });
    g.FT.prototype.SE = g.da(23, function() {
        return !!this.j.textTracks
    });
    g.LW.prototype.SE = g.da(22, function() {
        return this.mediaElement.SE()
    });
    g.FT.prototype.GB = g.da(21, function(a) {
        for (var b = 0; b < a.length; b++) this.j.appendChild(a[b])
    });
    g.LW.prototype.GB = g.da(20, function(a) {
        this.mediaElement.GB(a)
    });
    g.$Y.prototype.JC = g.da(10, function() {
        return this.K
    });
    g.p_.prototype.JC = g.da(9, function() {
        var a;
        return (null == (a = g.FS(this)) ? void 0 : a.ez()) || null
    });
    g.PS.prototype.ez = g.da(8, function() {
        return this.app.JC()
    });
    g.b_.prototype.ez = g.da(7, function() {
        var a;
        return (null == (a = this.Ea) ? void 0 : a.JC()) || null
    });
    g.qI.prototype.WG = g.da(3, function(a) {
        return (a = this.Zo(a)) ? a.j : 0
    });
    g.sK.prototype.WG = g.da(2, function() {
        return 0
    });
    var ehb = /#(.)(.)(.)/,
        dhb = /^#(?:[0-9a-f]{3}){1,2}$/i,
        lhb = {
            aa: "Afar",
            ab: "Abkhazian",
            ace: "Achinese",
            ach: "Acoli",
            ada: "Adangme",
            ady: "Adyghe",
            ae: "Avestan",
            aeb: "Tunisian Arabic",
            af: "Afrikaans",
            afh: "Afrihili",
            agq: "Aghem",
            ain: "Ainu",
            ak: "Akan",
            akk: "Akkadian",
            akz: "Alabama",
            ale: "Aleut",
            aln: "Gheg Albanian",
            alt: "Southern Altai",
            am: "Amharic",
            an: "Aragonese",
            ang: "Old English",
            anp: "Angika",
            ar: "Arabic",
            ar_001: "Arabic (world)",
            arc: "Aramaic",
            arn: "Mapuche",
            aro: "Araona",
            arp: "Arapaho",
            arq: "Algerian Arabic",
            ars: "Najdi Arabic",
            arw: "Arawak",
            ary: "Moroccan Arabic",
            arz: "Egyptian Arabic",
            as: "Assamese",
            asa: "Asu",
            ase: "American Sign Language",
            ast: "Asturian",
            av: "Avaric",
            avk: "Kotava",
            awa: "Awadhi",
            ay: "Aymara",
            az: "Azerbaijani",
            az_Cyrl: "Azerbaijani (Cyrillic)",
            az_Latn: "Azerbaijani (Latin)",
            ba: "Bashkir",
            bal: "Baluchi",
            ban: "Balinese",
            bar: "Bavarian",
            bas: "Basaa",
            bax: "Bamun",
            bbc: "Batak Toba",
            bbj: "Ghomala",
            be: "Belarusian",
            bej: "Beja",
            bem: "Bemba",
            bew: "Betawi",
            bez: "Bena",
            bfd: "Bafut",
            bfq: "Badaga",
            bg: "Bulgarian",
            bgc: "Haryanvi",
            bgn: "Western Balochi",
            bho: "Bhojpuri",
            bi: "Bislama",
            bik: "Bikol",
            bin: "Bini",
            bjn: "Banjar",
            bkm: "Kom",
            bla: "Siksik\u00e1",
            bm: "Bambara",
            bn: "Bangla",
            bo: "Tibetan",
            bpy: "Bishnupriya",
            bqi: "Bakhtiari",
            br: "Breton",
            bra: "Braj",
            brh: "Brahui",
            brx: "Bodo",
            bs: "Bosnian",
            bs_Cyrl: "Bosnian (Cyrillic)",
            bs_Latn: "Bosnian (Latin)",
            bss: "Akoose",
            bua: "Buriat",
            bug: "Buginese",
            bum: "Bulu",
            byn: "Blin",
            byv: "Medumba",
            ca: "Catalan",
            cad: "Caddo",
            car: "Carib",
            cay: "Cayuga",
            cch: "Atsam",
            ccp: "Chakma",
            ce: "Chechen",
            ceb: "Cebuano",
            cgg: "Chiga",
            ch: "Chamorro",
            chb: "Chibcha",
            chg: "Chagatai",
            chk: "Chuukese",
            chm: "Mari",
            chn: "Chinook Jargon",
            cho: "Choctaw",
            chp: "Chipewyan",
            chr: "Cherokee",
            chy: "Cheyenne",
            ckb: "Central Kurdish",
            ckb_Arab: "Central Kurdish (Arabic)",
            co: "Corsican",
            cop: "Coptic",
            cps: "Capiznon",
            cr: "Cree",
            crh: "Crimean Tatar",
            cs: "Czech",
            csb: "Kashubian",
            cu: "Church Slavic",
            cv: "Chuvash",
            cy: "Welsh",
            da: "Danish",
            dak: "Dakota",
            dar: "Dargwa",
            dav: "Taita",
            de: "German",
            de_AT: "German (Austria)",
            de_CH: "German (Switzerland)",
            del: "Delaware",
            den: "Slave",
            dgr: "Dogrib",
            din: "Dinka",
            dje: "Zarma",
            doi: "Dogri",
            dsb: "Lower Sorbian",
            dua: "Duala",
            dum: "Middle Dutch",
            dv: "Divehi",
            dyo: "Jola-Fonyi",
            dyu: "Dyula",
            dz: "Dzongkha",
            dzg: "Dazaga",
            ebu: "Embu",
            ee: "Ewe",
            efi: "Efik",
            egy: "Ancient Egyptian",
            eka: "Ekajuk",
            el: "Greek",
            elx: "Elamite",
            en: "English",
            en_AU: "English (Australia)",
            en_CA: "English (Canada)",
            en_GB: "English (United Kingdom)",
            en_US: "English (United States)",
            enm: "Middle English",
            eo: "Esperanto",
            es: "Spanish",
            es_419: "Spanish (Latin America)",
            es_ES: "Spanish (Spain)",
            es_MX: "Spanish (Mexico)",
            et: "Estonian",
            eu: "Basque",
            ewo: "Ewondo",
            fa: "Persian",
            fa_AF: "Persian (Afghanistan)",
            fan: "Fang",
            fat: "Fanti",
            ff: "Fula",
            ff_Adlm: "Fula (Adlam)",
            ff_Latn: "Fula (Latin)",
            fi: "Finnish",
            fil: "Filipino",
            fj: "Fijian",
            fo: "Faroese",
            fon: "Fon",
            fr: "French",
            fr_CA: "French (Canada)",
            fr_CH: "French (Switzerland)",
            frm: "Middle French",
            fro: "Old French",
            frr: "Northern Frisian",
            frs: "Eastern Frisian",
            fur: "Friulian",
            fy: "Western Frisian",
            ga: "Irish",
            gaa: "Ga",
            gay: "Gayo",
            gba: "Gbaya",
            gd: "Scottish Gaelic",
            gez: "Geez",
            gil: "Gilbertese",
            gl: "Galician",
            gmh: "Middle High German",
            gn: "Guarani",
            goh: "Old High German",
            gon: "Gondi",
            gor: "Gorontalo",
            got: "Gothic",
            grb: "Grebo",
            grc: "Ancient Greek",
            gsw: "Swiss German",
            gu: "Gujarati",
            guz: "Gusii",
            gv: "Manx",
            gwi: "Gwich\u02bcin",
            ha: "Hausa",
            hai: "Haida",
            haw: "Hawaiian",
            he: "Hebrew",
            hi: "Hindi",
            hi_Latn: "Hindi (Latin)",
            hil: "Hiligaynon",
            hit: "Hittite",
            hmn: "Hmong",
            ho: "Hiri Motu",
            hr: "Croatian",
            hsb: "Upper Sorbian",
            ht: "Haitian Creole",
            hu: "Hungarian",
            hup: "Hupa",
            hy: "Armenian",
            hz: "Herero",
            ia: "Interlingua",
            iba: "Iban",
            ibb: "Ibibio",
            id: "Indonesian",
            ie: "Interlingue",
            ig: "Igbo",
            ii: "Sichuan Yi",
            ik: "Inupiaq",
            ilo: "Iloko",
            "in": "Indonesian",
            inh: "Ingush",
            io: "Ido",
            is: "Icelandic",
            it: "Italian",
            iu: "Inuktitut",
            iw: "Hebrew",
            ja: "Japanese",
            jbo: "Lojban",
            jgo: "Ngomba",
            jmc: "Machame",
            jpr: "Judeo-Persian",
            jrb: "Judeo-Arabic",
            jv: "Javanese",
            ka: "Georgian",
            kaa: "Kara-Kalpak",
            kab: "Kabyle",
            kac: "Kachin",
            kaj: "Jju",
            kam: "Kamba",
            kaw: "Kawi",
            kbd: "Kabardian",
            kbl: "Kanembu",
            kcg: "Tyap",
            kde: "Makonde",
            kea: "Kabuverdianu",
            kfo: "Koro",
            kg: "Kongo",
            kgp: "Kaingang",
            kha: "Khasi",
            kho: "Khotanese",
            khq: "Koyra Chiini",
            ki: "Kikuyu",
            kj: "Kuanyama",
            kk: "Kazakh",
            kkj: "Kako",
            kl: "Kalaallisut",
            kln: "Kalenjin",
            km: "Khmer",
            kmb: "Kimbundu",
            kn: "Kannada",
            ko: "Korean",
            kok: "Konkani",
            kos: "Kosraean",
            kpe: "Kpelle",
            kr: "Kanuri",
            krc: "Karachay-Balkar",
            krl: "Karelian",
            kru: "Kurukh",
            ks: "Kashmiri",
            ks_Arab: "Kashmiri (Arabic)",
            ks_Deva: "Kashmiri (Devanagari)",
            ksb: "Shambala",
            ksf: "Bafia",
            ksh: "Colognian",
            ku: "Kurdish",
            kum: "Kumyk",
            kut: "Kutenai",
            kv: "Komi",
            kw: "Cornish",
            ky: "Kyrgyz",
            la: "Latin",
            lad: "Ladino",
            lag: "Langi",
            lah: "Western Panjabi",
            lam: "Lamba",
            lb: "Luxembourgish",
            lez: "Lezghian",
            lg: "Ganda",
            li: "Limburgish",
            lkt: "Lakota",
            ln: "Lingala",
            lo: "Lao",
            lol: "Mongo",
            loz: "Lozi",
            lrc: "Northern Luri",
            lt: "Lithuanian",
            lu: "Luba-Katanga",
            lua: "Luba-Lulua",
            lui: "Luiseno",
            lun: "Lunda",
            luo: "Luo",
            lus: "Mizo",
            luy: "Luyia",
            lv: "Latvian",
            mad: "Madurese",
            maf: "Mafa",
            mag: "Magahi",
            mai: "Maithili",
            mak: "Makasar",
            man: "Mandingo",
            mas: "Masai",
            mde: "Maba",
            mdf: "Moksha",
            mdr: "Mandar",
            men: "Mende",
            mer: "Meru",
            mfe: "Morisyen",
            mg: "Malagasy",
            mga: "Middle Irish",
            mgh: "Makhuwa-Meetto",
            mgo: "Meta\u02bc",
            mh: "Marshallese",
            mi: "M\u0101ori",
            mic: "Mi'kmaq",
            min: "Minangkabau",
            mk: "Macedonian",
            ml: "Malayalam",
            mn: "Mongolian",
            mnc: "Manchu",
            mni: "Manipuri",
            mni_Beng: "Manipuri (Bangla)",
            mo: "Romanian",
            moh: "Mohawk",
            mos: "Mossi",
            mr: "Marathi",
            ms: "Malay",
            mt: "Maltese",
            mua: "Mundang",
            mul: "Multiple languages",
            mus: "Muscogee",
            mwl: "Mirandese",
            mwr: "Marwari",
            my: "Burmese",
            mye: "Myene",
            myv: "Erzya",
            mzn: "Mazanderani",
            na: "Nauru",
            nap: "Neapolitan",
            naq: "Nama",
            nb: "Norwegian Bokm\u00e5l",
            nd: "North Ndebele",
            nds: "Low German",
            nds_NL: "Low German (Netherlands)",
            ne: "Nepali",
            "new": "Newari",
            ng: "Ndonga",
            nia: "Nias",
            niu: "Niuean",
            nl: "Dutch",
            nl_BE: "Dutch (Belgium)",
            nmg: "Kwasio",
            nn: "Norwegian Nynorsk",
            nnh: "Ngiemboon",
            no: "Norwegian",
            nog: "Nogai",
            non: "Old Norse",
            nqo: "N\u2019Ko",
            nr: "South Ndebele",
            nso: "Northern Sotho",
            nus: "Nuer",
            nv: "Navajo",
            nwc: "Classical Newari",
            ny: "Nyanja",
            nym: "Nyamwezi",
            nyn: "Nyankole",
            nyo: "Nyoro",
            nzi: "Nzima",
            oc: "Occitan",
            oj: "Ojibwa",
            om: "Oromo",
            or: "Odia",
            os: "Ossetic",
            osa: "Osage",
            ota: "Ottoman Turkish",
            pa: "Punjabi",
            pa_Arab: "Punjabi (Arabic)",
            pa_Guru: "Punjabi (Gurmukhi)",
            pag: "Pangasinan",
            pal: "Pahlavi",
            pam: "Pampanga",
            pap: "Papiamento",
            pau: "Palauan",
            pcm: "Nigerian Pidgin",
            peo: "Old Persian",
            phn: "Phoenician",
            pi: "Pali",
            pl: "Polish",
            pon: "Pohnpeian",
            pro: "Old Proven\u00e7al",
            ps: "Pashto",
            pt: "Portuguese",
            pt_BR: "Portuguese (Brazil)",
            pt_PT: "Portuguese (Portugal)",
            qu: "Quechua",
            raj: "Rajasthani",
            rap: "Rapanui",
            rar: "Rarotongan",
            rm: "Romansh",
            rn: "Rundi",
            ro: "Romanian",
            ro_MD: "Romanian (Moldova)",
            rof: "Rombo",
            rom: "Romany",
            ru: "Russian",
            rup: "Aromanian",
            rw: "Kinyarwanda",
            rwk: "Rwa",
            sa: "Sanskrit",
            sad: "Sandawe",
            sah: "Yakut",
            sam: "Samaritan Aramaic",
            saq: "Samburu",
            sas: "Sasak",
            sat: "Santali",
            sat_Olck: "Santali (Ol Chiki)",
            sba: "Ngambay",
            sbp: "Sangu",
            sc: "Sardinian",
            scn: "Sicilian",
            sco: "Scots",
            sd: "Sindhi",
            sd_Arab: "Sindhi (Arabic)",
            sd_Deva: "Sindhi (Devanagari)",
            se: "Northern Sami",
            see: "Seneca",
            seh: "Sena",
            sel: "Selkup",
            ses: "Koyraboro Senni",
            sg: "Sango",
            sga: "Old Irish",
            sh: "Serbo-Croatian",
            shi: "Tachelhit",
            shi_Latn: "Tachelhit (Latin)",
            shi_Tfng: "Tachelhit (Tifinagh)",
            shn: "Shan",
            shu: "Chadian Arabic",
            si: "Sinhala",
            sid: "Sidamo",
            sk: "Slovak",
            sl: "Slovenian",
            sm: "Samoan",
            sma: "Southern Sami",
            smj: "Lule Sami",
            smn: "Inari Sami",
            sms: "Skolt Sami",
            sn: "Shona",
            snk: "Soninke",
            so: "Somali",
            sog: "Sogdien",
            sq: "Albanian",
            sr: "Serbian",
            sr_Cyrl: "Serbian (Cyrillic)",
            sr_Latn: "Serbian (Latin)",
            srn: "Sranan Tongo",
            srr: "Serer",
            ss: "Swati",
            ssy: "Saho",
            st: "Southern Sotho",
            su: "Sundanese",
            su_Latn: "Sundanese (Latin)",
            suk: "Sukuma",
            sus: "Susu",
            sux: "Sumerian",
            sv: "Swedish",
            sw: "Swahili",
            sw_CD: "Swahili (Congo - Kinshasa)",
            swb: "Comorian",
            syc: "Classical Syriac",
            syr: "Syriac",
            ta: "Tamil",
            te: "Telugu",
            tem: "Timne",
            teo: "Teso",
            ter: "Tereno",
            tet: "Tetum",
            tg: "Tajik",
            th: "Thai",
            ti: "Tigrinya",
            tig: "Tigre",
            tiv: "Tiv",
            tk: "Turkmen",
            tkl: "Tokelau",
            tl: "Tagalog",
            tlh: "Klingon",
            tli: "Tlingit",
            tmh: "Tamashek",
            tn: "Tswana",
            to: "Tongan",
            tog: "Nyasa Tonga",
            tpi: "Tok Pisin",
            tr: "Turkish",
            trv: "Taroko",
            ts: "Tsonga",
            tsi: "Tsimshian",
            tt: "Tatar",
            tum: "Tumbuka",
            tvl: "Tuvalu",
            tw: "Twi",
            twq: "Tasawaq",
            ty: "Tahitian",
            tyv: "Tuvinian",
            tzm: "Central Atlas Tamazight",
            udm: "Udmurt",
            ug: "Uyghur",
            uga: "Ugaritic",
            uk: "Ukrainian",
            umb: "Umbundu",
            ur: "Urdu",
            uz: "Uzbek",
            uz_Arab: "Uzbek (Arabic)",
            uz_Cyrl: "Uzbek (Cyrillic)",
            uz_Latn: "Uzbek (Latin)",
            vai: "Vai",
            vai_Latn: "Vai (Latin)",
            vai_Vaii: "Vai (Vai)",
            ve: "Venda",
            vi: "Vietnamese",
            vo: "Volap\u00fck",
            vot: "Votic",
            vun: "Vunjo",
            wa: "Walloon",
            wae: "Walser",
            wal: "Wolaytta",
            war: "Waray",
            was: "Washo",
            wo: "Wolof",
            xal: "Kalmyk",
            xh: "Xhosa",
            xog: "Soga",
            yao: "Yao",
            yap: "Yapese",
            yav: "Yangben",
            ybb: "Yemba",
            yi: "Yiddish",
            yo: "Yoruba",
            yrl: "Nheengatu",
            yue: "Cantonese",
            yue_Hans: "Cantonese (Simplified)",
            yue_Hant: "Cantonese (Traditional)",
            za: "Zhuang",
            zap: "Zapotec",
            zbl: "Blissymbols",
            zen: "Zenaga",
            zgh: "Standard Moroccan Tamazight",
            zh: "Chinese",
            zh_Hans: "Chinese (Simplified)",
            zh_Hant: "Chinese (Traditional)",
            zh_TW: "Chinese (Taiwan)",
            zu: "Zulu",
            zun: "Zuni",
            zxx: "No linguistic content",
            zza: "Zaza"
        };
    p5.prototype.contains = function(a) {
        a = g.Ub(this.segments, a);
        return 0 <= a || 0 > a && 1 === (-a - 1) % 2
    };
    p5.prototype.length = function() {
        return this.segments.length / 2
    };
    g.w(ihb, g.D);
    g.k = ihb.prototype;
    g.k.xa = function() {
        g.D.prototype.xa.call(this);
        this.B && this.B.cancel()
    };
    g.k.Vz = function() {
        this.seekTo(this.player.getCurrentTime())
    };
    g.k.seekTo = function(a) {
        a -= this.player.Kd();
        var b = this.j;
        this.j = g.Bb(this.ma.Cq(a).gb);
        b !== this.j && this.V && this.V()
    };
    g.k.reset = function() {
        this.C = new p5;
        this.J = -1;
        this.B && (this.B.cancel(), this.B = null)
    };
    g.k.KW = function() {
        this.isDisposed();
        var a;
        if (a = null != this.j) a = this.j, a = a.j.xs(a);
        if (a && !this.B && !(this.j && 30 < this.j.startTime - this.player.getCurrentTime())) {
            a = this.j;
            a = a.j.xB(a);
            var b;
            if (null == (b = this.player.getVideoData()) ? 0 : b.enableServerStitchedDai)
                if (b = this.player.ez()) {
                    var c = a.gb[0].j.info.id,
                        d = a.gb[0].Pa,
                        e = a.gb[0].C;
                    if (this.policy.Ba) {
                        if (b = b.ot(e, d, c, 3)) a.J = b
                    } else if (c = b.bp(e, d, c, 3))
                        if (b = b.uC(d), 0 === b) c && (a.u = new g.jI(c));
                        else if (2 === b) {
                        this.K.start();
                        jhb(this) && this.seekTo(this.player.getCurrentTime());
                        return
                    }
                }
            a.gb[0].duration ? (this.C.contains(a.gb[0].Pa) || khb(this, a), this.j = g.Bb(a.gb)) : jhb(this) && this.seekTo(this.player.getCurrentTime())
        }
        this.K.start()
    };
    g.w(q5, g.ZT);
    g.k = q5.prototype;
    g.k.Ht = function(a, b, c) {
        var d = this;
        this.Xr();
        b = nhb(this, a.getId());
        b || (b = a.languageCode, b = this.u.isManifestless ? ohb(this, b, "386") : ohb(this, b));
        if (b) {
            var e = 1E3 * (b.index.WG(b.index.dn()) - b.index.getStartTime(b.index.dn())),
                f = new g.vNa(this.Z);
            this.B = new ihb(f, this.I, b, function(h, l) {
                c(h, a, l, e)
            }, this.J || g.oK(b.info), function() {
                d.B && d.B.reset();
                d.D = !0
            })
        }
    };
    g.k.GP = function() {
        var a = this.D;
        this.D = !1;
        return a
    };
    g.k.Cz = function(a) {
        var b = this.J ? [new g.kN({
            id: "rawcc",
            languageCode: "rawcc",
            languageName: "CC1",
            is_servable: !0,
            is_default: !0,
            is_translateable: !1,
            vss_id: ".en"
        }), new g.kN({
            id: "rawcc",
            languageCode: "rawcc",
            languageName: "CC3",
            is_servable: !0,
            is_default: !0,
            is_translateable: !1,
            vss_id: ".en"
        })] : this.u.isManifestless ? mhb(this, "386") : mhb(this);
        b = g.u(b);
        for (var c = b.next(); !c.done; c = b.next()) g.XT(this.j, c.value);
        a()
    };
    g.k.Xr = function() {
        this.B && (this.B.dispose(), this.B = null)
    };
    g.k.Kv = function() {
        return ""
    };
    var D5 = /^#(?:[0-9a-f]{3}){1,2}$/i,
        phb = window.yt && window.yt.msgs_ || window.ytcfg && window.ytcfg.msgs || {};
    g.Ra("yt.msgs_", phb);
    var thb = ["left", "right", "center", "justify"];
    g.w(r5, g.X);
    g.k = r5.prototype;
    g.k.t0 = function(a, b) {
        this.ob = a;
        this.sb = b;
        var c = g.Wn(this.element, this.element.parentElement);
        this.wb = a - c.x;
        this.Eb = b - c.y
    };
    g.k.s0 = function(a, b) {
        if (a !== this.ob || b !== this.sb) {
            g.Kq(this.element, "ytp-dragging") || g.Lq(this.element, "ytp-dragging");
            var c = g.mo(this.element);
            a = a - this.wb - .02 * this.playerWidth;
            var d = b - this.Eb - .02 * this.playerHeight,
                e = (a + c.width / 2) / this.maxWidth * 3;
            e = Math.floor(g.qe(e, 0, 2));
            var f = (d + c.height / 2) / this.maxHeight * 3;
            f = Math.floor(g.qe(f, 0, 2));
            b = e + 3 * f;
            a = (a + e / 2 * c.width) / this.maxWidth;
            a = 100 * g.qe(a, 0, 1);
            c = (d + f / 2 * c.height) / this.maxHeight;
            c = 100 * g.qe(c, 0, 1);
            this.u.params.Ul = b;
            this.u.params.Yn = c;
            this.u.params.hk =
                a;
            this.u.params.isDefault = !1;
            this.j.Ul = b;
            this.j.Yn = c;
            this.j.hk = a;
            this.j.isDefault = !1;
            this.Ba.Ul = b;
            this.Ba.Yn = c;
            this.Ba.hk = a;
            this.Ba.isDefault = !1;
            this.IY()
        }
    };
    g.k.r0 = function() {
        g.Nq(this.element, "ytp-dragging")
    };
    g.k.IY = function() {
        this.wA(this.J)
    };
    g.k.getType = function() {
        return this.type
    };
    g.k.wA = function(a) {
        var b = Math.min(this.eV(), this.maxWidth),
            c = this.dV(),
            d = "";
        3 === this.u.params.Ei && (d = "rotate(180deg)");
        g.Nn(this.element, {
            top: 0,
            left: 0,
            right: "",
            bottom: "",
            width: b ? b + "px" : "",
            height: c ? c + "px" : "",
            "max-width": "96%",
            "max-height": "96%",
            margin: "",
            transform: ""
        });
        this.rL(a);
        d = {
            transform: d,
            top: "",
            left: "",
            width: b ? b + "px" : "",
            height: c ? c + "px" : "",
            "max-width": "",
            "max-height": ""
        };
        var e = .96 * this.j.hk + 2,
            f = this.j.Ul;
        switch (f) {
            case 0:
            case 3:
            case 6:
                (b = this.j.Xe.fontSizeIncrement) && 0 < b && 2 !== this.j.Ei && 3 !==
                    this.j.Ei && (e = Math.max(e / (1 + 2 * b), 2));
                d.left = e + "%";
                break;
            case 1:
            case 4:
            case 7:
                d.left = e + "%";
                e = this.C.offsetWidth;
                b || e ? (b = b || e + 1, d.width = b + "px", d["margin-left"] = b / -2 + "px") : d.transform += " translateX(-50%)";
                break;
            case 2:
            case 5:
            case 8:
                d.right = 100 - e + "%"
        }
        b = .96 * this.j.Yn + 2;
        switch (f) {
            case 0:
            case 1:
            case 2:
                d.top = b + "%";
                break;
            case 3:
            case 4:
            case 5:
                d.top = b + "%";
                (c = c || this.element.clientHeight) ? (d.height = c + "px", d["margin-top"] = c / -2 + "px") : d.transform += " translateY(-50%)";
                break;
            case 6:
            case 7:
            case 8:
                d.bottom = 100 - b + "%"
        }
        g.Nn(this.element,
            d);
        if (this.D) {
            c = this.C.offsetHeight;
            d = 1;
            for (f = 0; f < a.length; f++) b = a[f], "string" === typeof b.text && (d += b.text.split("\n").length - 1, b.append || 0 === f || d++);
            c /= d;
            this.D.style.height = c + "px";
            this.D.style.width = c + "px";
            this.element.style.paddingLeft = c + 5 + "px";
            this.element.style.paddingRight = c + 5 + "px";
            a = Number(this.element.style.marginLeft.replace("px", "")) - c - 5;
            c = Number(this.element.style.marginRight.replace("px", "")) - c - 5;
            this.element.style.marginLeft = a + "px";
            this.element.style.marginRight = c + "px"
        }
    };
    g.k.rL = function(a) {
        var b;
        for (b = 0; b < a.length && a[b] === this.J[b]; b++);
        if (this.Fa || this.J.length > b) b = 0, this.Fa = !1, this.J = [], this.K = this.Oa = this.Na = null, g.of(this.C);
        for (; b < a.length; b++) yhb(this, a[b])
    };
    g.k.eV = function() {
        return 0
    };
    g.k.dV = function() {
        return 0
    };
    g.k.toString = function() {
        return g.X.prototype.toString.call(this)
    };
    g.w(s5, g.ZT);
    s5.prototype.Ht = function(a, b, c) {
        chb(this.videoData.videoId, a.vssId, c)
    };
    s5.prototype.Cz = function(a) {
        if (this.audioTrack)
            for (var b = g.u(this.audioTrack.captionTracks), c = b.next(); !c.done; c = b.next()) g.XT(this.j, c.value);
        a()
    };
    g.w(t5, r5);
    t5.prototype.rL = function(a) {
        var b = this.u.j;
        r5.prototype.rL.call(this, a);
        for (a = a.length; a < b.length; a++) {
            var c = b[a];
            if (f && c.j === e) var d = f;
            else {
                d = {};
                Object.assign(d, c.j);
                Object.assign(d, Fib);
                var e = c.j;
                var f = d
            }
            yhb(this, c, d)
        }
    };
    var Fib = {
        x5: !0
    };
    g.w(u5, r5);
    g.k = u5.prototype;
    g.k.IY = function() {
        g.Fq(this.fb)
    };
    g.k.q8 = function() {
        g.Nq(this.element, "ytp-rollup-mode");
        this.wA(this.vc, !0)
    };
    g.k.dV = function() {
        return this.B ? this.qa : this.oa
    };
    g.k.eV = function() {
        return this.B ? this.oa : this.qa
    };
    g.k.wA = function(a, b) {
        this.vc = a;
        if (this.u.params.Er) {
            for (var c = 0, d = 0; d < this.J.length && c < a.length; d++) this.J[d] === a[c] && c++;
            0 < c && c < a.length && (a = this.J.concat(a.slice(c)));
            this.hc = this.qa;
            this.oa = this.qa = 0;
            r5.prototype.wA.call(this, a);
            Bhb(this, b)
        }
        r5.prototype.wA.call(this, a)
    };
    g.w(v5, g.HG);
    v5.prototype.toString = function() {
        return g.HG.prototype.toString.call(this)
    };
    g.w(w5, g.HG);
    w5.prototype.toString = function() {
        return g.HG.prototype.toString.call(this)
    };
    var x5 = 0;
    g.w(y5, g.D);
    y5.prototype.u = function() {
        return []
    };
    y5.prototype.reset = function() {};
    g.w(z5, y5);
    z5.prototype.reset = function() {
        this.K = {};
        this.B = this.j = null;
        this.J = !0
    };
    z5.prototype.u = function(a, b) {
        a = a.firstChild;
        a.getAttribute("format");
        b = b || 0;
        Number.isFinite(b);
        a = Array.from(a.childNodes);
        a = g.u(a);
        for (var c = a.next(); !c.done; c = a.next())
            if (c = c.value, 1 === c.nodeType) switch (c.tagName) {
                case "head":
                    var d = c;
                    break;
                case "body":
                    var e = c
            }
        if (d)
            for (d = Array.from(d.childNodes), d = g.u(d), a = d.next(); !a.done; a = d.next())
                if (a = a.value, 1 === a.nodeType) switch (a.tagName) {
                    case "pen":
                        c = a.getAttribute("id");
                        var f = this.pens,
                            h = {},
                            l = a.getAttribute("p");
                        l && Object.assign(h, this.pens[l]);
                        l = B5(a, "b");
                        null != l && (h.bold = l);
                        l = B5(a, "i");
                        null != l && (h.italic = l);
                        l = B5(a, "u");
                        null != l && (h.underline = l);
                        l = C5(a, "et");
                        null != l && (h.charEdgeStyle = l);
                        l = C5(a, "of");
                        null != l && (h.offset = l);
                        l = E5(a, "bc");
                        null != l && (h.background = l);
                        l = E5(a, "ec");
                        null != l && (h.ML = l);
                        l = E5(a, "fc");
                        null != l && (h.color = l);
                        l = C5(a, "fs");
                        null != l && 0 !== l && (h.fontFamily = l);
                        l = A5(a, "sz");
                        void 0 !== l && (h.fontSizeIncrement = l / 100 - 1);
                        l = A5(a, "bo");
                        void 0 !== l && (h.backgroundOpacity = l / 255);
                        l = A5(a, "fo");
                        void 0 !== l && (h.textOpacity = l / 255);
                        l = C5(a, "rb");
                        null != l && 10 !== l &&
                            0 !== l && (h.gg = 10 < l ? l - 1 : l);
                        a = C5(a, "hg");
                        null != a && (h.aW = a);
                        f[c] = h;
                        break;
                    case "ws":
                        c = a.getAttribute("id");
                        this.ma[c] = Fhb(this, a);
                        break;
                    case "wp":
                        c = a.getAttribute("id"), this.V[c] = Ghb(this, a)
                }
        if (e) {
            d = [];
            e = Array.from(e.childNodes);
            e = g.u(e);
            for (a = e.next(); !a.done; a = e.next())
                if (a = a.value, 1 === a.nodeType) switch (a.tagName) {
                    case "w":
                        this.j = Hhb(this, a, b, !1);
                        (a = this.K[this.j.id]) && a.end > this.j.start && (a.end = this.j.start);
                        this.K[this.j.id] = this.j;
                        d.push(this.j);
                        break;
                    case "p":
                        l = b;
                        c = [];
                        f = a.getAttribute("w") || this.D;
                        h = !!B5(a, "a");
                        l = (A5(a, "t") || 0) + l;
                        var m = A5(a, "d") || 5E3;
                        h || (!this.J && this.B && this.B.windowId === f && this.B.end > l && (this.B.end = l), this.B && "\n" === this.B.text && (this.B.text = ""));
                        var n = h ? 6 : 5,
                            p = a.getAttribute("p");
                        p = p ? this.pens[p] : null;
                        var q = Array.from(a.childNodes);
                        q.length && (this.J = null != a.getAttribute("d"));
                        for (var r = 0; r < q.length; r++) {
                            var v = q[r],
                                y = void 0;
                            0 < r && (h = !0);
                            var A = void 0;
                            1 === v.nodeType && (A = v);
                            if (A && "s" === A.tagName) {
                                if ((v = (v = A.getAttribute("p")) ? this.pens[v] : null) && v.gg && (1 === v.gg ? (v = q.slice(r, r +
                                        4), 4 === v.length && (y = Ehb(l, m, f, h, n, v, this.pens), r += 3)) : y = Ehb(l, m, f, h, n, [A], this.pens)), !y) {
                                    var F = A;
                                    y = l;
                                    A = m;
                                    v = f;
                                    var M = h,
                                        J = n,
                                        G = F.textContent ? F.textContent : "",
                                        U = F.getAttribute("p");
                                    U = U ? this.pens[U] : null;
                                    F = A5(F, "t") || 0;
                                    y = new v5(y + F, A - F, J, v, G, M, U)
                                }
                            } else y = new v5(l, m, n, f, v.textContent || "", h, p);
                            c.push(y);
                            this.B = y
                        }
                        if (0 < c.length)
                            for (c[0].windowId === this.D && (this.j = Hhb(this, a, b, !0), d.push(this.j)), a = g.u(c), c = a.next(); !c.done; c = a.next()) c = c.value, c.windowId = this.j.id, this.j.j.push(c), d.push(c)
                }
            b = d
        } else b = [];
        return b
    };
    var Gib = new Map([
        [9, 1],
        [10, 1],
        [11, 2],
        [12, 3],
        [13, 4],
        [14, 5]
    ]);
    g.w(F5, y5);
    F5.prototype.reset = function() {
        this.B.clear()
    };
    F5.prototype.u = function(a, b) {
        var c = JSON.parse(a);
        if (!c) return [];
        if (c.pens) {
            a = 0;
            for (var d = g.u(c.pens), e = d.next(); !e.done; e = d.next()) {
                e = e.value;
                var f = {},
                    h = e.pParentId;
                h && Object.assign(f, this.j.get(h));
                e.bAttr && (f.bold = !0);
                e.iAttr && (f.italic = !0);
                e.uAttr && (f.underline = !0);
                h = e.ofOffset;
                null != h && (f.offset = h);
                void 0 !== e.szPenSize && (f.fontSizeIncrement = e.szPenSize / 100 - 1);
                h = e.etEdgeType;
                null != h && (f.charEdgeStyle = h);
                void 0 !== e.ecEdgeColor && (f.ML = G5(e.ecEdgeColor));
                h = e.fsFontStyle;
                null != h && 0 !== h && (f.fontFamily =
                    h);
                void 0 !== e.fcForeColor && (f.color = G5(e.fcForeColor));
                void 0 !== e.foForeAlpha && (f.textOpacity = e.foForeAlpha / 255);
                void 0 !== e.bcBackColor && (f.background = G5(e.bcBackColor));
                void 0 !== e.boBackAlpha && (f.backgroundOpacity = e.boBackAlpha / 255);
                (h = e.rbRuby) && 10 !== h && (f.gg = 10 < h ? h - 1 : h, f.Xn = Gib.get(f.gg));
                e.hgHorizGroup && (f.aW = e.hgHorizGroup);
                this.j.set(a++, f)
            }
        }
        if (c.wsWinStyles)
            for (a = 0, d = g.u(c.wsWinStyles), e = d.next(); !e.done; e = d.next()) e = e.value, f = {}, (h = e.wsParentId) ? Object.assign(f, this.D.get(h)) : Object.assign(f,
                this.J), void 0 !== e.mhModeHint && (f.Lz = e.mhModeHint), void 0 !== e.juJustifCode && (f.textAlign = e.juJustifCode), void 0 !== e.pdPrintDir && (f.Ei = e.pdPrintDir), void 0 !== e.sdScrollDir && (f.NQ = e.sdScrollDir), void 0 !== e.wfcWinFillColor && (f.windowColor = G5(e.wfcWinFillColor)), void 0 !== e.wfoWinFillAlpha && (f.windowOpacity = e.wfoWinFillAlpha / 255), this.D.set(a++, f);
        if (c.wpWinPositions)
            for (a = 0, d = g.u(c.wpWinPositions), e = d.next(); !e.done; e = d.next()) e = e.value, f = {}, (h = e.wpParentId) && Object.assign(f, this.C.get(h)), void 0 !== e.ahHorPos &&
                (f.hk = e.ahHorPos), void 0 !== e.apPoint && (f.Ul = e.apPoint), void 0 !== e.avVerPos && (f.Yn = e.avVerPos), void 0 !== e.ccCols && (f.Hs = e.ccCols), void 0 !== e.rcRows && (f.Er = e.rcRows), this.C.set(a++, f);
        if (c.events) {
            a = [];
            c = g.u(c.events);
            for (d = c.next(); !d.done; d = c.next()) {
                var l = d.value;
                d = (l.tStartMs || 0) + b;
                e = l.dDurationMs || 0;
                if (l.id) f = String(l.id), d = Ihb(this, l, d, e, f), a.push(d), this.B.set(f, d);
                else {
                    l.wWinId ? f = l.wWinId.toString() : (f = "_" + x5++, h = Ihb(this, l, d, e, f), a.push(h), this.B.set(f, h));
                    0 === e && (e = 5E3);
                    h = this.B.get(f);
                    var m = !!l.aAppend,
                        n = m ? 6 : 5,
                        p = l.segs,
                        q = null;
                    l.pPenId && (q = this.j.get(l.pPenId));
                    for (l = 0; l < p.length; l++) {
                        var r = p[l],
                            v = r.utf8;
                        if (v) {
                            var y = r.tOffsetMs || 0,
                                A = null;
                            r.pPenId && (A = this.j.get(r.pPenId));
                            if (2 === (null != h.params.Lz ? h.params.Lz : 1 < h.j.length ? 1 : 0) && m && "\n" === v) continue;
                            if (r = A && 1 === A.gg)
                                if (r = l, r + 3 >= p.length || !p[r + 1].pPenId || !p[r + 2].pPenId || !p[r + 3].pPenId) r = !1;
                                else {
                                    var F = p[r + 1].pPenId;
                                    (F = this.j.get(F)) && F.gg && 2 === F.gg ? (F = p[r + 2].pPenId, F = this.j.get(F), !F || !F.gg || 3 > F.gg ? r = !1 : (F = p[r + 3].pPenId, r = (F = this.j.get(F)) &&
                                        F.gg && 2 === F.gg ? !0 : !1)) : r = !1
                                }
                            if (r) {
                                y = p[l + 1].utf8;
                                r = p[l + 3].utf8;
                                F = p[l + 2].utf8;
                                var M = this.j.get(p[l + 2].pPenId);
                                v = Dhb(v, y, F, r, M);
                                m = new v5(d, e, n, f, v, m, A);
                                l += 3
                            } else m = new v5(d + y, e - y, n, h.id, v, m, A || q);
                            m && (a.push(m), h.j.push(m))
                        }
                        m = !0
                    }
                }
            }
            b = a
        } else b = [];
        return b
    };
    Khb.prototype.clear = function() {
        this.B = this.time = this.mode = 0;
        this.j = [];
        this.reset()
    };
    Khb.prototype.reset = function() {
        this.mode = 0;
        this.C.reset(0);
        this.D.reset(1)
    };
    var Lhb = [128, 1, 2, 131, 4, 133, 134, 7, 8, 137, 138, 11, 140, 13, 14, 143, 16, 145, 146, 19, 148, 21, 22, 151, 152, 25, 26, 155, 28, 157, 158, 31, 32, 161, 162, 35, 164, 37, 38, 167, 168, 41, 42, 171, 44, 173, 174, 47, 176, 49, 50, 179, 52, 181, 182, 55, 56, 185, 186, 59, 188, 61, 62, 191, 64, 193, 194, 67, 196, 69, 70, 199, 200, 73, 74, 203, 76, 205, 206, 79, 208, 81, 82, 211, 84, 213, 214, 87, 88, 217, 218, 91, 220, 93, 94, 223, 224, 97, 98, 227, 100, 229, 230, 103, 104, 233, 234, 107, 236, 109, 110, 239, 112, 241, 242, 115, 244, 117, 118, 247, 248, 121, 122, 251, 124, 253, 254, 127, 0, 129, 130, 3, 132, 5, 6, 135, 136, 9, 10, 139,
        12, 141, 142, 15, 144, 17, 18, 147, 20, 149, 150, 23, 24, 153, 154, 27, 156, 29, 30, 159, 160, 33, 34, 163, 36, 165, 166, 39, 40, 169, 170, 43, 172, 45, 46, 175, 48, 177, 178, 51, 180, 53, 54, 183, 184, 57, 58, 187, 60, 189, 190, 63, 192, 65, 66, 195, 68, 197, 198, 71, 72, 201, 202, 75, 204, 77, 78, 207, 80, 209, 210, 83, 212, 85, 86, 215, 216, 89, 90, 219, 92, 221, 222, 95, 96, 225, 226, 99, 228, 101, 102, 231, 232, 105, 106, 235, 108, 237, 238, 111, 240, 113, 114, 243, 116, 245, 246, 119, 120, 249, 250, 123, 252, 125, 126, 255
    ];
    H5.prototype.set = function(a) {
        this.type = a
    };
    H5.prototype.get = function() {
        return this.type
    };
    I5.prototype.clear = function() {
        this.state = 0
    };
    I5.prototype.update = function() {
        this.state = 2 === this.state ? 1 : 0
    };
    I5.prototype.Ge = function() {
        return 0 !== this.state
    };
    I5.prototype.matches = function(a, b) {
        return this.Ge() && a === this.Zu && b === this.Ds
    };
    Qhb.prototype.reset = function() {
        this.timestamp = this.j = 0
    };
    J5.prototype.updateTime = function(a) {
        for (var b = 1; 15 >= b; ++b)
            for (var c = 1; 32 >= c; ++c) this.B[b][c].timestamp = a
    };
    J5.prototype.debugString = function() {
        for (var a = "\n", b = 1; 15 >= b; ++b) {
            for (var c = 1; 32 >= c; ++c) {
                var d = this.B[b][c];
                a = 0 === d.j ? a + "_" : a + String.fromCharCode(d.j)
            }
            a += "\n"
        }
        return a
    };
    J5.prototype.reset = function(a) {
        for (var b = 0; 15 >= b; b++)
            for (var c = 0; 32 >= c; c++) this.B[b][c].reset();
        this.C = a;
        this.j = 0;
        this.u = this.row = 1
    };
    var Rhb = [32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 225, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 233, 93, 237, 243, 250, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 231, 247, 209, 241, 9632],
        Shb = [174, 176, 189, 191, 8482, 162, 163, 9834, 224, 32, 232, 226, 234, 238, 244, 251],
        Thb = [193, 201, 211, 218, 220, 252, 8216, 161, 42, 39, 9473, 169, 8480, 183, 8220, 8221, 192, 194, 199, 200, 202, 203, 235,
            206, 207, 239, 212, 217, 249, 219, 171, 187
        ],
        Uhb = [195, 227, 205, 204, 236, 210, 242, 213, 245, 123, 125, 92, 94, 95, 124, 126, 196, 228, 214, 246, 223, 165, 164, 9475, 197, 229, 216, 248, 9487, 9491, 9495, 9499];
    Yhb.prototype.reset = function(a, b) {
        this.D = b;
        this.style.set(2);
        this.u = this.J;
        this.C = this.K;
        this.j = this.u;
        var c = (a << 2) + (b << 1);
        this.J.reset(c);
        this.K.reset(c);
        this.text.reset((a << 2) + (b << 1) + 1)
    };
    Jhb.prototype.reset = function(a) {
        this.D = a;
        this.u.clear();
        this.C = this.B;
        this.B.reset(a, 0);
        this.J.reset(a, 1)
    };
    bib.prototype.C = function() {};
    g.w(O5, bib);
    O5.prototype.C = function(a, b, c, d, e) {
        if (c < d) {
            var f = "_" + x5++;
            c = c / 1E3 - this.J;
            d = d / 1E3 - this.J;
            a = new w5(c, d - c, 5, f, {
                textAlign: 0,
                Ul: 0,
                hk: 2.5 * b,
                Yn: 5.33 * a
            });
            e = new v5(c, d - c, 5, f, e);
            this.u.push(a);
            this.u.push(e)
        }
    };
    g.w(R5, y5);
    R5.prototype.u = function(a) {
        a = new O5(a, a.byteLength, this.B);
        if (cib(a)) {
            for (; a.byteOffset < a.j.byteLength;)
                for (0 === a.version ? a.B = Q5(a) * (1E3 / 45) : 1 === a.version && (a.B = 4294967296 * Q5(a) + Q5(a)), a.D = P5(a); 0 < a.D; a.D--) {
                    var b = P5(a),
                        c = P5(a),
                        d = P5(a);
                    b & 4 && (b & 3) === this.track && (0 === this.track || 1 === this.track) && (b = this.j, b.j.push({
                        time: a.B,
                        type: this.track,
                        gU: c,
                        hU: d,
                        order: b.j.length
                    }))
                }
            Phb(this.j, a);
            return a.u
        }
        return []
    };
    R5.prototype.reset = function() {
        this.j.clear()
    };
    g.w(S5, y5);
    S5.prototype.u = function(a, b) {
        var c = [];
        a = a.split(Hib);
        for (var d = 1; d < a.length; d++) {
            var e = a[d],
                f = b;
            if ("" !== e && !Iib.test(e)) {
                var h = Jib.exec(e);
                if (h && 4 <= h.length) {
                    var l = fib(h[1]),
                        m = fib(h[2]) - l;
                    l += f;
                    var n = (h = h[3]) ? h.split(" ") : [];
                    h = {};
                    var p = null;
                    var q = "";
                    var r = null,
                        v = "";
                    n = g.u(n);
                    for (var y = n.next(); !y.done; y = n.next())
                        if (y = y.value.split(":"), 2 === y.length) {
                            var A = y[1];
                            switch (y[0]) {
                                case "line":
                                    y = A.split(",");
                                    y[0].endsWith("%") && (p = y[0], h.Yn = Number.parseInt(p, 10), 2 === y.length && (q = y[1].trim()));
                                    break;
                                case "position":
                                    y =
                                        A.split(",");
                                    r = y[0];
                                    h.hk = Number.parseInt(r, 10);
                                    2 === y.length && (v = y[1].trim());
                                    break;
                                case "align":
                                    switch (A) {
                                        case "start":
                                            h.textAlign = 0;
                                            break;
                                        case "middle":
                                            h.textAlign = 2;
                                            break;
                                        case "end":
                                            h.textAlign = 1
                                    }
                            }
                        }
                    p || q || (q = "end");
                    if (!r) switch (h.textAlign) {
                        case 0:
                            h.hk = 0;
                            break;
                        case 1:
                            h.hk = 100;
                            break;
                        case 2:
                            h.hk = 50
                    }
                    if (null != h.textAlign) {
                        p = 0;
                        switch (q) {
                            case "center":
                                p += 3;
                                break;
                            case "end":
                                p += 6;
                                break;
                            default:
                                p += 0
                        }
                        switch (v) {
                            case "line-left":
                                p += 0;
                                break;
                            case "center":
                                p += 1;
                                break;
                            case "line-right":
                                p += 2;
                                break;
                            default:
                                switch (h.textAlign) {
                                    case 0:
                                        p +=
                                            0;
                                        break;
                                    case 2:
                                        p += 1;
                                        break;
                                    case 1:
                                        p += 2
                                }
                        }
                        q = 0 > p || 8 < p ? 7 : p;
                        h.Ul = q
                    }
                    e = e.substring(Jib.lastIndex).replace(/[\x01-\x09\x0b-\x1f]/g, "");
                    v = h;
                    h = e;
                    e = {};
                    if (0 > h.indexOf("<") && 0 > h.indexOf("&")) f = gib(l, m, 5, v), m = new v5(l, m, 5, f.id, h, !1, g.kd(e) ? void 0 : e), c.push(f), c.push(m), f.j.push(m);
                    else
                        for (q = h.split(Kib), 1 === q.length ? (h = 5, v = gib(l, m, h, v)) : (p = h = 6, v = Object.assign({
                                Hs: 32
                            }, v), v = new w5(l, m, p, "_" + x5++, v)), c.push(v), p = l, r = 0; r < q.length; r++) n = q[r], 0 === r % 2 ? (y = g.x$a("<html>" + n + "</html>"), y.getElementsByTagName("parsererror").length ?
                            (A = y.createElement("span"), A.appendChild(y.createTextNode(n))) : A = y.firstChild, eib(this, p, m - (p - l), h, v, 0 < r, A, e, c)) : p = fib(n) + f
                }
                Jib.lastIndex = 0
            }
        }
        return c
    };
    var Iib = /^NOTE/,
        Hib = /(?:\r\n|\r|\n){2,}/,
        Jib = RegExp("^((?:[\\d]{2}:)?[\\d]{2}:[\\d]{2}\\.[\\d]{3})[\\t ]+--\x3e[\\t ]+((?:[\\d]{2}:)?[\\d]{2}:[\\d]{2}\\.[\\d]{3})(?:[\\t ]*)(.*)(?:\\r\\n|\\r|\\n)", "gm"),
        Kib = RegExp("<((?:[\\d]{2}:)?[\\d]{2}:[\\d]{2}\\.[\\d]{3})>");
    g.MW.YC(S5, {
        u: "wvppt"
    });
    g.w(T5, g.D);
    T5.prototype.clear = function() {
        this.parser && this.parser.dispose();
        this.parser = null
    };
    T5.prototype.reset = function() {
        this.parser && this.parser.reset()
    };
    T5.prototype.xa = function() {
        g.D.prototype.xa.call(this);
        this.clear()
    };
    var b6 = {
        windowColor: "#080808",
        windowOpacity: 0,
        textAlign: 2,
        Ul: 7,
        hk: 50,
        Yn: 100,
        isDefault: !0,
        Xe: {
            background: "#080808",
            backgroundOpacity: .75,
            charEdgeStyle: 0,
            color: "#fff",
            fontFamily: 4,
            fontSizeIncrement: 0,
            textOpacity: 1,
            offset: 1
        }
    };
    g.w(U5, g.VT);
    g.k = U5.prototype;
    g.k.xa = function() {
        if (this.C || this.Ba) {
            var a = this.I.Qe();
            a && !a.isDisposed() && a.Cy()
        } else Eib(this, !1);
        g.VT.prototype.xa.call(this)
    };
    g.k.Nw = function() {
        if (this.fb) return this.C || this.Ba;
        var a = this.player.getAudioTrack();
        if (uib(this)) {
            if (!a.captionTracks.length) return !1;
            if (!this.j) return !0
        }
        a = Zgb(a, g.TM(this.Z));
        return "CAPTIONS_INITIAL_STATE_ON_REQUIRED" === a ? !0 : "CAPTIONS_INITIAL_STATE_OFF_REQUIRED" === a ? V5(this) : sib(this) || V5(this) ? !0 : tib(this)
    };
    g.k.load = function() {
        var a = this;
        g.VT.prototype.load.call(this);
        this.K = this.player.getAudioTrack();
        this.j ? this.u && (this.kb.clear(), this.C ? yib(this, !0) : 3 !== this.player.getPresentingPlayerType() && this.j.Ht(this.u, "json3", function(b, c, d, e) {
                if (b) {
                    var f;
                    zib(a, null != (f = a.u) ? f : void 0);
                    a.j.GP() && (a.Fa = [], a.I.Te("captions"), g.Cq(a.Na), a.kb.reset());
                    b = mib(a.kb, b, c, d, e);
                    a.player.hf(b, void 0, a.ob);
                    !a.oa || a.Ba || Y5(a) || g.MM(a.Z) || g.GM(a.Z) || g.HM(a.Z) || "shortspage" === a.Z.Na || a.player.isInline() || (g.Gq(a.Oa), b = Chb({
                        Ul: 0,
                        hk: 5,
                        Yn: 5,
                        Er: 2,
                        textAlign: 0,
                        Ei: 0,
                        lang: "en"
                    }), a.Va = [b], c = ["Click ", " for settings"], a.sb || (d = new g.XQ(g.QEa()), g.H(a, d), a.sb = d.element), d = b.end - b.start, (e = g.lN(a.u)) && a.Va.push(new v5(b.start, d, 0, b.id, e)), a.Va.push(new v5(b.start, d, 0, b.id, c[0]), new v5(b.start, d, 0, b.id, a.sb, !0), new v5(b.start, d, 0, b.id, c[1], !0)), a.player.hf(a.Va), g.Eq(a.Oa));
                    !a.oa || a.Ba || Y5(a) || (g.TM(a.Z) ? $5(a, !0) : a6(a, !0), a.K && (a.K.C = a.u), a.player.Tp());
                    a.oa = !1
                }
            }), this.C || this.Ba || Y5(this) || this.player.Qa("captionschanged", g.mN(this.u))) :
            (this.j = vib(this), g.H(this, this.j), this.j.Cz(function() {
                xib(a)
            }))
    };
    g.k.unload = function() {
        this.C && this.u ? yib(this, !1) : (this.Oa && g.Gq(this.Oa), this.player.Te("captions"), this.Fa = [], this.j && this.j.Xr(), this.kb.clear(), this.V && this.player.hf(this.V), this.hR());
        g.VT.prototype.unload.call(this);
        this.player.Tp();
        this.player.Qa("captionschanged", {})
    };
    g.k.create = function() {
        this.Nw() && this.load();
        var a;
        a: {
            var b, c, d;
            if (this.Z.N("suggest_caption_correction_menu_item") && this.Z.N("web_player_nitrate_promo_tooltip") && (null == (b = this.videoData.getPlayerResponse()) ? 0 : null == (c = b.captions) ? 0 : null == (d = c.playerCaptionsTracklistRenderer) ? 0 : d.openTranscriptCommand)) {
                var e, f;
                if (b = null == (a = this.videoData.getPlayerResponse()) ? void 0 : null == (e = a.captions) ? void 0 : null == (f = e.playerCaptionsTracklistRenderer) ? void 0 : f.captionTracks)
                    for (a = g.u(b), e = a.next(); !e.done; e = a.next())
                        if (e =
                            e.value, "asr" === e.kind && "en" === e.languageCode) {
                            a = !0;
                            break a
                        }
            }
            a = !1
        }
        a && this.I.ra("showpromotooltip", this.J.element)
    };
    g.k.Z8 = function() {
        for (var a = this.I.Qe().Bb().textTracks, b = null, c = 0; c < a.length; c++)
            if ("showing" === a[c].mode) a: {
                b = a[c].id;
                for (var d = g.WT(this.j.j, !0), e = 0; e < d.length; e++)
                    if (d[e].toString() === b) {
                        b = d[e];
                        break a
                    }
                b = null
            }(this.loaded ? this.u : null) !== b && Z5(this, b, !0)
    };
    g.k.W$ = function() {
        !this.u && this.C || this.unload()
    };
    g.k.onCueRangeEnter = function(a) {
        this.Fa.push(a);
        g.Cq(this.Na)
    };
    g.k.onCueRangeExit = function(a) {
        g.Jb(this.Fa, a);
        this.j instanceof q5 && this.j.J && this.player.Kp([a]);
        g.Cq(this.Na)
    };
    g.k.getCaptionWindowContainerId = function() {
        return this.J.element.id
    };
    g.k.O9 = function() {
        Dib(this, this.Va);
        this.Va = null
    };
    g.k.fR = function() {
        var a = this;
        if (!this.Yb || !this.C) {
            this.Na.stop();
            g.pba(this.Ya);
            this.Fa.sort(g.IG);
            var b = this.Fa;
            if (this.V) {
                var c = g.Wo(b, function(f) {
                    return -1 === this.V.indexOf(f)
                }, this);
                c.length && (b = c)
            }
            b = g.u(b);
            for (c = b.next(); !c.done; c = b.next()) Bib(this, c.value);
            b = g.u(Object.entries(this.qa));
            var d = b.next();
            for (c = {}; !d.done; c = {
                    Ju: c.Ju,
                    Gm: c.Gm
                }, d = b.next()) {
                var e = g.u(d.value);
                d = e.next().value;
                e = e.next().value;
                c.Ju = d;
                c.Gm = e;
                this.Ya[c.Ju] ? (c.Gm.element.parentNode || (c.Gm instanceof u5 || c.Gm instanceof t5 || g.bd(this.qa, function(f) {
                    return function(h, l) {
                        l !== f.Ju && h.u.params.Ul === f.Gm.u.params.Ul && h.u.params.hk === f.Gm.u.params.hk && h.u.params.Yn === f.Gm.u.params.Yn && (h.dispose(), delete a.qa[l]);
                        return l === f.Ju
                    }
                }(c), this), this.J.element.appendChild(c.Gm.element)), c.Gm.wA(this.Ya[c.Ju])) : (c.Gm.dispose(), delete this.qa[c.Ju])
            }
        }
    };
    g.k.T9 = function() {
        qib(this, {}, !0);
        this.player.Qa("captionssettingschanged")
    };
    g.k.Q4 = function() {
        var a = b6.Xe;
        a = {
            background: a.background,
            backgroundOpacity: a.backgroundOpacity,
            charEdgeStyle: a.charEdgeStyle,
            color: a.color,
            fontFamily: a.fontFamily,
            fontSizeIncrement: a.fontSizeIncrement,
            fontStyle: a.bold && a.italic ? 3 : a.bold ? 1 : a.italic ? 2 : 0,
            textOpacity: a.textOpacity,
            windowColor: b6.windowColor,
            windowOpacity: b6.windowOpacity
        };
        var b = ghb() || {};
        null != b.background && (a.background = b.background);
        null != b.backgroundOverride && (a.backgroundOverride = b.backgroundOverride);
        null != b.backgroundOpacity && (a.backgroundOpacity =
            b.backgroundOpacity);
        null != b.backgroundOpacityOverride && (a.backgroundOpacityOverride = b.backgroundOpacityOverride);
        null != b.charEdgeStyle && (a.charEdgeStyle = b.charEdgeStyle);
        null != b.charEdgeStyleOverride && (a.charEdgeStyleOverride = b.charEdgeStyleOverride);
        null != b.color && (a.color = b.color);
        null != b.colorOverride && (a.colorOverride = b.colorOverride);
        null != b.fontFamily && (a.fontFamily = b.fontFamily);
        null != b.fontFamilyOverride && (a.fontFamilyOverride = b.fontFamilyOverride);
        null != b.fontSizeIncrement && (a.fontSizeIncrement =
            b.fontSizeIncrement);
        null != b.fontSizeIncrementOverride && (a.fontSizeIncrementOverride = b.fontSizeIncrementOverride);
        null != b.fontStyle && (a.fontStyle = b.fontStyle);
        null != b.fontStyleOverride && (a.fontStyleOverride = b.fontStyleOverride);
        null != b.textOpacity && (a.textOpacity = b.textOpacity);
        null != b.textOpacityOverride && (a.textOpacityOverride = b.textOpacityOverride);
        null != b.windowColor && (a.windowColor = b.windowColor);
        null != b.windowColorOverride && (a.windowColorOverride = b.windowColorOverride);
        null != b.windowOpacity &&
            (a.windowOpacity = b.windowOpacity);
        null != b.windowOpacityOverride && (a.windowOpacityOverride = b.windowOpacityOverride);
        return a
    };
    g.k.e_ = function(a, b) {
        var c = {};
        Object.assign(c, ghb());
        Object.assign(c, a);
        qib(this, c, b);
        this.player.Qa("captionssettingschanged")
    };
    g.k.hR = function() {
        !this.C && this.loaded && (g.Zc(this.qa, function(a, b) {
            a.dispose();
            delete this.qa[b]
        }, this), this.fR())
    };
    g.k.Ih = function(a, b) {
        switch (a) {
            case "fontSize":
                if (isNaN(b)) break;
                var c = g.qe(b, -2, 4);
                this.e_({
                    fontSizeIncrement: c
                });
                return c;
            case "reload":
                b && !this.C && Z5(this, this.u, !0);
                break;
            case "stickyLoading":
                void 0 !== b && this.Z.J && (g.TM(this.Z) ? $5(this, !!b) : a6(this, !!b));
                break;
            case "track":
                if (!this.j) return {};
                if (b) {
                    if (this.C) break;
                    if (!g.Za(b)) break;
                    if (g.kd(b)) {
                        Z5(this, null, !0);
                        break
                    }
                    a = g.WT(this.j.j, !0);
                    for (var d = 0; d < a.length; d++) {
                        var e = a[d];
                        e.languageCode !== b.languageCode || c && (e.languageName !== b.languageName ||
                            this.Z.N("html5_enable_caption_changes_for_mosaic") && (e.captionId || "") !== (b.captionId || "")) || (c = b.translationLanguage ? ahb(e, b.translationLanguage) : e)
                    }
                    this.yJ(b.position);
                    !c || c === this.u && this.loaded || (a = g.wva(), b = g.nN(c), a.length && b === a[a.length - 1] || (a.push(b), g.lB("yt-player-caption-language-preferences", a)), (a = $gb(this.Z)) && !this.I.isInline() && g.lB("yt-player-caption-sticky-language", b, 86400 * a), Z5(this, c, !0))
                } else return this.loaded && this.u && !Y5(this) ? g.mN(this.u) : {};
                return "";
            case "tracklist":
                return this.j ?
                    g.cn(g.WT(this.j.j, !(!b || !b.includeAsr)), function(f) {
                        return g.mN(f)
                    }) : [];
            case "translationLanguages":
                return this.j ? this.j.C.map(function(f) {
                    return Object.assign({}, f)
                }) : [];
            case "sampleSubtitles":
                this.C || void 0 === b || Eib(this, !!b);
                break;
            case "sampleSubtitlesCustomized":
                this.C || Eib(this, !!b, b);
                break;
            case "recommendedTranslationLanguages":
                return g.wva()
        }
    };
    g.k.getOptions = function() {
        var a = "reload fontSize track tracklist translationLanguages sampleSubtitle".split(" ");
        this.Z.J && a.push("stickyLoading");
        return a
    };
    g.k.Eq = function() {
        var a = this.u;
        if (this.Z.N("html5_modify_caption_vss_logging")) {
            var b;
            return (a = null != (b = this.videoData.kF) ? b : null) ? {
                cc: g.yxa(a)
            } : {}
        }
        return a ? (b = a.vssId, a.translationLanguage && b && (b = "t" + b + "." + g.nN(a)), {
            cc: b
        }) : {}
    };
    g.k.K$ = function() {
        this.isSubtitlesOn() ? (g.TM(this.Z) ? $5(this, !1) : a6(this, !1), zib(this), this.unload(), V5(this, !0) && Z5(this, W5(this), !1)) : this.LZ()
    };
    g.k.LZ = function() {
        this.isSubtitlesOn() || Z5(this, Y5(this) || !this.u ? X5(this, !0) : this.u, !0)
    };
    g.k.isSubtitlesOn = function() {
        return !!this.loaded && !!this.u && !Y5(this)
    };
    g.k.T6 = function() {
        var a = Y5(this);
        V5(this, a) ? Z5(this, this.player.getAudioTrack().j, !1) : this.videoData.captionTracks.length && (this.loaded && this.unload(), uib(this) && (this.oa = !1, this.u = null, this.j && (this.j.dispose(), this.j = null)), this.Nw() && (a ? Z5(this, X5(this), !1) : this.load()))
    };
    g.k.yJ = function(a) {
        a && (this.ma = {
            top: a.top,
            right: a.right,
            bottom: a.bottom,
            left: a.left,
            width: 1 - a.left - a.right,
            height: 1 - a.top - a.bottom
        }, this.J.element.style.top = 100 * this.ma.top + "%", this.J.element.style.left = 100 * this.ma.left + "%", this.J.element.style.width = 100 * this.ma.width + "%", this.J.element.style.height = 100 * this.ma.height + "%", this.Z.N("html5_enable_caption_changes_for_mosaic") && (this.J.element.style.position = "absolute", a = Cib(this))) && (this.J.element.style.width = a.width + "px", this.J.element.style.height =
            a.height + "px")
    };
    g.k.B7 = function() {
        var a = this.I.Qe();
        a && !a.isDisposed() && a.Cy();
        this.I.isFullscreen() ? (this.C = this.fb = !0, this.loaded && xib(this)) : (this.fb = "3" === this.Z.controlsType, this.C = pib(this));
        Z5(this, this.u)
    };
    g.k.eK = function() {
        var a, b, c, d = null == (a = this.videoData.getPlayerResponse()) ? void 0 : null == (b = a.captions) ? void 0 : null == (c = b.playerCaptionsTracklistRenderer) ? void 0 : c.openTranscriptCommand;
        d && this.player.Qa("innertubeCommand", d)
    };
    g.MW.YC(U5, {
        fR: "smucd"
    });
    g.UT("captions", U5);
})(_yt_player);