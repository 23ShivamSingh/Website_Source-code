(function(g) {
    var window = this;
    'use strict';
    var fjb = function(a, b) {
            a.Qa("onAutonavCoundownStarted", b)
        },
        l6 = function(a, b, c) {
            g.Pq(a.element, "ytp-suggestion-set", !!b.videoId);
            var d = b.playlistId;
            c = b.Kg(c ? c : "mqdefault.jpg");
            var e = null,
                f = null;
            b instanceof g.RN && (b.lengthText ? (e = b.lengthText || null, f = b.ew || null) : b.lengthSeconds && (e = g.HR(b.lengthSeconds), f = g.HR(b.lengthSeconds, !0)));
            var h = !!d;
            d = h && "RD" === g.bya(d).type;
            var l = b instanceof g.RN ? b.isLivePlayback : null,
                m = b instanceof g.RN ? b.isUpcoming : null,
                n = b.author,
                p = b.shortViewCount,
                q = b.publishedTimeText,
                r = [],
                v = [];
            n && r.push(n);
            p && (r.push(p), v.push(p));
            q && v.push(q);
            c = {
                title: b.title,
                author: n,
                author_and_views: r.join(" \u2022 "),
                aria_label: b.ariaLabel ||
                    g.PP("Watch $TITLE", {
                        TITLE: b.title
                    }),
                duration: e,
                timestamp: f,
                url: b.Vk(),
                is_live: l,
                is_upcoming: m,
                is_list: h,
                is_mix: d,
                background: c ? "background-image: url(" + c + ")" : "",
                views_and_publish_time: v.join(" \u2022 "),
                autoplayAlternativeHeader: b.Cs
            };
            b instanceof g.QN && (c.playlist_length = b.playlistLength);
            a.update(c)
        },
        m6 = function(a) {
            var b = a.W(),
                c = b.C;
            g.X.call(this, {
                G: "a",
                S: "ytp-autonav-suggestion-card",
                Y: {
                    href: "{{url}}",
                    target: c ? b.ma : "",
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}",
                    "data-is-upcoming": "{{is_upcoming}}"
                },
                X: [{
                    G: "div",
                    Ma: ["ytp-autonav-endscreen-upnext-thumbnail", "ytp-autonav-thumbnail-small"],
                    Y: {
                        style: "{{background}}"
                    },
                    X: [{
                        G: "div",
                        Y: {
                            "aria-label": "{{timestamp}}"
                        },
                        Ma: ["ytp-autonav-timestamp"],
                        Aa: "{{duration}}"
                    }, {
                        G: "div",
                        Ma: ["ytp-autonav-live-stamp"],
                        Aa: "Live"
                    }, {
                        G: "div",
                        Ma: ["ytp-autonav-upcoming-stamp"],
                        Aa: "Upcoming"
                    }, {
                        G: "div",
                        S: "ytp-autonav-list-overlay",
                        X: [{
                            G: "div",
                            S: "ytp-autonav-mix-text",
                            Aa: "Mix"
                        }, {
                            G: "div",
                            S: "ytp-autonav-mix-icon"
                        }]
                    }]
                }, {
                    G: "div",
                    Ma: ["ytp-autonav-endscreen-upnext-title", "ytp-autonav-title-card"],
                    Aa: "{{title}}"
                }, {
                    G: "div",
                    Ma: ["ytp-autonav-endscreen-upnext-author", "ytp-autonav-author-card"],
                    Aa: "{{author}}"
                }, {
                    G: "div",
                    Ma: ["ytp-autonav-endscreen-upnext-author", "ytp-autonav-view-and-date-card"],
                    Aa: "{{views_and_publish_time}}"
                }]
            });
            this.I = a;
            this.suggestion =
                null;
            this.j = c;
            this.Ta("click", this.onClick);
            this.Ta("keypress", this.onKeyPress)
        },
        n6 = function(a, b) {
            b = void 0 === b ? !1 : b;
            g.X.call(this, {
                G: "div",
                S: "ytp-autonav-endscreen-countdown-overlay"
            });
            var c = this;
            this.J = b;
            this.D = void 0;
            this.B = 0;
            this.container = new g.X({
                G: "div",
                S: "ytp-autonav-endscreen-countdown-container"
            });
            g.H(this, this.container);
            this.container.Ja(this.element);
            b = a.W();
            var d = b.C;
            this.I = a;
            this.suggestion = null;
            this.onVideoDataChange("newdata", this.I.getVideoData());
            this.T(a, "videodatachange", this.onVideoDataChange);
            this.j = new g.X({
                G: "div",
                S: "ytp-autonav-endscreen-upnext-container",
                Y: {
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}",
                    "data-is-upcoming": "{{is_upcoming}}"
                },
                X: [{
                    G: "div",
                    S: "ytp-autonav-endscreen-upnext-header"
                }, {
                    G: "div",
                    S: "ytp-autonav-endscreen-upnext-alternative-header",
                    Aa: "{{autoplayAlternativeHeader}}"
                }, {
                    G: "a",
                    S: "ytp-autonav-endscreen-link-container",
                    Y: {
                        href: "{{url}}",
                        target: d ? b.ma : ""
                    },
                    X: [{
                        G: "div",
                        S: "ytp-autonav-endscreen-upnext-thumbnail",
                        Y: {
                            style: "{{background}}"
                        },
                        X: [{
                            G: "div",
                            Y: {
                                "aria-label": "{{timestamp}}"
                            },
                            Ma: ["ytp-autonav-timestamp"],
                            Aa: "{{duration}}"
                        }, {
                            G: "div",
                            Ma: ["ytp-autonav-live-stamp"],
                            Aa: "Live"
                        }, {
                            G: "div",
                            Ma: ["ytp-autonav-upcoming-stamp"],
                            Aa: "Upcoming"
                        }]
                    }, {
                        G: "div",
                        S: "ytp-autonav-endscreen-video-info",
                        X: [{
                            G: "div",
                            S: "ytp-autonav-endscreen-premium-badge"
                        }, {
                            G: "div",
                            S: "ytp-autonav-endscreen-upnext-title",
                            Aa: "{{title}}"
                        }, {
                            G: "div",
                            S: "ytp-autonav-endscreen-upnext-author",
                            Aa: "{{author}}"
                        }, {
                            G: "div",
                            S: "ytp-autonav-view-and-date",
                            Aa: "{{views_and_publish_time}}"
                        }, {
                            G: "div",
                            S: "ytp-autonav-author-and-view",
                            Aa: "{{author_and_views}}"
                        }]
                    }]
                }]
            });
            g.H(this, this.j);
            this.j.Ja(this.container.element);
            d || this.T(this.j.Ha("ytp-autonav-endscreen-link-container"), "click", this.MR);
            this.I.xb(this.container.element, this, 115127);
            this.I.xb(this.j.Ha("ytp-autonav-endscreen-link-container"), this, 115128);
            this.overlay = new g.X({
                G: "div",
                S: "ytp-autonav-overlay"
            });
            g.H(this, this.overlay);
            this.overlay.Ja(this.container.element);
            this.u = new g.X({
                G: "div",
                S: "ytp-autonav-endscreen-button-container"
            });
            g.H(this, this.u);
            this.u.Ja(this.container.element);
            this.cancelButton =
                new g.X({
                    G: "button",
                    Ma: ["ytp-autonav-endscreen-upnext-button", "ytp-autonav-endscreen-upnext-cancel-button", b.N("web_modern_buttons") ? "ytp-autonav-endscreen-upnext-button-rounded" : ""],
                    Y: {
                        "aria-label": "Cancel autoplay"
                    },
                    Aa: "Cancel"
                });
            g.H(this, this.cancelButton);
            this.cancelButton.Ja(this.u.element);
            this.cancelButton.Ta("click", this.x0, this);
            this.I.xb(this.cancelButton.element, this, 115129);
            this.playButton = new g.X({
                G: "a",
                Ma: ["ytp-autonav-endscreen-upnext-button", "ytp-autonav-endscreen-upnext-play-button",
                    b.N("web_modern_buttons") ? "ytp-autonav-endscreen-upnext-button-rounded" : ""
                ],
                Y: {
                    href: "{{url}}",
                    role: "button",
                    "aria-label": "Play next video"
                },
                Aa: "Play Now"
            });
            g.H(this, this.playButton);
            this.playButton.Ja(this.u.element);
            this.playButton.Ta("click", this.MR, this);
            this.I.xb(this.playButton.element, this, 115130);
            this.C = new g.Dq(function() {
                gjb(c)
            }, 500);
            g.H(this, this.C);
            this.LR();
            this.T(a, "autonavvisibility", this.LR);
            this.I.N("web_autonav_color_transition") && (this.T(a, "autonavchange", this.w0), this.T(a, "onAutonavCoundownStarted", this.U6))
        },
        o6 = function(a) {
            var b = a.I.Uk(!0, a.I.isFullscreen());
            g.Pq(a.container.element, "ytp-autonav-endscreen-small-mode", a.lh(b));
            g.Pq(a.container.element, "ytp-autonav-endscreen-is-premium", !!a.suggestion && !!a.suggestion.mJ);
            g.Pq(a.I.getRootNode(), "ytp-autonav-endscreen-cancelled-state", !a.I.Qf());
            g.Pq(a.I.getRootNode(), "countdown-running", a.Yk());
            g.Pq(a.container.element, "ytp-player-content", a.I.Qf());
            g.Nn(a.overlay.element, {
                width: b.width + "px"
            });
            if (!a.Yk()) {
                a.I.Qf() ? hjb(a, Math.round(ijb(a) / 1E3)) : hjb(a);
                b = !!a.suggestion && !!a.suggestion.Cs;
                var c = a.I.Qf() || !b;
                g.Pq(a.container.element, "ytp-autonav-endscreen-upnext-alternative-header-only", !c && b);
                g.Pq(a.container.element, "ytp-autonav-endscreen-upnext-no-alternative-header", c && !b);
                g.$Q(a.u, a.I.Qf());
                g.Pq(a.element, "ytp-enable-w2w-color-transitions", jjb(a))
            }
        },
        gjb = function(a) {
            var b = ijb(a),
                c = Math,
                d = c.min;
            var e = a.B ? Date.now() - a.B : 0;
            c = d.call(c, e, b);
            hjb(a, Math.ceil((b - c) / 1E3));
            500 >= b - c && a.Yk() ? a.select(!0) : a.Yk() && a.C.start()
        },
        ijb = function(a) {
            if (a.I.isFullscreen()) {
                var b;
                a = null == (b = a.I.getVideoData()) ? void 0 : b.jF;
                return -1 === a || void 0 === a ? 8E3 : a
            }
            return 0 <= a.I.Ss() ? a.I.Ss() : g.AL(a.I.W().experiments, "autoplay_time") || 1E4
        },
        jjb = function(a) {
            var b;
            return !(null == (b = a.I.getVideoData()) || !b.watchToWatchTransitionRenderer)
        },
        hjb = function(a, b) {
            b = void 0 === b ? -1 : b;
            a = a.j.Ha("ytp-autonav-endscreen-upnext-header");
            g.of(a);
            if (0 <= b) {
                b = String(b);
                var c = "Up next in $SECONDS".match(RegExp("\\$SECONDS", "gi"))[0],
                    d = "Up next in $SECONDS".indexOf(c);
                if (0 <= d) {
                    a.appendChild(g.df("Up next in $SECONDS".slice(0, d)));
                    var e = g.cf("span");
                    g.Jq(e, "ytp-autonav-endscreen-upnext-header-countdown-number");
                    g.tf(e, b);
                    a.appendChild(e);
                    a.appendChild(g.df("Up next in $SECONDS".slice(d + c.length)));
                    return
                }
            }
            g.tf(a, "Up next")
        },
        p6 = function(a, b) {
            g.X.call(this, {
                G: "div",
                Ma: ["html5-endscreen", "ytp-player-content", b || "base-endscreen"]
            });
            this.created = !1;
            this.player = a
        },
        q6 = function(a) {
            g.X.call(this, {
                G: "div",
                Ma: ["ytp-upnext", "ytp-player-content"],
                Y: {
                    "aria-label": "{{aria_label}}"
                },
                X: [{
                    G: "div",
                    S: "ytp-cued-thumbnail-overlay-image",
                    Y: {
                        style: "{{background}}"
                    }
                }, {
                    G: "span",
                    S: "ytp-upnext-top",
                    X: [{
                        G: "span",
                        S: "ytp-upnext-header",
                        Aa: "Up Next"
                    }, {
                        G: "span",
                        S: "ytp-upnext-title",
                        Aa: "{{title}}"
                    }, {
                        G: "span",
                        S: "ytp-upnext-author",
                        Aa: "{{author}}"
                    }]
                }, {
                    G: "a",
                    S: "ytp-upnext-autoplay-icon",
                    Y: {
                        role: "button",
                        href: "{{url}}",
                        "aria-label": "Play next video"
                    },
                    X: [{
                        G: "svg",
                        Y: {
                            height: "100%",
                            version: "1.1",
                            viewBox: "0 0 72 72",
                            width: "100%"
                        },
                        X: [{
                            G: "circle",
                            S: "ytp-svg-autoplay-circle",
                            Y: {
                                cx: "36",
                                cy: "36",
                                fill: "#fff",
                                "fill-opacity": "0.3",
                                r: "31.5"
                            }
                        }, {
                            G: "circle",
                            S: "ytp-svg-autoplay-ring",
                            Y: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-dasharray": "211",
                                "stroke-dashoffset": "-211",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }, {
                            G: "path",
                            S: "ytp-svg-fill",
                            Y: {
                                d: "M 24,48 41,36 24,24 V 48 z M 44,24 v 24 h 4 V 24 h -4 z"
                            }
                        }]
                    }]
                }, {
                    G: "span",
                    S: "ytp-upnext-bottom",
                    X: [{
                        G: "span",
                        S: "ytp-upnext-cancel"
                    }, {
                        G: "span",
                        S: "ytp-upnext-paused",
                        Aa: "Autoplay is paused"
                    }]
                }]
            });
            this.api = a;
            this.cancelButton = null;
            this.D = this.Ha("ytp-svg-autoplay-ring");
            this.B = this.notification = this.j = this.suggestion = null;
            this.C = new g.Dq(this.eG, 5E3, this);
            this.u = 0;
            var b = this.Ha("ytp-upnext-cancel");
            this.cancelButton = new g.X({
                G: "button",
                Ma: ["ytp-upnext-cancel-button", "ytp-button"],
                Y: {
                    tabindex: "0",
                    "aria-label": "Cancel autoplay"
                },
                Aa: "Cancel"
            });
            g.H(this, this.cancelButton);
            this.cancelButton.Ta("click", this.y0, this);
            this.cancelButton.Ja(b);
            this.cancelButton && this.api.xb(this.cancelButton.element,
                this, 115129);
            g.H(this, this.C);
            this.api.xb(this.element, this, 18788);
            b = this.Ha("ytp-upnext-autoplay-icon");
            this.T(b, "click", this.z0);
            this.api.xb(b, this, 115130);
            this.NR();
            this.T(a, "autonavvisibility", this.NR);
            this.T(a, "mdxnowautoplaying", this.D7);
            this.T(a, "mdxautoplaycanceled", this.E7);
            g.Pq(this.element, "ytp-upnext-mobile", this.api.W().u)
        },
        kjb = function(a, b) {
            if (b) return b;
            if (a.api.isFullscreen()) {
                var c;
                a = null == (c = a.api.getVideoData()) ? void 0 : c.jF;
                return -1 === a || void 0 === a ? 8E3 : a
            }
            return 0 <= a.api.Ss() ? a.api.Ss() : g.AL(a.api.W().experiments, "autoplay_time") || 1E4
        },
        ljb = function(a, b) {
            b = kjb(a, b);
            var c = Math,
                d = c.min;
            var e = (0, g.gC)() - a.u;
            c = d.call(c, e, b);
            b = 0 === b ? 1 : Math.min(c / b, 1);
            a.D.setAttribute("stroke-dashoffset", "" + -211 * (b + 1));
            1 <= b && a.Yk() && 3 !== a.api.getPresentingPlayerType() ? a.select(!0) : a.Yk() && a.j.start()
        },
        r6 = function(a) {
            p6.call(this, a, "autonav-endscreen");
            this.overlay = this.videoData = null;
            this.table = new g.X({
                G: "div",
                S: "ytp-suggestion-panel",
                X: [{
                    G: "div",
                    Ma: ["ytp-autonav-endscreen-upnext-header", "ytp-autonav-endscreen-more-videos"],
                    Aa: "More videos"
                }]
            });
            this.K = new g.X({
                G: "div",
                S: "ytp-suggestions-container"
            });
            this.videos = [];
            this.B = null;
            this.D = this.J = !1;
            this.u = new n6(this.player);
            g.H(this, this.u);
            this.u.Ja(this.element);
            a.getVideoData().Ve ? this.j = this.u : (this.j = new q6(a), g.XS(this.player, this.j.element, 4), g.H(this, this.j));
            this.overlay = new g.X({
                G: "div",
                S: "ytp-autonav-overlay-cancelled-state"
            });
            g.H(this, this.overlay);
            this.overlay.Ja(this.element);
            this.C = new g.LK(this);
            g.H(this, this.C);
            g.H(this, this.table);
            this.table.Ja(this.element);
            this.table.show();
            g.H(this, this.K);
            this.K.Ja(this.table.element);
            this.hide()
        },
        s6 = function(a) {
            var b = a.Qf();
            b !== a.D && (a.D = b, a.player.ra("autonavvisibility"), a.D ? (a.u !== a.j && a.u.hide(), a.table.hide()) : (a.u !== a.j && a.u.show(), a.table.show()))
        },
        t6 = function(a, b) {
            g.X.call(this, {
                G: "button",
                Ma: ["ytp-watch-on-youtube-button", "ytp-button"],
                Aa: "{{content}}"
            });
            this.I = a;
            this.buttonType = this.buttonType = b;
            this.updateButton();
            2 === this.buttonType && g.Lq(this.element, "ytp-continue-watching-button");
            this.Ta("click", this.onClick);
            this.Ta("videodatachange", this.updateButton);
            g.$Q(this, !0)
        },
        u6 = function(a, b) {
            p6.call(this, a, "embeds-lite-endscreen");
            this.I = a;
            this.j = b;
            this.I.xb(this.element, this, 156943);
            this.watchButton = new t6(a, 2);
            g.H(this, this.watchButton);
            this.watchButton.Ja(this.element);
            this.hide()
        },
        mjb = function(a) {
            p6.call(this, a, "subscribecard-endscreen");
            this.j = new g.X({
                G: "div",
                S: "ytp-subscribe-card",
                X: [{
                    G: "img",
                    S: "ytp-author-image",
                    Y: {
                        src: "{{profilePicture}}"
                    }
                }, {
                    G: "div",
                    S: "ytp-subscribe-card-right",
                    X: [{
                        G: "div",
                        S: "ytp-author-name",
                        Aa: "{{author}}"
                    }, {
                        G: "div",
                        S: "html5-subscribe-button-container"
                    }]
                }]
            });
            g.H(this, this.j);
            this.j.Ja(this.element);
            var b = a.getVideoData();
            this.subscribeButton = new g.JU("Subscribe", null, "Unsubscribe", null, !0, !1, b.Ek, b.subscribed, "trailer-endscreen", null, a);
            g.H(this, this.subscribeButton);
            this.subscribeButton.Ja(this.j.Ha("html5-subscribe-button-container"));
            this.T(a, "videodatachange", this.Sa);
            this.Sa();
            this.hide()
        },
        v6 = function(a) {
            var b = a.W(),
                c = g.OK || g.zM ? {
                    style: "will-change: opacity"
                } : void 0,
                d = b.C,
                e = ["ytp-videowall-still"];
            b.u && e.push("ytp-videowall-show-text");
            g.X.call(this, {
                G: "a",
                Ma: e,
                Y: {
                    href: "{{url}}",
                    target: d ? b.ma : "",
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}"
                },
                X: [{
                    G: "div",
                    S: "ytp-videowall-still-image",
                    Y: {
                        style: "{{background}}"
                    }
                }, {
                    G: "span",
                    S: "ytp-videowall-still-info",
                    Y: {
                        "aria-hidden": "true"
                    },
                    X: [{
                        G: "span",
                        S: "ytp-videowall-still-info-bg",
                        X: [{
                            G: "span",
                            S: "ytp-videowall-still-info-content",
                            Y: c,
                            X: [{
                                    G: "span",
                                    S: "ytp-videowall-still-info-title",
                                    Aa: "{{title}}"
                                },
                                {
                                    G: "span",
                                    S: "ytp-videowall-still-info-author",
                                    Aa: "{{author_and_views}}"
                                }, {
                                    G: "span",
                                    S: "ytp-videowall-still-info-live",
                                    Aa: "Live"
                                }, {
                                    G: "span",
                                    S: "ytp-videowall-still-info-duration",
                                    Aa: "{{duration}}"
                                }
                            ]
                        }]
                    }]
                }, {
                    G: "span",
                    Ma: ["ytp-videowall-still-listlabel-regular", "ytp-videowall-still-listlabel"],
                    Y: {
                        "aria-hidden": "true"
                    },
                    X: [{
                        G: "span",
                        S: "ytp-videowall-still-listlabel-icon"
                    }, "Playlist", {
                        G: "span",
                        S: "ytp-videowall-still-listlabel-length",
                        X: [" (", {
                            G: "span",
                            Aa: "{{playlist_length}}"
                        }, ")"]
                    }]
                }, {
                    G: "span",
                    Ma: ["ytp-videowall-still-listlabel-mix",
                        "ytp-videowall-still-listlabel"
                    ],
                    Y: {
                        "aria-hidden": "true"
                    },
                    X: [{
                        G: "span",
                        S: "ytp-videowall-still-listlabel-mix-icon"
                    }, "Mix", {
                        G: "span",
                        S: "ytp-videowall-still-listlabel-length",
                        Aa: " (50+)"
                    }]
                }]
            });
            this.suggestion = null;
            this.u = d;
            this.api = a;
            this.j = new g.LK(this);
            g.H(this, this.j);
            this.Ta("click", this.onClick);
            this.Ta("keypress", this.onKeyPress);
            this.j.T(a, "videodatachange", this.onVideoDataChange);
            a.cg(this.element, this);
            this.onVideoDataChange()
        },
        w6 = function(a) {
            p6.call(this, a, "videowall-endscreen");
            var b = this;
            this.I = a;
            this.B = 0;
            this.stills = [];
            this.C = this.videoData = null;
            this.D = this.K = !1;
            this.V = null;
            this.u = new g.LK(this);
            g.H(this, this.u);
            this.J = new g.Dq(function() {
                g.Lq(b.element, "ytp-show-tiles")
            }, 0);
            g.H(this, this.J);
            var c = new g.X({
                G: "button",
                Ma: ["ytp-button", "ytp-endscreen-previous"],
                Y: {
                    "aria-label": "Previous"
                },
                X: [g.dR()]
            });
            g.H(this, c);
            c.Ja(this.element);
            c.Ta("click", this.D0, this);
            this.table = new g.XQ({
                G: "div",
                S: "ytp-endscreen-content"
            });
            g.H(this, this.table);
            this.table.Ja(this.element);
            c = new g.X({
                G: "button",
                Ma: ["ytp-button", "ytp-endscreen-next"],
                Y: {
                    "aria-label": "Next"
                },
                X: [g.eR()]
            });
            g.H(this, c);
            c.Ja(this.element);
            c.Ta("click", this.C0, this);
            a.getVideoData().Ve ? this.j = new n6(a, !0) : this.j = new q6(a);
            g.H(this, this.j);
            g.XS(this.player, this.j.element, 4);
            a.xb(this.element, this, 158789);
            this.hide()
        },
        x6 = function(a) {
            return g.YS(a.player) && a.JB() && !a.C
        },
        y6 = function(a) {
            var b = a.Qf();
            b !== a.K && (a.K = b, a.player.ra("autonavvisibility"))
        },
        z6 = function(a) {
            p6.call(this, a, "watch-again-on-youtube-endscreen");
            this.watchButton = new t6(a, 1);
            g.H(this, this.watchButton);
            this.watchButton.Ja(this.element);
            g.y$a(a) && (this.j = new g.h3(a, g.GS(a)), g.H(this, this.j), this.u = new g.X({
                G: "div",
                Ma: ["ytp-watch-again-on-youtube-endscreen-more-videos-container"],
                Y: {
                    tabIndex: "-1"
                },
                X: [this.j]
            }), g.H(this, this.u), this.j.Ja(this.u.element), this.u.Ja(this.element));
            a.xb(this.element, this, 156914);
            this.hide()
        },
        qjb = function(a) {
            g.VT.call(this, a);
            var b = this;
            this.endScreen = null;
            this.u = this.j = this.B = this.C = !1;
            this.listeners = new g.LK(this);
            g.H(this, this.listeners);
            var c = a.W(),
                d = a.getVideoData();
            d = d && 0 !== d.limitedPlaybackDurationInSeconds;
            g.MA(g.JM(c)) && d && !g.TS(a) ? (this.u = !0, this.endScreen = new u6(a, g.GS(a))) : g.US(a) ? this.endScreen = new z6(a) : njb(a) ? (this.C = !0, ojb(this), this.j ? this.endScreen = new r6(a) : this.endScreen = new w6(a)) : c.fh ? this.endScreen = new mjb(a) : this.endScreen = new p6(a);
            g.H(this, this.endScreen);
            g.XS(a, this.endScreen.element, 4);
            pjb(this);
            this.listeners.T(a, "videodatachange", this.onVideoDataChange, this);
            this.listeners.T(a, g.JG("endscreen"), function(e) {
                b.onCueRangeEnter(e)
            });
            this.listeners.T(a, g.KG("endscreen"), function(e) {
                b.onCueRangeExit(e)
            })
        },
        ojb = function(a) {
            var b = a.player.getVideoData();
            if (!b || a.j === b.Fm && a.B === b.Ve) return !1;
            a.j = b.Fm;
            a.B = b.Ve;
            return !0
        },
        njb = function(a) {
            a = a.W();
            return a.Hd && !a.fh
        },
        pjb = function(a) {
            a.player.Te("endscreen");
            var b = a.player.getVideoData();
            b = new g.HG(Math.max(1E3 * (b.lengthSeconds - 10), 0), 0x8000000000000, {
                id: "preload",
                namespace: "endscreen"
            });
            var c = new g.HG(0x8000000000000, 0x8000000000000, {
                id: "load",
                priority: 8,
                namespace: "endscreen"
            });
            a.player.hf([b, c])
        };
    g.wW.prototype.sA = g.da(37, function(a) {
        this.vP !== a && (this.vP = a, this.Fl())
    });
    g.mV.prototype.Kr = g.da(36, function(a) {
        this.u !== a && (this.u = a, this.Sa())
    });
    g.wW.prototype.Kr = g.da(35, function(a) {
        this.shareButton && this.shareButton.Kr(a)
    });
    g.iV.prototype.Jr = g.da(34, function(a) {
        this.j !== a && (this.j = a, this.Sa())
    });
    g.wW.prototype.Jr = g.da(33, function(a) {
        this.overflowButton && this.overflowButton.Jr(a)
    });
    g.AU.prototype.JE = g.da(32, function(a) {
        this.wP !== a && (this.wP = a, this.Rp())
    });
    g.PS.prototype.Ss = g.da(6, function() {
        return this.app.Ss()
    });
    g.p_.prototype.Ss = g.da(5, function() {
        return this.getVideoData().hT
    });
    g.w(m6, g.X);
    m6.prototype.select = function() {
        this.I.uo(this.suggestion.videoId, this.suggestion.sessionData, this.suggestion.playlistId, void 0, void 0, this.suggestion.fC || void 0) && this.I.ub(this.element)
    };
    m6.prototype.onClick = function(a) {
        g.oT(a, this.I, this.j, this.suggestion.sessionData || void 0) && this.select()
    };
    m6.prototype.onKeyPress = function(a) {
        switch (a.keyCode) {
            case 13:
            case 32:
                g.XP(a) || (this.select(), g.YP(a))
        }
    };
    g.w(n6, g.X);
    g.k = n6.prototype;
    g.k.vF = function(a) {
        this.suggestion !== a && (this.suggestion = a, l6(this.j, a), this.playButton.updateValue("url", this.suggestion.Vk()), o6(this))
    };
    g.k.Yk = function() {
        return 0 < this.B
    };
    g.k.AA = function() {
        this.Yk() || (this.B = Date.now(), gjb(this), fjb(this.I, ijb(this)), g.Pq(this.I.getRootNode(), "countdown-running", this.Yk()))
    };
    g.k.Aw = function() {
        this.Qr();
        gjb(this);
        var a = this.j.Ha("ytp-autonav-endscreen-upnext-header");
        a && g.tf(a, "Up next")
    };
    g.k.Qr = function() {
        this.Yk() && (this.C.stop(), this.B = 0)
    };
    g.k.select = function(a) {
        this.I.nextVideo(!1, void 0 === a ? !1 : a);
        this.Qr()
    };
    g.k.MR = function(a) {
        g.oT(a, this.I) && (a.currentTarget === this.playButton.element ? this.I.ub(this.playButton.element) : a.currentTarget === this.j.Ha("ytp-autonav-endscreen-link-container") && (a = this.j.Ha("ytp-autonav-endscreen-link-container"), this.I.Za(a, !0), this.I.ub(a)), this.select())
    };
    g.k.x0 = function() {
        this.I.ub(this.cancelButton.element);
        g.RS(this.I, !0);
        this.D && this.I.Qa("innertubeCommand", this.D)
    };
    g.k.onVideoDataChange = function(a, b) {
        var c;
        this.D = null == (c = b.X2) ? void 0 : c.command
    };
    g.k.U6 = function(a) {
        if (jjb(this)) {
            var b = this.I.getVideoData().watchToWatchTransitionRenderer,
                c = null == b ? void 0 : b.fromColorPaletteDark;
            b = null == b ? void 0 : b.toColorPaletteDark;
            if (c && b) {
                var d = this.element;
                d.style.setProperty("--w2w-start-background-color", g.OR(c.surgeColor));
                d.style.setProperty("--w2w-start-primary-text-color", g.OR(c.primaryTitleColor));
                d.style.setProperty("--w2w-start-secondary-text-color", g.OR(c.secondaryTitleColor));
                d.style.setProperty("--w2w-end-background-color", g.OR(b.surgeColor));
                d.style.setProperty("--w2w-end-primary-text-color", g.OR(b.primaryTitleColor));
                d.style.setProperty("--w2w-end-secondary-text-color", g.OR(b.secondaryTitleColor));
                d.style.setProperty("--w2w-animation-duration", a + "ms")
            }
            g.Pq(this.element, "ytp-w2w-animate", !0)
        }
    };
    g.k.w0 = function(a) {
        this.I.N("web_autonav_color_transition") && 2 !== a && g.Pq(this.element, "ytp-w2w-animate", !1)
    };
    g.k.LR = function() {
        var a = this.I.Qf();
        this.J && this.Gb !== a && g.$Q(this, a);
        o6(this);
        this.I.Za(this.container.element, a);
        this.I.Za(this.cancelButton.element, a);
        this.I.Za(this.j.Ha("ytp-autonav-endscreen-link-container"), a);
        this.I.Za(this.playButton.element, a)
    };
    g.k.lh = function(a) {
        return 400 > a.width || 459 > a.height
    };
    g.w(p6, g.X);
    g.k = p6.prototype;
    g.k.create = function() {
        this.created = !0
    };
    g.k.destroy = function() {
        this.created = !1
    };
    g.k.JB = function() {
        return !1
    };
    g.k.Qf = function() {
        return !1
    };
    g.k.tW = function() {
        return !1
    };
    g.w(q6, g.X);
    g.k = q6.prototype;
    g.k.eG = function() {
        this.notification && (this.C.stop(), this.Mc(this.B), this.B = null, this.notification.close(), this.notification = null)
    };
    g.k.vF = function(a) {
        this.suggestion = a;
        l6(this, a, "hqdefault.jpg")
    };
    g.k.NR = function() {
        g.$Q(this, this.api.Qf());
        this.api.Za(this.element, this.api.Qf());
        this.api.Za(this.Ha("ytp-upnext-autoplay-icon"), this.api.Qf());
        this.cancelButton && this.api.Za(this.cancelButton.element, this.api.Qf())
    };
    g.k.M7 = function() {
        window.focus();
        this.eG()
    };
    g.k.AA = function(a) {
        var b = this;
        this.Yk() || (g.JD("a11y-announce", "Up Next " + this.suggestion.title), this.u = (0, g.gC)(), this.j = new g.Dq(function() {
            ljb(b, a)
        }, 25), ljb(this, a), fjb(this.api, kjb(this, a)));
        g.Nq(this.element, "ytp-upnext-autoplay-paused")
    };
    g.k.hide = function() {
        g.X.prototype.hide.call(this)
    };
    g.k.Yk = function() {
        return !!this.j
    };
    g.k.Aw = function() {
        this.Qr();
        this.u = (0, g.gC)();
        ljb(this);
        g.Lq(this.element, "ytp-upnext-autoplay-paused")
    };
    g.k.Qr = function() {
        this.Yk() && (this.j.dispose(), this.j = null)
    };
    g.k.select = function(a) {
        a = void 0 === a ? !1 : a;
        if (this.api.W().N("autonav_notifications") && a && window.Notification && "function" === typeof document.hasFocus) {
            var b = Notification.permission;
            "default" === b ? Notification.requestPermission() : "granted" !== b || document.hasFocus() || (this.eG(), this.notification = new Notification("Up Next", {
                body: this.suggestion.title,
                icon: this.suggestion.Kg()
            }), this.B = this.T(this.notification, "click", this.M7), this.C.start())
        }
        this.Qr();
        this.api.nextVideo(!1, a)
    };
    g.k.z0 = function(a) {
        !g.sf(this.cancelButton.element, g.WP(a)) && g.oT(a, this.api) && (this.api.Qf() && this.api.ub(this.Ha("ytp-upnext-autoplay-icon")), this.select())
    };
    g.k.y0 = function() {
        this.api.Qf() && this.cancelButton && this.api.ub(this.cancelButton.element);
        g.RS(this.api, !0)
    };
    g.k.D7 = function(a) {
        this.api.getPresentingPlayerType();
        this.show();
        this.AA(a)
    };
    g.k.E7 = function() {
        this.api.getPresentingPlayerType();
        this.Qr();
        this.hide()
    };
    g.k.xa = function() {
        this.Qr();
        this.eG();
        g.X.prototype.xa.call(this)
    };
    g.w(r6, p6);
    g.k = r6.prototype;
    g.k.create = function() {
        p6.prototype.create.call(this);
        this.C.T(this.player, "appresize", this.nB);
        this.C.T(this.player, "onVideoAreaChange", this.nB);
        this.C.T(this.player, "videodatachange", this.onVideoDataChange);
        this.C.T(this.player, "autonavchange", this.OR);
        this.C.T(this.player, "autonavcancel", this.A0);
        this.onVideoDataChange()
    };
    g.k.show = function() {
        p6.prototype.show.call(this);
        (this.J || this.B && this.B !== this.videoData.clientPlaybackNonce) && g.RS(this.player, !1);
        g.YS(this.player) && this.JB() && !this.B ? (s6(this), 2 === this.videoData.autonavState ? 3 === this.player.getVisibilityState() ? this.j.select(!0) : this.j.AA() : 3 === this.videoData.autonavState && this.j.Aw()) : (g.RS(this.player, !0), s6(this));
        this.nB()
    };
    g.k.hide = function() {
        p6.prototype.hide.call(this);
        this.j.Aw();
        s6(this)
    };
    g.k.nB = function() {
        var a = this.player.Uk(!0, this.player.isFullscreen());
        s6(this);
        o6(this.u);
        g.Pq(this.element, "ytp-autonav-cancelled-small-mode", this.lh(a));
        g.Pq(this.element, "ytp-autonav-cancelled-tiny-mode", this.sH(a));
        g.Pq(this.element, "ytp-autonav-cancelled-mini-mode", 400 >= a.width || 360 >= a.height);
        this.overlay && g.Nn(this.overlay.element, {
            width: a.width + "px"
        });
        if (!this.D)
            for (a = 0; a < this.videos.length; a++) g.Pq(this.videos[a].element, "ytp-suggestion-card-with-margin", 1 === a % 2)
    };
    g.k.onVideoDataChange = function() {
        var a = this.player.getVideoData();
        if (this.videoData !== a && a) {
            this.videoData = a;
            if ((a = this.videoData.suggestions) && a.length || this.player.N("web_player_autonav_empty_suggestions_fix")) {
                var b = g.vO(this.videoData);
                b && (this.j.vF(b), this.j !== this.u && this.u.vF(b))
            }
            if (a && a.length)
                for (b = 0; b < rjb.length; ++b) {
                    var c = rjb[b];
                    if (a && a[c]) {
                        this.videos[b] = new m6(this.player);
                        var d = this.videos[b];
                        c = a[c];
                        d.suggestion !== c && (d.suggestion = c, l6(d, c));
                        g.H(this, this.videos[b]);
                        this.videos[b].Ja(this.K.element)
                    }
                }
            this.nB()
        }
    };
    g.k.OR = function(a) {
        1 === a ? (this.J = !1, this.B = this.videoData.clientPlaybackNonce, this.j.Qr(), this.Gb && this.nB()) : (this.J = !0, this.Qf() && (2 === a ? this.j.AA() : 3 === a && this.j.Aw()))
    };
    g.k.A0 = function(a) {
        a ? this.OR(1) : (this.B = null, this.J = !1)
    };
    g.k.JB = function() {
        return 1 !== this.videoData.autonavState
    };
    g.k.lh = function(a) {
        return (910 > a.width || 459 > a.height) && !this.sH(a) && !(400 >= a.width || 360 >= a.height)
    };
    g.k.sH = function(a) {
        return 800 > a.width && !(400 >= a.width || 360 >= a.height)
    };
    g.k.Qf = function() {
        return this.Gb && g.YS(this.player) && this.JB() && !this.B
    };
    var rjb = [1, 3, 2, 4];
    g.w(t6, g.X);
    g.k = t6.prototype;
    g.k.updateButton = function() {
        var a = this.I.getVideoData();
        if (this.I.N("embeds_enable_server_driven_watch_again_on_youtube")) {
            var b, c;
            if (b = (a = null == (b = a.zd) ? void 0 : null == (c = b.playerOverlays) ? void 0 : c.playerOverlayRenderer) && g.S(a.watchOnYoutubeButton, g.YLa)) this.j = b
        }
        if (this.j) this.update({
            content: this.j.title
        }), this.I.uj(this.element) && this.I.Oy(this.element), this.I.cg(this.element, this), this.I.hg(this.element, this.j.trackingParams || null);
        else {
            switch (this.buttonType) {
                case 1:
                    b = "Watch again on YouTube";
                    c = 156915;
                    break;
                case 2:
                    b = "Continue watching on YouTube";
                    c = 156942;
                    break;
                default:
                    b = "Continue watching on YouTube", c = 156942
            }
            this.update({
                content: b
            });
            this.I.uj(this.element) && this.I.Oy(this.element);
            this.I.xb(this.element, this, c)
        }
    };
    g.k.onClick = function(a) {
        this.I.N("web_player_log_click_before_generating_ve_conversion_params") && this.I.ub(this.element);
        this.j ? this.I.Qa("innertubeCommand", g.S(this.j.onTap, g.UQ)) : g.pT(this.getVideoUrl(), this.I, a);
        this.I.N("web_player_log_click_before_generating_ve_conversion_params") || this.I.ub(this.element)
    };
    g.k.getVideoUrl = function() {
        var a = !0;
        switch (this.buttonType) {
            case 1:
                a = !0;
                break;
            case 2:
                a = !1
        }
        a = this.I.getVideoUrl(a, !1, !1, !0);
        var b = this.I.W();
        if (g.AM(b) || g.IM(b)) {
            var c = {};
            g.AM(b) && g.ES(this.I, "addEmbedsConversionTrackingParams", [c]);
            a: {
                switch (this.buttonType) {
                    case 2:
                        b = "emb_ytp_continue_watching";
                        break a
                }
                b = "emb_ytp_watch_again"
            }
            g.xS(c, b);
            a = g.Sj(a, c)
        }
        return a
    };
    g.k.Za = function() {
        this.I.Za(this.element, this.Gb && this.ma)
    };
    g.k.show = function() {
        g.X.prototype.show.call(this);
        this.Za()
    };
    g.k.hide = function() {
        g.X.prototype.hide.call(this);
        this.Za()
    };
    g.k.lc = function(a) {
        g.X.prototype.lc.call(this, a);
        this.Za()
    };
    g.w(u6, p6);
    u6.prototype.show = function() {
        3 !== this.player.getPlayerState() && (p6.prototype.show.call(this), this.j.sA(!0), this.j.Kr(!0), this.I.W().hc || this.j.Jr(!0), this.I.Za(this.element, !0), this.watchButton.lc(!0))
    };
    u6.prototype.hide = function() {
        p6.prototype.hide.call(this);
        this.j.sA(!1);
        this.j.Kr(!1);
        this.j.Jr(!1);
        this.I.Za(this.element, !1);
        this.watchButton.lc(!1)
    };
    g.w(mjb, p6);
    mjb.prototype.Sa = function() {
        var a = this.player.getVideoData();
        this.j.update({
            profilePicture: a.profilePicture,
            author: a.author
        });
        this.subscribeButton.channelId = a.Ek;
        var b = this.subscribeButton;
        a.subscribed ? b.j() : b.u()
    };
    g.w(v6, g.X);
    v6.prototype.select = function() {
        this.api.uo(this.suggestion.videoId, this.suggestion.sessionData, this.suggestion.playlistId, void 0, void 0, this.suggestion.fC || void 0) && this.api.ub(this.element)
    };
    v6.prototype.onClick = function(a) {
        if (g.AM(this.api.W()) && this.api.N("web_player_log_click_before_generating_ve_conversion_params")) {
            this.api.ub(this.element);
            var b = this.suggestion.Vk(),
                c = {};
            g.iLa(this.api, c, "emb_rel_end");
            b = g.Sj(b, c);
            g.pT(b, this.api, a)
        } else g.oT(a, this.api, this.u, this.suggestion.sessionData || void 0) && this.select()
    };
    v6.prototype.onKeyPress = function(a) {
        switch (a.keyCode) {
            case 13:
            case 32:
                g.XP(a) || (this.select(), g.YP(a))
        }
    };
    v6.prototype.onVideoDataChange = function() {
        var a = this.api.getVideoData(),
            b = this.api.W();
        this.u = a.Ed ? !1 : b.C
    };
    g.w(w6, p6);
    g.k = w6.prototype;
    g.k.create = function() {
        p6.prototype.create.call(this);
        var a = this.player.getVideoData();
        a && (this.videoData = a);
        this.Zp();
        this.u.T(this.player, "appresize", this.Zp);
        this.u.T(this.player, "onVideoAreaChange", this.Zp);
        this.u.T(this.player, "videodatachange", this.onVideoDataChange);
        this.u.T(this.player, "autonavchange", this.gK);
        this.u.T(this.player, "autonavcancel", this.B0);
        a = this.videoData.autonavState;
        a !== this.V && this.gK(a);
        this.u.T(this.element, "transitionend", this.a9)
    };
    g.k.destroy = function() {
        g.hB(this.u);
        g.sb(this.stills);
        this.stills = [];
        p6.prototype.destroy.call(this);
        g.Nq(this.element, "ytp-show-tiles");
        this.J.stop();
        this.V = this.videoData.autonavState
    };
    g.k.JB = function() {
        return 1 !== this.videoData.autonavState
    };
    g.k.show = function() {
        var a = this.Gb;
        p6.prototype.show.call(this);
        g.Nq(this.element, "ytp-show-tiles");
        this.player.W().u ? g.Fq(this.J) : this.J.start();
        (this.D || this.C && this.C !== this.videoData.clientPlaybackNonce) && g.RS(this.player, !1);
        x6(this) ? (y6(this), 2 === this.videoData.autonavState ? 3 === this.player.getVisibilityState() ? this.j.select(!0) : this.j.AA() : 3 === this.videoData.autonavState && this.j.Aw()) : (g.RS(this.player, !0), y6(this));
        a !== this.Gb && this.player.Za(this.element, !0)
    };
    g.k.hide = function() {
        var a = this.Gb;
        p6.prototype.hide.call(this);
        this.j.Aw();
        y6(this);
        a !== this.Gb && this.player.Za(this.element, !1)
    };
    g.k.a9 = function(a) {
        g.WP(a) === this.element && this.Zp()
    };
    g.k.Zp = function() {
        var a, b, c, d;
        var e = (null == (a = this.videoData) ? 0 : null == (b = a.suggestions) ? 0 : b.length) ? null == (c = this.videoData) ? void 0 : c.suggestions : [null == (d = this.videoData) ? void 0 : g.vO(d)];
        if (e.length) {
            g.Lq(this.element, "ytp-endscreen-paginate");
            var f = this.I.Uk(!0, this.I.isFullscreen());
            if (a = g.GS(this.I)) a = a.Mg() ? 48 : 32, f.width -= 2 * a;
            var h = f.width / f.height;
            d = 96 / 54;
            b = a = 2;
            var l = Math.max(f.width / 96, 2),
                m = Math.max(f.height / 54, 2);
            c = e.length;
            var n = Math.pow(2, 2);
            var p = c * n + (Math.pow(2, 2) - n);
            p += Math.pow(2, 2) -
                n;
            for (p -= n; 0 < p && (a < l || b < m);) {
                var q = a / 2,
                    r = b / 2,
                    v = a <= l - 2 && p >= r * n,
                    y = b <= m - 2 && p >= q * n;
                if ((q + 1) / r * d / h > h / (q / (r + 1) * d) && y) p -= q * n, b += 2;
                else if (v) p -= r * n, a += 2;
                else if (y) p -= q * n, b += 2;
                else break
            }
            d = !1;
            p >= 3 * n && 6 >= c * n - p && (4 <= b || 4 <= a) && (d = !0);
            n = 96 * a;
            p = 54 * b;
            h = n / p < h ? f.height / p : f.width / n;
            h = Math.min(h, 2);
            n = Math.floor(Math.min(f.width, n * h));
            p = Math.floor(Math.min(f.height, p * h));
            f = this.table.element;
            f.ariaLive = "polite";
            g.lo(f, n, p);
            g.Nn(f, {
                marginLeft: n / -2 + "px",
                marginTop: p / -2 + "px"
            });
            this.j.vF(g.vO(this.videoData));
            this.j instanceof
            n6 && o6(this.j);
            g.Pq(this.element, "ytp-endscreen-takeover", x6(this));
            y6(this);
            n += 4;
            p += 4;
            h = 0;
            f.ariaBusy = "true";
            for (l = 0; l < a; l++)
                for (m = 0; m < b; m++)
                    if (q = h, v = 0, d && l >= a - 2 && m >= b - 2 ? v = 1 : 0 === m % 2 && 0 === l % 2 && (2 > m && 2 > l ? 0 === m && 0 === l && (v = 2) : v = 2), q = g.re(q + this.B, c), 0 !== v) {
                        r = this.stills[h];
                        r || (r = new v6(this.player), this.stills[h] = r, f.appendChild(r.element));
                        y = Math.floor(p * m / b);
                        var A = Math.floor(n * l / a),
                            F = Math.floor(p * (m + v) / b) - y - 4,
                            M = Math.floor(n * (l + v) / a) - A - 4;
                        g.Tn(r.element, A, y);
                        g.lo(r.element, M, F);
                        g.Nn(r.element, "transitionDelay",
                            (m + l) / 20 + "s");
                        g.Pq(r.element, "ytp-videowall-still-mini", 1 === v);
                        g.Pq(r.element, "ytp-videowall-still-large", 2 < v);
                        v = Math.max(M, F);
                        g.Pq(r.element, "ytp-videowall-still-round-large", 256 <= v);
                        g.Pq(r.element, "ytp-videowall-still-round-medium", 96 < v && 256 > v);
                        g.Pq(r.element, "ytp-videowall-still-round-small", 96 >= v);
                        q = e[q];
                        r.suggestion !== q && (r.suggestion = q, v = r.api.W(), y = g.Kq(r.element, "ytp-videowall-still-large") ? "hqdefault.jpg" : "mqdefault.jpg", l6(r, q, y), g.AM(v) && !r.api.N("web_player_log_click_before_generating_ve_conversion_params") &&
                            (v = q.Vk(), y = {}, g.ES(r.api, "addEmbedsConversionTrackingParams", [y]), v = g.Sj(v, g.xS(y, "emb_rel_end")), r.updateValue("url", v)), (q = (q = q.sessionData) && q.itct) && r.api.hg(r.element, q));
                        h++
                    }
            f.ariaBusy = "false";
            g.Pq(this.element, "ytp-endscreen-paginate", h < c);
            for (e = this.stills.length - 1; e >= h; e--) a = this.stills[e], g.qf(a.element), g.rb(a);
            this.stills.length = h
        }
    };
    g.k.onVideoDataChange = function() {
        var a = this.player.getVideoData();
        this.videoData !== a && (this.B = 0, this.videoData = a, this.Zp())
    };
    g.k.C0 = function() {
        this.B += this.stills.length;
        this.Zp()
    };
    g.k.D0 = function() {
        this.B -= this.stills.length;
        this.Zp()
    };
    g.k.tW = function() {
        return this.j.Yk()
    };
    g.k.gK = function(a) {
        1 === a ? (this.D = !1, this.C = this.videoData.clientPlaybackNonce, this.j.Qr(), this.Gb && this.Zp()) : (this.D = !0, this.Gb && x6(this) && (2 === a ? this.j.AA() : 3 === a && this.j.Aw()))
    };
    g.k.B0 = function(a) {
        if (a) {
            for (a = 0; a < this.stills.length; a++) this.I.Za(this.stills[a].element, !0);
            this.gK(1)
        } else this.C = null, this.D = !1;
        this.Zp()
    };
    g.k.Qf = function() {
        return this.Gb && x6(this)
    };
    g.w(z6, p6);
    z6.prototype.show = function() {
        if (3 !== this.player.getPlayerState()) {
            p6.prototype.show.call(this);
            var a = this.u;
            if (a) {
                var b = 0 < this.j.suggestionData.length;
                g.Pq(this.element, "ytp-shorts-branded-ui", b);
                b ? a.show() : a.hide()
            }
            var c;
            null == (c = g.GS(this.player)) || c.JE(!0);
            this.player.Za(this.element, !0);
            this.watchButton.lc(!0)
        }
    };
    z6.prototype.hide = function() {
        p6.prototype.hide.call(this);
        var a;
        null == (a = g.GS(this.player)) || a.JE(!1);
        this.player.Za(this.element, !1);
        this.watchButton.lc(!1)
    };
    g.w(qjb, g.VT);
    g.k = qjb.prototype;
    g.k.Nw = function() {
        var a = this.player.getVideoData(),
            b = a.mutedAutoplay;
        if ((g.US(this.player) || this.u) && !b) return !0;
        var c;
        var d = !!((null == a ? 0 : g.vO(a)) || (null == a ? 0 : null == (c = a.suggestions) ? 0 : c.length));
        d = !njb(this.player) || d;
        a = a.Aj || g.IM(a.Ia);
        c = this.player.rC();
        return d && !a && !c && !b
    };
    g.k.Qf = function() {
        return this.endScreen.Qf()
    };
    g.k.H5 = function() {
        return this.Qf() ? this.endScreen.tW() : !1
    };
    g.k.xa = function() {
        this.player.Te("endscreen");
        g.VT.prototype.xa.call(this)
    };
    g.k.load = function() {
        var a = this.player.getVideoData();
        var b = a.transitionEndpointAtEndOfStream;
        if (b && b.videoId) {
            var c = this.player.Fb().Se.get("heartbeat"),
                d = g.vO(a);
            !d || b.videoId !== d.videoId || a.x_ ? (this.player.uo(b.videoId, void 0, void 0, !0, !0, b), c && c.BH("HEARTBEAT_ACTION_TRIGGER_AT_STREAM_END", "HEARTBEAT_ACTION_TRANSITION_REASON_HAS_NEW_STREAM_TRANSITION_ENDPOINT"), a = !0) : a = !1
        } else a = !1;
        a || (g.VT.prototype.load.call(this), this.endScreen.show())
    };
    g.k.unload = function() {
        g.VT.prototype.unload.call(this);
        this.endScreen.hide();
        this.endScreen.destroy()
    };
    g.k.onCueRangeEnter = function(a) {
        this.Nw() && (this.endScreen.created || this.endScreen.create(), "load" === a.getId() && this.load())
    };
    g.k.onCueRangeExit = function(a) {
        "load" === a.getId() && this.loaded && this.unload()
    };
    g.k.onVideoDataChange = function() {
        pjb(this);
        this.C && ojb(this) && (this.endScreen && (this.endScreen.hide(), this.endScreen.created && this.endScreen.destroy(), this.endScreen.dispose()), this.j ? this.endScreen = new r6(this.player) : this.endScreen = new w6(this.player), g.H(this, this.endScreen), g.XS(this.player, this.endScreen.element, 4))
    };
    g.UT("endscreen", qjb);
})(_yt_player);