(function(g) {
    var window = this;
    'use strict';
    var H4 = function(a) {
            a.ra("cardstatechange", a.Lk() && a.Ro() ? 1 : 0)
        },
        I4 = function(a, b) {
            var c = g.Wa(b),
                d = c ? b : arguments;
            for (c = c ? 0 : 1; c < d.length; c++) {
                if (null == a) return;
                a = a[d[c]]
            }
            return a
        },
        lfb = function(a) {
            var b = g.Vn(a);
            a = g.mo(a);
            return new g.Kn(b.x, b.y, a.width, a.height)
        },
        L4 = function(a) {
            a = g.ab(a);
            delete J4[a];
            g.kd(J4) && K4 && K4.stop()
        },
        nfb = function() {
            K4 || (K4 = new g.Dq(function() {
                mfb()
            }, 20));
            var a = K4;
            a.isActive() || a.start()
        },
        mfb = function() {
            var a = g.eb();
            g.Zc(J4, function(b) {
                ofb(b, a)
            });
            g.kd(J4) || nfb()
        },
        M4 = function(a, b, c, d) {
            g.Xq.call(this);
            if (!Array.isArray(a) || !Array.isArray(b)) throw Error("Start and end parameters must be arrays");
            if (a.length != b.length) throw Error("Start and end points must be the same length");
            this.u = a;
            this.K = b;
            this.duration = c;
            this.D = d;
            this.coords = [];
            this.progress = this.J = 0;
            this.C = null
        },
        ofb = function(a, b) {
            b < a.startTime && (a.endTime = b + a.endTime - a.startTime, a.startTime = b);
            a.progress = (b - a.startTime) / (a.endTime - a.startTime);
            1 < a.progress && (a.progress = 1);
            a.J = 1E3 / (b - a.C);
            a.C = b;
            pfb(a, a.progress);
            1 == a.progress ? (a.j = 0, L4(a), a.onFinish(), a.rr()) : a.rd() && a.cK()
        },
        pfb = function(a, b) {
            "function" === typeof a.D && (b = a.D(b));
            a.coords = Array(a.u.length);
            for (var c = 0; c < a.u.length; c++) a.coords[c] = (a.K[c] - a.u[c]) * b + a.u[c]
        },
        qfb = function(a, b) {
            g.zb.call(this, a);
            this.coords = b.coords;
            this.x = b.coords[0];
            this.y = b.coords[1];
            this.z = b.coords[2];
            this.duration = b.duration;
            this.progress = b.progress;
            this.fps = b.J;
            this.state = b.j
        },
        N4 = function(a, b, c, d, e) {
            M4.call(this, b, c, d, e);
            this.element = a
        },
        rfb = function(a, b, c, d, e) {
            if (2 != b.length || 2 != c.length) throw Error("Start and end points must be 2D");
            N4.call(this, a, b, c, d, e)
        },
        sfb = function(a) {
            return Math.pow(a, 3)
        },
        tfb = function(a) {
            return 3 * a * a - 2 * a * a * a
        },
        ufb = function(a) {
            g.D.call(this);
            this.u = a || window;
            this.j = []
        },
        O4 = function(a) {
            return a.baseUrl || null
        },
        P4 = function(a, b) {
            return g.Wo(g.cn(a, b), function(c) {
                return !!c
            })
        },
        vfb = function(a, b, c) {
            function d(aa) {
                var ma = aa.hovercardButton;
                if (!ma) return null;
                ma = ma.subscribeButtonRenderer;
                if (!ma) return null;
                var ca = f(ma.unsubscribedButtonText),
                    Da = f(ma.subscribedButtonText);
                if (ma.subscribed) {
                    var W = f(ma.subscriberCountWithUnsubscribeText);
                    var Ua = f(ma.subscriberCountText)
                } else W = f(ma.subscriberCountText), Ua = f(ma.subscriberCountWithSubscribeText);
                var t = null;
                if (aa.signinEndpoint) {
                    t = I4(aa, "signinEndpoint", "webNavigationEndpointData", "url");
                    if (!t) {
                        var Q, jb;
                        t = null == (jb = g.S(null == (Q = ma.signInEndpoint) ? void 0 : Q.commandMetadata, g.A3)) ? void 0 : jb.url
                    }
                    if (!t) return null
                }
                return ca &&
                    (Da || t) ? {
                        subscribed: ma.subscribed,
                        subscribeText: ca,
                        subscribeCount: W,
                        unsubscribeText: Da,
                        unsubscribeCount: Ua,
                        enabled: ma.enabled,
                        signinUrl: t,
                        classic: aa.useClassicSubscribeButton
                    } : null
            }

            function e(aa) {
                if (aa) {
                    var ma = [],
                        ca = aa.videoId;
                    ca && ma.push("v=" + ca);
                    (ca = aa.playlistId) && ma.push("list=" + ca);
                    (aa = aa.startTimeSeconds) && ma.push("t=" + aa);
                    return "/watch?" + ma.join("&")
                }
            }

            function f(aa) {
                if (!aa) return null;
                var ma = aa.simpleText;
                return ma ? ma : aa.runs ? g.cn(aa.runs, function(ca) {
                    return ca.text
                }).join("") : null
            }
            b = b.endscreenElementRenderer;
            if (!b) return null;
            var h = b.style,
                l = b.endpoint || {},
                m = null,
                n = null,
                p = !1,
                q = null,
                r = null,
                v = null,
                y = null,
                A = !1,
                F = null,
                M = null,
                J = null,
                G = null,
                U = null,
                Y = null;
            if ("VIDEO" === h) g.S(l, g.uO) ? m = g.S(l, g.uO).url : (Y = g.S(l, g.tO), m = e(Y)), n = !1, q = a, b.thumbnailOverlays ? (p = b.thumbnailOverlays[0].thumbnailOverlayTimeStatusRenderer, r = f(p.text), p = "LIVE" === p.style) : r = f(b.videoDuration);
            else if ("PLAYLIST" === h) g.S(l, g.uO) ? m = g.S(l, g.uO).url : (Y = g.S(l, g.tO), m = e(Y)), n = !1, q = a, v = f(b.playlistLength);
            else if ("CHANNEL" ===
                h) {
                if (A = I4(l, "browseEndpoint", "browseId")) y = A, m = "/channel/" + y;
                n = !1;
                q = "new";
                (A = !!b.isSubscribe) ? F = d(b): M = f(b.subscribersText)
            } else "WEBSITE" === h ? ((J = I4(l, "urlEndpoint", "url")) && (m = J), n = !0, q = "new", J = b.icon.thumbnails[0].url) : "CREATOR_MERCHANDISE" === h && (b.productPrice && (G = f(b.productPrice)), b.additionalFeesText && (U = f(b.additionalFeesText)), (n = I4(l, "urlEndpoint", "url")) && (m = n), n = !0, q = "new");
            a = I4(b, "title", "accessibility", "accessibilityData", "label");
            var ka = b.endpoint ? b.endpoint.clickTrackingParams : null,
                ua = "";
            if (b.metadata) {
                var oa = f(b.metadata);
                oa && (ua = oa)
            }
            return {
                id: "element-" + c,
                type: h,
                title: f(b.title),
                metadata: ua,
                callToAction: f(b.callToAction),
                FU: b.image,
                iconUrl: J,
                left: Number(b.left),
                width: Number(b.width),
                top: Number(b.top),
                aspectRatio: Number(b.aspectRatio),
                startMs: Math.floor(Number(b.startMs)),
                endMs: Math.floor(Number(b.endMs)),
                videoDuration: r,
                cD: p,
                playlistLength: v,
                channelId: y,
                subscribeButton: F,
                subscribersText: M,
                isSubscribe: A,
                wu: m || null,
                K5: n,
                sessionData: ka ? {
                    itct: ka
                } : null,
                C$: q,
                EB: a ? a : null,
                isPlaceholder: b.isPlaceholder,
                impressionUrls: P4(b.impressionUrls || [], O4),
                z5: P4(b.hovercardShowUrls || [], O4),
                clickUrls: P4(l.loggingUrls || [], O4),
                visualElement: g.jH(b.trackingParams),
                productPrice: G,
                additionalFeesText: U,
                watchEndpoint: Y || null
            }
        },
        wfb = function(a, b) {
            var c = {
                startMs: Math.floor(Number(a.startMs)),
                impressionUrls: P4(a.impressionUrls || [], O4),
                elements: P4(a.elements || [], function(d, e) {
                    return vfb(b, d, e)
                })
            };
            a.trackingParams && (c.visualElement = g.jH(a.trackingParams));
            return c
        },
        xfb = function(a) {
            g.VT.call(this, a);
            this.B = this.endscreen = null;
            this.j = {};
            this.D = {};
            this.C = this.u = null;
            this.K = [];
            this.ma = !0;
            this.J = 0;
            a = a.W();
            this.V = g.FM(a) || "profilepage" === a.Na;
            this.events = new g.LK(this);
            g.H(this, this.events);
            this.events.T(this.player, g.JG("creatorendscreen"), this.onCueRangeEnter);
            this.events.T(this.player, g.KG("creatorendscreen"), this.onCueRangeExit);
            this.events.T(this.player, "resize", this.Kb);
            this.events.T(window, "focus", this.j9);
            this.load();
            var b = g.cf("STYLE");
            (g.Le("HEAD")[0] || document.body).appendChild(b);
            g.tb(this,
                function() {
                    g.qf(b)
                });
            b.sheet && (b.sheet.insertRule(".ytp-ce-playlist-icon {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASBAMAAACk4JNkAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAIVBMVEVMaXGzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7P///91E4wTAAAACXRSTlMArBbpVOtYrReN+x2FAAAAAWJLR0QKaND0VgAAACFJREFUCNdjYCAWzIQAFBaZ6hgVYLKcJnBWGEyWvYGASwCXtBf7m4i3CQAAAABJRU5ErkJggg==) no-repeat center;background-size:18px;width:18px;height:18px}", 0), b.sheet.insertRule(".ytp-ce-size-853 .ytp-ce-playlist-icon, .ytp-ce-size-1280 .ytp-ce-playlist-icon, .ytp-ce-size-1920 .ytp-ce-playlist-icon {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYBAMAAAASWSDLAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAJ1BMVEVMaXGzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7P///9RfzIKAAAAC3RSTlMAvDeyLvxYtDK9Ogx4T1QAAAABYktHRAyBs1FjAAAAK0lEQVQY02NgoBjshgO8HJoYwKiAMGAD92YHJM7uMCTO9gaEHs4FlPuZAQC8Fj8x/xHjxwAAAABJRU5ErkJggg==) no-repeat center;background-size:24px;width:24px;height:24px}",
                0))
        },
        yfb = function(a) {
            return a.player.getVideoData().Ed ? "current" : a.V ? "new" : "current"
        },
        Q4 = function(a) {
            return "creator-endscreen-editor" === a.player.W().playerStyle
        },
        zfb = function(a) {
            var b = a.player.getVideoData(),
                c = b.videoId;
            a.B && a.B.abort();
            c = {
                method: "POST",
                onFinish: function(e) {
                    var f = a.B = null;
                    200 === e.status && (e = e.responseText, ")]}" === e.substring(0, 3) && (e = e.substring(3), f = JSON.parse(e), f = wfb(f, yfb(a))));
                    R4(a, f)
                },
                urlParams: {
                    v: c
                },
                withCredentials: !0
            };
            a.V && (c.urlParams.ptype = "embedded");
            var d = b.tx;
            d && (c.postParams = {
                ad_tracking: d
            });
            if (b = g.Mza(b))
                if (b = g.ge(b), b = g.ae(b)) a.B = g.bA(b, c)
        },
        R4 = function(a, b, c) {
            c = void 0 === c ? !0 : c;
            a.player.Te("creatorendscreen");
            a.u && (a.u.dispose(), a.u = null, a.C.dispose(), a.C = null);
            for (var d = g.u(Object.values(a.j)), e = d.next(); !e.done; e = d.next()) e.value.dispose();
            a.j = {};
            a.D = {};
            0 < a.K.length && (a.K.forEach(function(l) {
                l.dispose()
            }), a.K.length = 0);
            a.J = 0;
            if ((a.endscreen = b) && b.elements) {
                c && Afb(a);
                c = [];
                d = new g.HG(b.startMs, 0x7ffffffffffff, {
                    id: "ytp-ce-in-endscreen",
                    namespace: "creatorendscreen"
                });
                c.push(d);
                a.player.W().u || (a.u = new g.X({
                    G: "div",
                    S: "ytp-ce-shadow"
                }), g.XS(a.player, a.u.element, 4), a.C = new g.yR(a.u, 200));
                for (d = 0; d < b.elements.length; ++d) {
                    e = b.elements[d];
                    var f = Bfb(a, e);
                    if (f) {
                        a.j[e.id] = f;
                        a.D[e.id] = e;
                        g.XS(a.player, f.element, 4);
                        var h = new g.HG(e.startMs, e.endMs, {
                            id: "ytp-ce-element-" + e.id,
                            namespace: "creatorendscreen"
                        });
                        c.push(h);
                        Cfb(a, f, e)
                    } else g.nG(new g.yB("buildEndscreenElement null",
                        e))
                }
                a.player.hf(c);
                a.Kb()
            }
        },
        Afb = function(a) {
            var b = g.lH(),
                c = g.mH();
            c && b && a.endscreen.visualElement && g.Hz(g.kQ)(void 0, c, b, a.endscreen.visualElement)
        },
        Bfb = function(a, b) {
            var c = null;
            switch (b.type) {
                case "VIDEO":
                    a = {
                        G: "div",
                        Ma: ["ytp-ce-element", "ytp-ce-video"],
                        Y: {
                            tabindex: "0",
                            "aria-label": b.EB || "",
                            "aria-hidden": "true"
                        },
                        X: [{
                            G: "div",
                            S: "ytp-ce-element-shadow"
                        }, {
                            G: "div",
                            S: "ytp-ce-covering-image",
                            Y: S4(b)
                        }, {
                            G: "div",
                            S: "ytp-ce-covering-shadow-top"
                        }, {
                            G: "a",
                            S: "ytp-ce-covering-overlay",
                            Y: {
                                href: T4(a, b.wu),
                                tabindex: "-1"
                            },
                            X: [{
                                G: "div",
                                Ma: ["ytp-ce-video-title", "ytp-webkit-ellipsis"],
                                Y: {
                                    dir: g.ar(b.title || "")
                                },
                                Aa: b.title
                            }, {
                                G: "div",
                                S: b.cD ? "ytp-ce-live-video-duration" : "ytp-ce-video-duration",
                                Aa: b.videoDuration ||
                                    void 0
                            }]
                        }]
                    };
                    c = new g.X(a);
                    break;
                case "PLAYLIST":
                    a = {
                        G: "div",
                        Ma: ["ytp-ce-element", "ytp-ce-playlist"],
                        Y: {
                            tabindex: "0",
                            "aria-label": b.EB || "",
                            "aria-hidden": "true"
                        },
                        X: [{
                            G: "div",
                            S: "ytp-ce-element-shadow"
                        }, {
                            G: "div",
                            S: "ytp-ce-covering-image",
                            Y: S4(b)
                        }, {
                            G: "div",
                            S: "ytp-ce-covering-shadow-top"
                        }, {
                            G: "a",
                            S: "ytp-ce-covering-overlay",
                            Y: {
                                href: T4(a, b.wu),
                                tabindex: "-1"
                            },
                            X: [{
                                G: "div",
                                Ma: ["ytp-ce-playlist-title", "ytp-webkit-ellipsis"],
                                Y: {
                                    dir: g.ar(b.title || "")
                                },
                                Aa: b.title
                            }, {
                                G: "div",
                                S: "ytp-ce-playlist-count",
                                X: [{
                                        G: "div",
                                        S: "ytp-ce-playlist-icon"
                                    },
                                    {
                                        G: "div",
                                        S: "ytp-ce-playlist-count-text",
                                        Aa: b.playlistLength || void 0
                                    }
                                ]
                            }]
                        }]
                    };
                    c = new g.X(a);
                    break;
                case "CHANNEL":
                    c = {
                        G: "div",
                        Ma: ["ytp-ce-element", "ytp-ce-channel", b.isSubscribe ? "ytp-ce-channel-this" : "ytp-ce-channel-that"],
                        Y: {
                            tabindex: "0",
                            "aria-label": b.EB || "",
                            "aria-hidden": "true"
                        },
                        X: [{
                            G: "div",
                            S: "ytp-ce-element-shadow"
                        }, {
                            G: "div",
                            S: "ytp-ce-expanding-overlay",
                            X: [{
                                G: "div",
                                S: "ytp-ce-expanding-overlay-hider"
                            }, {
                                G: "div",
                                S: "ytp-ce-expanding-overlay-background"
                            }, {
                                G: "div",
                                S: "ytp-ce-expanding-overlay-content",
                                X: [{
                                    G: "div",
                                    S: "ytp-ce-expanding-overlay-body",
                                    X: [{
                                        G: "div",
                                        S: "ytp-ce-expanding-overlay-body-padding",
                                        X: [{
                                            G: "a",
                                            Ma: ["ytp-ce-channel-title", "ytp-ce-link"],
                                            Y: {
                                                href: T4(a, b.wu),
                                                target: "_blank",
                                                tabindex: "-1",
                                                dir: g.ar(b.title || "")
                                            },
                                            Aa: b.title
                                        }, b.subscribeButton ? {
                                            G: "div",
                                            S: "ytp-ce-subscribe-container",
                                            X: [{
                                                G: "div",
                                                S: "ytp-ce-channel-subscribe"
                                            }]
                                        } : "", b.subscribersText ? {
                                            G: "div",
                                            S: "ytp-ce-channel-subscribers-text",
                                            Aa: b.subscribersText
                                        } : "", b.metadata ? {
                                            G: "div",
                                            Ma: ["ytp-ce-channel-metadata", "yt-ui-ellipsis", "yt-ui-ellipsis-3"],
                                            Aa: b.metadata
                                        } : ""]
                                    }]
                                }]
                            }]
                        }, {
                            G: "div",
                            S: "ytp-ce-expanding-image",
                            Y: S4(b)
                        }]
                    };
                    c = new g.X(c);
                    var d = g.Me(document, "div", "ytp-ce-channel-subscribe", c.element)[0];
                    if (b.subscribeButton && b.channelId) {
                        g.Lq(d, "ytp-ce-subscribe-button");
                        if (a.player.W().u) {
                            var e = null;
                            var f = b.sessionData.itct
                        } else e = "endscreen", f = null;
                        e = new g.JU(b.subscribeButton.subscribeText, b.subscribeButton.subscribeCount, b.subscribeButton.unsubscribeText, b.subscribeButton.unsubscribeCount, !!b.subscribeButton.enabled, !!b.subscribeButton.classic,
                            b.channelId, !!b.subscribeButton.subscribed, e, f, a.player);
                        d.appendChild(e.element);
                        a.K.push(e)
                    }
                    break;
                case "WEBSITE":
                    a = {
                        G: "div",
                        Ma: ["ytp-ce-element", "ytp-ce-website"],
                        Y: {
                            tabindex: "0",
                            "aria-label": b.EB || "",
                            "aria-hidden": "true"
                        },
                        X: [{
                            G: "div",
                            S: "ytp-ce-element-shadow"
                        }, {
                            G: "div",
                            S: "ytp-ce-expanding-overlay",
                            X: [{
                                G: "div",
                                S: "ytp-ce-expanding-overlay-hider"
                            }, {
                                G: "div",
                                S: "ytp-ce-expanding-overlay-background"
                            }, {
                                G: "div",
                                S: "ytp-ce-expanding-overlay-content",
                                X: [{
                                    G: "div",
                                    S: "ytp-ce-expanding-overlay-body",
                                    X: [{
                                        G: "div",
                                        S: "ytp-ce-expanding-overlay-body-padding",
                                        X: [{
                                            G: "div",
                                            S: "ytp-ce-website-title",
                                            Y: {
                                                dir: g.ar(b.title || "")
                                            },
                                            Aa: b.title
                                        }, {
                                            G: "div",
                                            S: "ytp-ce-website-metadata",
                                            Aa: b.metadata
                                        }, {
                                            G: "a",
                                            Ma: ["ytp-ce-website-goto", "ytp-ce-link"],
                                            Y: {
                                                href: T4(a, b.wu),
                                                target: "_blank",
                                                tabindex: "-1"
                                            },
                                            Aa: b.callToAction
                                        }]
                                    }]
                                }]
                            }]
                        }, {
                            G: "div",
                            S: "ytp-ce-expanding-image",
                            Y: S4(b)
                        }, {
                            G: "div",
                            S: "ytp-ce-expanding-icon",
                            Y: Dfb(b.iconUrl)
                        }]
                    };
                    c = new g.X(a);
                    break;
                case "CREATOR_MERCHANDISE":
                    c = "", b.productPrice && (c = {
                        G: "div",
                        S: "ytp-ce-merchandise-price-container",
                        X: [{
                            G: "div",
                            S: "ytp-ce-merchandise-price",
                            Aa: b.productPrice
                        }]
                    }, b.additionalFeesText && c.X.push({
                        G: "div",
                        S: "ytp-ce-merchandise-additional-fees",
                        Aa: b.additionalFeesText
                    })), a = {
                        G: "div",
                        Ma: ["ytp-ce-element", "ytp-ce-merchandise"],
                        Y: {
                            tabindex: "0",
                            "aria-label": b.EB || "",
                            "aria-hidden": "true"
                        },
                        X: [{
                            G: "div",
                            S: "ytp-ce-element-shadow"
                        }, {
                            G: "div",
                            S: "ytp-ce-expanding-overlay",
                            X: [{
                                G: "div",
                                S: "ytp-ce-expanding-overlay-hider"
                            }, {
                                G: "div",
                                S: "ytp-ce-expanding-overlay-background"
                            }, {
                                G: "div",
                                S: "ytp-ce-expanding-overlay-content",
                                X: [{
                                    G: "div",
                                    S: "ytp-ce-expanding-overlay-body",
                                    X: [{
                                        G: "div",
                                        S: "ytp-ce-expanding-overlay-body-padding",
                                        X: [{
                                            G: "div",
                                            S: "ytp-ce-merchandise-title",
                                            Y: {
                                                dir: g.ar(b.title || "")
                                            },
                                            Aa: b.title
                                        }, c, {
                                            G: "div",
                                            S: "ytp-ce-merchandise-metadata",
                                            Aa: b.metadata
                                        }, {
                                            G: "a",
                                            Ma: ["ytp-ce-merchandise-goto", "ytp-ce-link"],
                                            Y: {
                                                href: T4(a, b.wu),
                                                target: "_blank",
                                                tabindex: "-1"
                                            },
                                            Aa: b.callToAction
                                        }]
                                    }]
                                }]
                            }]
                        }, {
                            G: "div",
                            S: "ytp-ce-expanding-image",
                            Y: S4(b)
                        }, {
                            G: "div",
                            S: "ytp-ce-merchandise-invideo-cta-container",
                            X: [{
                                G: "div",
                                S: "ytp-ce-merchandise-invideo-cta",
                                Aa: b.callToAction || void 0
                            }]
                        }]
                    }, c = new g.X(a)
            }
            b.isPlaceholder && g.Lq(c.element, "ytp-ce-placeholder");
            return c
        },
        S4 = function(a) {
            if (a.FU) var b = a.FU.thumbnails;
            return Dfb(b ? b[b.length - 1].url : null)
        },
        Dfb = function(a) {
            return a ? {
                style: "background-image: url(" + a + ")"
            } : {}
        },
        Cfb = function(a, b, c) {
            function d(m) {
                m && (b.Ta("blur", function() {
                    "none" != m.style.display && a.ma && m.focus()
                }), b.T(m, "focus", f), b.T(m, "blur", h))
            }

            function e(m) {
                a.J += m;
                0 < a.J ? (g.Lq(b.element, "ytp-ce-force-expand"), U4(a, c.id, !0)) : (g.Nq(b.element, "ytp-ce-force-expand"), g.Nq(b.element, "ytp-ce-element-hover"), U4(a, c.id, !1))
            }

            function f() {
                e(1)
            }

            function h() {
                e(-1)
            }
            b.Ta("mouseenter", function() {
                Efb(a, b, c)
            });
            b.Ta("mouseleave", function() {
                Ffb(a, b, c)
            });
            a.player.W().u || b.Ta("click", function() {
                g.Lq(b.element, "ytp-ce-element-hover")
            });
            b.Ta("click", function(m) {
                Gfb(a, c, m)
            });
            b.Ta("keypress", function(m) {
                Gfb(a, c, m)
            });
            b.Ta("focus", function() {
                Efb(a, b, c)
            });
            b.Ta("blur", function() {
                Ffb(a, b, c)
            });
            b.Ta("touchstart", function() {
                Efb(a, b, c)
            });
            var l = g.Xe("ytp-ce-expanding-overlay-hider", b.element);
            l && b.T(l, "touchstart", function(m) {
                g.TP ? m.stopPropagation() : (m = m || window.event, m.cancelBubble = !0, m.stopPropagation && m.stopPropagation());
                g.Nq(b.element, "ytp-ce-element-hover");
                g.Nq(b.element, "ytp-ce-force-expand")
            });
            b.Ta("keydown", function(m) {
                a.ma = 9 === m.keyCode && !m.shiftKey
            });
            d(g.Xe("ytp-sb-subscribe", b.element));
            d(g.Xe("ytp-sb-unsubscribe", b.element));
            b.Ta("focus", f);
            b.Ta("blur", h)
        },
        Gfb = function(a, b, c) {
            if (b.wu && (!c || "keypress" !== c.type || 13 === c.keyCode)) {
                for (var d = c.target; d && !g.Kq(d, "ytp-ce-element");) {
                    g.Kq(d, "subscribe-label") && Hfb(a, b);
                    if (g.Kq(d, "ytp-ce-channel-subscribe")) return;
                    d = g.rf(d)
                }
                if (!d || g.Kq(d, "ytp-ce-element-hover")) {
                    c.preventDefault();
                    c.stopPropagation();
                    if (d = a.j[b.id]) Ffb(a, d, b), d.element.blur();
                    if (c.ctrlKey || c.metaKey || "new" === b.C$) Hfb(a, b), a.player.sendVideoStatsEngageEvent(17, void 0), a.player.pauseVideo(), c = g.ge(T4(a, b.wu)), g.vP(g.ae(c), void 0, b.sessionData);
                    else {
                        var e = g.TM(a.player.W()) || a.player.getVideoData().Ed,
                            f = function() {
                                var h = T4(a, b.wu),
                                    l = b.sessionData,
                                    m = b.watchEndpoint,
                                    n = g.Nz(h);
                                e && n && (n.v || n.list) ? a.player.uo(n.v,
                                    l, n.list, !1, void 0, m || void 0) : g.tAa(h, l)
                            };
                        Hfb(a, b, function() {
                            a.player.sendVideoStatsEngageEvent(17, f)
                        })
                    }
                }
            }
        },
        T4 = function(a, b) {
            a = a.player.W();
            if (b) {
                if (b.startsWith("//")) return a.protocol + ":" + b;
                if (b.startsWith("/")) return g.$M(a) + b
            } else return "";
            return b
        },
        Efb = function(a, b, c) {
            g.Kq(b.element, "ytp-ce-element-hover") || ("VIDEO" === c.type || "PLAYLIST" === c.type ? g.Lq(b.element, "ytp-ce-element-hover") : a.player.W().u ? (new g.Dq(function() {
                g.Lq(b.element, "ytp-ce-element-hover")
            }, 200)).start() : g.Lq(b.element, "ytp-ce-element-hover"), V4(a, c.z5), U4(a, c.id, !0))
        },
        Ffb = function(a, b, c) {
            g.Nq(b.element, "ytp-ce-element-hover");
            g.Nq(b.element, "ytp-ce-force-expand");
            U4(a, c.id, !1)
        },
        U4 = function(a, b, c) {
            a.u && (c ? a.C.show() : a.C.hide());
            for (var d = g.u(Object.keys(a.j)), e = d.next(); !e.done; e = d.next()) e = e.value, e !== b && g.Pq(a.j[e].element, "ytp-ce-element-shadow-show", c)
        },
        V4 = function(a, b, c) {
            function d() {
                f || (e++, e === b.length && (h.stop(), c && c()))
            }
            if (!b || 0 === b.length || Q4(a)) c && c();
            else {
                b = Ifb(a, b);
                var e = 0,
                    f = !1,
                    h = new g.Dq(function() {
                        f = !0;
                        c && c()
                    }, 1E3, a);
                h.start();
                for (a = 0; a < b.length; a++) g.qD(b[a], d)
            }
        },
        Hfb = function(a, b, c) {
            V4(a, b.clickUrls, c);
            (a = g.mH()) && b.K5 && g.qQ(a, b.visualElement)
        },
        Ifb = function(a, b) {
            var c = a.player.getVideoData().clientPlaybackNonce;
            a = a.player.getCurrentTime().toFixed(2);
            c = {
                CPN: c,
                AD_CPN: c,
                MT: a
            };
            a = [];
            for (var d = 0; d < b.length; d++) a.push(Jfb(b[d], c));
            return a
        },
        Jfb = function(a, b) {
            return a.replace(/%5B[a-zA-Z_:]+%5D|\[[a-zA-Z_:]+\]/g, function(c) {
                var d = unescape(c);
                d = d.substring(1, d.length - 1);
                return b[d] ? escape(b[d]) : c
            })
        },
        Kfb = function(a) {
            return "string" === typeof a ? a : ""
        },
        W4 = function(a, b, c) {
            for (var d in b)
                if (b[d] === a) return a;
            return c
        },
        Lfb = function(a, b, c, d) {
            this.value = a;
            this.target = b;
            this.showLinkIcon = c;
            this.j = d
        },
        X4 = function(a) {
            return a.value ? a.value : null
        },
        Y4 = function(a) {
            if (!a) return null;
            var b = g.ge(Kfb(a.value));
            b = g.ae(b);
            if (!b) return null;
            var c = W4(a.target, Mfb, "current");
            if (null == c) a = null;
            else {
                var d = a.show_link_icon;
                a = new Lfb(b, c, "true" === d || "false" === d ? "true" === d : !0, null != a.pause_on_navigation ? a.pause_on_navigation : !0)
            }
            return a
        },
        Nfb = function(a, b, c) {
            this.type = a;
            this.trigger = b;
            this.url = c
        },
        Qfb = function(a) {
            if (!a) return null;
            var b = W4(a.type, Ofb),
                c = W4(a.trigger, Pfb);
            a = a.url;
            a = Array.isArray(a) && a.length ? a[0] : a;
            a = Y4(a ? a : null);
            return b ? new Nfb(b, c, a) : null
        },
        Rfb = function(a, b, c, d, e) {
            this.id = a;
            this.type = b;
            this.style = c;
            this.data = e;
            this.action = d || []
        },
        Sfb = function(a, b) {
            return g.Eb(a.action, b)
        },
        Tfb = function(a, b) {
            this.context = a;
            this.j = b
        },
        Ufb = function(a) {
            return a.customMessage ? Z4("div", "iv-card-message", a.customMessage) : ""
        },
        $4 = function(a, b) {
            a = "background-image: url(" + a + ");";
            var c = [];
            b && c.push(b);
            return {
                G: "div",
                S: "iv-card-image",
                Y: {
                    style: a
                },
                X: c
            }
        },
        Vfb = function(a) {
            if (!a.metaInfo || 0 === a.metaInfo.length) return "";
            var b = [];
            a = g.u(a.metaInfo);
            for (var c = a.next(); !c.done; c = a.next()) b.push(Z4("li", "", c.value));
            return {
                G: "ul",
                S: "iv-card-meta-info",
                X: b
            }
        },
        Z4 = function(a, b, c) {
            b ? "string" === typeof b ? b = {
                "class": b
            } : Array.isArray(b) && (b = {
                "class": b.join(" ")
            }) : b = {};
            b.dir = g.ar(c);
            return {
                G: a,
                Y: b,
                Aa: c
            }
        },
        Wfb = function(a) {
            if (!a.customMessage) return "";
            var b = ["iv-card-action", "iv-card-primary-link"],
                c = {};
            a.MB && (b.push("iv-card-action-icon"), c.style = "background-image: url(" + a.MB + ");");
            c.dir = g.ar(a.customMessage);
            var d = [{
                G: "span",
                Aa: a.customMessage
            }];
            a.showLinkIcon && (d.push("\u00a0"), d.push({
                G: "span",
                S: "iv-card-link-icon"
            }));
            return {
                G: "div",
                Ma: b,
                Y: c,
                X: d
            }
        },
        a5 = function(a, b, c, d) {
            if (d) {
                b = g.u(b);
                for (var e = b.next(); !e.done; e = b.next()) a.j(e.value, d, c.id, c.sessionData, c.dj.click, 5)
            }
        },
        Xfb = function(a, b) {
            this.merchant = a;
            this.price = b
        },
        Yfb = function(a) {
            var b;
            (b = a) && !(b = 1 < a.length ? "/" === a.charAt(0) && "/" !== a.charAt(1) : "/" === a) && (b = a.replace(/^(https?:)?\/\//, "").split("/", 1), b = !b || 1 > b.length || !b[0] ? [] : b[0].toLowerCase().split(".").reverse(), b = "com" === b[0] && "youtube" === b[1] || "be" === b[0] && "youtu" === b[1]);
            return b ? -1 === a.indexOf("/redirect?") : !1
        },
        Zfb = function(a, b) {
            return b ? b : Yfb(a) ? "current" : "new"
        },
        b5 = function(a, b) {
            g.D.call(this);
            var c = this;
            this.element = a;
            this.context = b;
            this.wb = !1;
            this.fb = new Map;
            this.kb = new Map;
            this.context.I.addEventListener(g.JG("annotations_module"), function(d) {
                (d = c.fb.get(d)) && d.apply(c)
            });
            this.context.I.addEventListener(g.KG("annotations_module"), function(d) {
                (d = c.kb.get(d)) && d.apply(c)
            })
        },
        c5 = function(a, b, c, d, e, f, h) {
            a.context.j.Ta(b, "click", function(l) {
                a.dK(c, d, e, f || [], h || 0, l)
            });
            a.context.j.Ta(b, "touchstart", function() {
                a.wb = !1
            });
            a.context.j.Ta(b, "touchmove", function() {
                a.wb = !0
            })
        },
        $fb = function(a) {
            var b;
            return (null == (b = g.S(a, g.uO)) ? 0 : b.url) ? g.S(a, g.uO).url : (a = g.S(a, g.tO)) && a.videoId ? (b = "/watch?v=" + a.videoId, a.playlistId && (b += "&list=" + a.playlistId), a.index && (b += "&index=" + a.index), a.startTimeSeconds && (b += "&t=" + a.startTimeSeconds), b) : null
        },
        d5 = function(a, b, c) {
            return {
                cW: (a.impressionLoggingUrlsV2s || []).map(function(d) {
                    return d.baseUrl || ""
                }),
                click: (c.loggingUrls || []).map(function(d) {
                    return d.baseUrl || ""
                }),
                close: (b.dismissLoggingUrlsV2s || []).map(function(d) {
                    return d.baseUrl || ""
                }),
                CZ: (b.impressionLoggingUrlsV2s || []).map(function(d) {
                    return d.baseUrl || ""
                }),
                rJ: (b.clickLoggingUrlsV2s || []).map(function(d) {
                    return d.baseUrl || ""
                })
            }
        },
        agb = function(a, b, c) {
            b5.call(this, b, c);
            var d = this;
            this.I = a;
            this.eventId = null;
            this.Oa = this.hc = this.B = this.isInitialized = !1;
            this.cards = [];
            this.Eb = this.V = this.Na = this.D = this.Ya = this.j = null;
            this.oa = [];
            this.qa = this.K = this.zg = this.Fa = null;
            this.J = 0;
            this.Ga = new g.Dq(function() {}, c.Z.Li ? 4E3 : 3E3);
            g.H(this, this.Ga);
            this.sb = new g.Dq(function() {});
            g.H(this, this.sb);
            this.Ba = new Tfb(c, function(e, f, h, l, m, n) {
                c5(d, e, f, h, l, m, n)
            });
            this.ma = new g.X({
                G: "div",
                S: "iv-drawer",
                Y: {
                    id: "iv-drawer"
                },
                X: [{
                    G: "div",
                    S: "iv-drawer-header",
                    Y: {
                        "aria-role": "heading"
                    },
                    X: [{
                        G: "span",
                        S: "iv-drawer-header-text"
                    }, {
                        G: "button",
                        Ma: ["iv-drawer-close-button", "ytp-button"],
                        Y: {
                            "aria-label": "Hide cards",
                            tabindex: "0"
                        }
                    }]
                }, {
                    G: "div",
                    S: "iv-drawer-content"
                }]
            });
            g.H(this, this.ma);
            this.C = this.ma.element;
            this.ob = new g.yR(this.ma, 330);
            g.H(this, this.ob);
            this.Yb = g.Xe("iv-drawer-header-text", this.C);
            this.u = g.Xe("iv-drawer-content", this.C);
            this.addCueRange(0, 1E3 * c.videoData.lengthSeconds,
                "",
                function() {
                    d.hc && e5(d, "YOUTUBE_DRAWER_AUTO_OPEN")
                },
                function() {
                    (d.hc = d.B) && f5(d)
                });
            this.Va = new g.LK(this);
            g.H(this, this.Va);
            this.I.addEventListener("videodatachange", this.vt.bind(this))
        },
        bgb = function(a, b) {
            b = b.data;
            b.autoOpenMs && a.addCueRange(b.autoOpenMs, 0x8000000000000, "", function() {
                e5(a, "YOUTUBE_DRAWER_AUTO_OPEN")
            });
            b.autoCloseMs && a.addCueRange(b.autoCloseMs, 0x8000000000000, "", function() {
                f5(a)
            });
            var c = b.headerText;
            g.tf(a.Yb, c);
            a.V && a.V.setAttribute("title", c);
            b.eventId && (a.eventId = b.eventId);
            a.Fa = g.jH(b.trackingParams);
            a.K = g.jH(b.closeTrackingParams);
            a.zg = g.jH(b.iconTrackingParams)
        },
        cgb = function(a, b) {
            var c = b.cardId ? b.cardId : "cr:" + a.J,
                d = a.I.W().experiments.rb("enable_error_corrections_infocard_web_client");
            if (!b.content && b.teaser.simpleCardTeaserRenderer && d) {
                var e = b.teaser.simpleCardTeaserRenderer,
                    f = b.icon ? b.icon.infoCardIconRenderer : null;
                b = {
                    id: c,
                    timestamp: a.J,
                    type: "simple",
                    teaserText: g.PG(e.message),
                    teaserDurationMs: Number(b.cueRanges[0].teaserDurationMs),
                    startMs: Number(b.cueRanges[0].startCardActiveMs),
                    autoOpen: !!b.autoOpen,
                    sessionData: {},
                    sponsored: !1,
                    dj: {},
                    So: null,
                    Al: e.trackingParams ? g.jH(e.trackingParams) : null,
                    zg: f && f.trackingParams ? g.jH(f.trackingParams) : null,
                    imageUrl: "",
                    displayDomain: null,
                    showLinkIcon: !1,
                    MB: null,
                    title: "",
                    customMessage: "",
                    url: null,
                    onClickCommand: e.onTapCommand || null
                };
                g5(a, b)
            } else {
                var h;
                if (null == (h = b.content) ? 0 : h.simpleCardContentRenderer) {
                    if (!b.cueRanges.length) return;
                    f = null == (e = b.content) ? void 0 : e.simpleCardContentRenderer;
                    e = b.teaser.simpleCardTeaserRenderer;
                    var l = b.icon ? b.icon.infoCardIconRenderer : null;
                    b = {
                        id: c,
                        timestamp: a.J,
                        type: "simple",
                        teaserText: g.PG(e.message),
                        teaserDurationMs: Number(b.cueRanges[0].teaserDurationMs),
                        startMs: Number(b.cueRanges[0].startCardActiveMs),
                        autoOpen: !!b.autoOpen,
                        sessionData: h5(a, c, b, f),
                        sponsored: !1,
                        dj: d5(f, e, f.command),
                        So: f.trackingParams ? g.jH(f.trackingParams) : null,
                        Al: e.trackingParams ? g.jH(e.trackingParams) : null,
                        zg: l && l.trackingParams ? g.jH(l.trackingParams) : null,
                        imageUrl: i5(f.image.thumbnails, 290).url,
                        displayDomain: f.displayDomain ? g.PG(f.displayDomain) : null,
                        showLinkIcon: !!f.showLinkIcon,
                        MB: null,
                        title: f.title ? g.PG(f.title) : "",
                        customMessage: f.callToAction ? g.PG(f.callToAction) : "",
                        url: g.S(f.command, g.uO).url ? Y4({
                            pause_on_navigation: !a.context.videoData.isLivePlayback,
                            target: "new",
                            value: g.S(f.command, g.uO).url
                        }) : null,
                        onClickCommand: null
                    };
                    g5(a, b)
                } else {
                    var m;
                    if (null == (m = b.content) ? 0 : m.collaboratorInfoCardContentRenderer) {
                        if (!b.cueRanges.length) return;
                        e = null == (f = b.content) ? void 0 : f.collaboratorInfoCardContentRenderer;
                        f = b.teaser.simpleCardTeaserRenderer;
                        l = b.icon ? b.icon.infoCardIconRenderer : null;
                        b = {
                            id: c,
                            timestamp: a.J,
                            type: "collaborator",
                            teaserText: g.PG(f.message),
                            teaserDurationMs: Number(b.cueRanges[0].teaserDurationMs),
                            startMs: Number(b.cueRanges[0].startCardActiveMs),
                            autoOpen: !!b.autoOpen,
                            sessionData: h5(a, c, b, e),
                            sponsored: !1,
                            dj: d5(e, f, e.endpoint),
                            So: e.trackingParams ? g.jH(e.trackingParams) : null,
                            Al: f.trackingParams ? g.jH(f.trackingParams) : null,
                            zg: l && l.trackingParams ? g.jH(l.trackingParams) : null,
                            channelId: g.S(e.endpoint, g.z3).browseId,
                            customMessage: e.customText ? g.PG(e.customText) : null,
                            rY: i5(e.channelAvatar.thumbnails, 290).url,
                            title: e.channelName ? g.PG(e.channelName) : "",
                            metaInfo: [e.subscriberCountText ? g.PG(e.subscriberCountText) : ""],
                            url: Y4({
                                pause_on_navigation: !a.context.videoData.isLivePlayback,
                                target: "new",
                                value: g.S(e.endpoint, g.z3).canonicalBaseUrl ? g.S(e.endpoint, g.z3).canonicalBaseUrl : "/channel/" + g.S(e.endpoint, g.z3).browseId
                            }),
                            onClickCommand: null
                        };
                        g5(a, b)
                    } else {
                        var n;
                        if (null == (n = b.content) ? 0 : n.playlistInfoCardContentRenderer) {
                            if (!b.cueRanges.length) return;
                            e = null == (l = b.content) ? void 0 : l.playlistInfoCardContentRenderer;
                            f = b.teaser.simpleCardTeaserRenderer;
                            l = b.icon ? b.icon.infoCardIconRenderer : null;
                            b = {
                                id: c,
                                timestamp: a.J,
                                type: "playlist",
                                teaserText: g.PG(f.message),
                                teaserDurationMs: Number(b.cueRanges[0].teaserDurationMs),
                                startMs: Number(b.cueRanges[0].startCardActiveMs),
                                autoOpen: !!b.autoOpen,
                                sessionData: h5(a, c, b, e),
                                sponsored: !1,
                                dj: d5(e, f, e.action),
                                So: e.trackingParams ? g.jH(e.trackingParams) : null,
                                Al: f.trackingParams ? g.jH(f.trackingParams) : null,
                                zg: l && l.trackingParams ? g.jH(l.trackingParams) : null,
                                WE: i5(e.playlistThumbnail.thumbnails, 258).url,
                                customMessage: e.customMessage ? g.PG(e.customMessage) : null,
                                playlistVideoCount: g.PG(e.playlistVideoCount),
                                title: e.playlistTitle ? g.PG(e.playlistTitle) : "",
                                metaInfo: [e.channelName ? g.PG(e.channelName) :
                                    "", e.videoCountText ? g.PG(e.videoCountText) : ""
                                ],
                                url: Y4({
                                    pause_on_navigation: !a.context.videoData.isLivePlayback,
                                    target: "new",
                                    value: $fb(e.action)
                                }),
                                onClickCommand: null
                            };
                            g5(a, b)
                        } else {
                            var p;
                            if (null == (p = b.content) ? 0 : p.videoInfoCardContentRenderer) {
                                if (!b.cueRanges.length) return;
                                var q;
                                e = null == (q = b.content) ? void 0 : q.videoInfoCardContentRenderer;
                                f = b.teaser.simpleCardTeaserRenderer;
                                l = b.icon ? b.icon.infoCardIconRenderer : null;
                                b = {
                                    id: c,
                                    timestamp: a.J,
                                    type: "video",
                                    teaserText: g.PG(f.message),
                                    teaserDurationMs: Number(b.cueRanges[0].teaserDurationMs),
                                    startMs: Number(b.cueRanges[0].startCardActiveMs),
                                    autoOpen: !!b.autoOpen,
                                    sessionData: h5(a, c, b, e),
                                    sponsored: !1,
                                    dj: d5(e, f, e.action),
                                    So: e.trackingParams ? g.jH(e.trackingParams) : null,
                                    Al: f.trackingParams ? g.jH(f.trackingParams) : null,
                                    zg: l && l.trackingParams ? g.jH(l.trackingParams) : null,
                                    WE: i5(e.videoThumbnail.thumbnails, 258).url,
                                    videoDuration: e.lengthString ? g.PG(e.lengthString) : null,
                                    customMessage: e.customMessage ? g.PG(e.customMessage) : null,
                                    title: e.videoTitle ? g.PG(e.videoTitle) : "",
                                    metaInfo: [e.channelName ? g.PG(e.channelName) :
                                        "", e.viewCountText ? g.PG(e.viewCountText) : ""
                                    ],
                                    isLiveNow: !!e.badge,
                                    url: Y4({
                                        pause_on_navigation: !a.context.videoData.isLivePlayback,
                                        target: "new",
                                        value: $fb(e.action)
                                    }),
                                    onClickCommand: null
                                };
                                g5(a, b)
                            }
                        }
                    }
                }
            }
            a.J++
        },
        i5 = function(a, b) {
            for (var c = -1, d = -1, e = 0; e < a.length; e++) {
                if (a[e].height === b || 290 === a[e].width) return a[e];
                ((a[e].height || 0) < b || 290 > (a[e].width || 0)) && (0 > c || (a[c].height || 0) < (a[e].height || 0) || (a[c].width || 0) < (a[e].width || 0)) ? c = e: ((a[e].height || 0) >= b || 290 <= (a[e].width || 0)) && (0 > d || (a[d].height || 0) > (a[e].height || 0) || (a[d].width || 0) > (a[e].width || 0)) && (d = e)
            }
            return a[0 <= d ? d : c]
        },
        h5 = function(a, b, c, d) {
            return {
                feature: c.feature ? c.feature : "cards",
                src_vid: a.context.videoData.videoId,
                annotation_id: b,
                ei: a.context.videoData.eventId || "",
                itct: d.trackingParams || ""
            }
        },
        egb = function(a, b) {
            if (b = dgb(a, b)) b === a.j && (a.j = null), a.I.removeCueRange(b.vg.id), g.qf(b.KL), g.Jb(a.cards, b), a.TF(), j5(a)
        },
        e5 = function(a, b, c) {
            if (!a.B) {
                a.ob.show();
                a.Ya = new g.Dq(function() {
                    g.Lq(a.context.I.getRootNode(), g.wX.IV_DRAWER_OPEN)
                }, 0);
                a.Ya.start();
                a.Va.T(a.u, "mousewheel", function(h) {
                    a.Ga.start();
                    h.preventDefault();
                    h = h || window.event;
                    var l = 0;
                    "MozMousePixelScroll" == h.type ? l = 0 == (h.axis == h.HORIZONTAL_AXIS) ? h.detail : 0 : window.opera ? l = h.detail : l = 0 == h.wheelDelta % 120 ? "WebkitTransform" in document.documentElement.style ? window.chrome && 0 == navigator.platform.indexOf("Mac") ? h.wheelDeltaY / -30 : h.wheelDeltaY / -1.2 : h.wheelDelta / -1.6 : h.wheelDeltaY / -3;
                    if (h = l) a.u.scrollTop += h
                });
                a.B = !0;
                var d = g.mH();
                d && a.Fa && a.K && g.oQ(d, [a.Fa, a.K]);
                b = {
                    TRIGGER_TYPE: b
                };
                for (var e = g.u(a.cards), f = e.next(); !f.done; f = e.next()) f = f.value, f.RW || (f.RW = !0, fgb(a.context.logger, f.vg.dj.cW, b)), d && g.oQ(d, [f.vg.So]);
                H4(a.I);
                c && (a.D = new g.Dq(function() {
                    a.Na = a.V;
                    a.Eb.focus()
                }, 330), a.D.start())
            }
        },
        f5 = function(a) {
            a.B && (a.ob.hide(), g.hB(a.Va), g.Nq(a.context.I.getRootNode(), g.wX.IV_DRAWER_OPEN), a.B = !1, H4(a.I), a.D && a.D.stop(), a.D = new g.Dq(function() {
                a.Na && (a.Na.focus(), a.Na = null)
            }, 330), a.D.start())
        },
        hgb = function(a) {
            g.Mq(a.Bb(), [g.wX.STOP_EVENT_PROPAGATION,
                "iv-drawer-manager"
            ]);
            g.XS(a.I, a.C, 5);
            ggb(a);
            a.V = g.Xe("ytp-cards-button", a.I.getRootNode());
            a.Eb = g.Xe("iv-drawer-close-button", a.C);
            a.isInitialized = !0
        },
        ggb = function(a) {
            var b = g.Xe("iv-drawer-close-button", a.C);
            a.context.j.Ta(b, "click", a.N3, a);
            a.context.j.Ta(a.u, "touchend", function() {
                a.Ga.start()
            });
            a.context.j.Ta(a.u, "scroll", a.g4, a);
            a.context.u.subscribe("onHideControls", function() {
                a.Oa = !0
            });
            a.context.u.subscribe("onShowControls", function() {
                a.Oa = !1
            });
            a.context.u.subscribe("onVideoAreaChange", function() {
                a.Oa = g.Kq(a.I.getRootNode(), "ytp-autohide")
            });
            a.oa.push(g.HD("iv-button-shown", a.V5, a));
            a.oa.push(g.HD("iv-button-hidden", a.U5, a));
            a.oa.push(g.HD("iv-teaser-shown", a.o0, a));
            a.oa.push(g.HD("iv-teaser-hidden", a.W5, a));
            a.oa.push(g.HD("iv-teaser-clicked", a.n0, a))
        },
        igb = function(a, b) {
            var c;
            return b.onClickCommand && "engagement-panel-error-corrections" === (null == (c = g.S(b.onClickCommand, g.Xbb)) ? void 0 : c.targetId) ? (a.qa = b, !0) : !1
        },
        jgb = function(a, b) {
            a.qa = b;
            var c = a.I.getVideoData();
            if (!c) return !1;
            c = a.I.N("embeds_web_enable_video_data_refactoring_offline_and_progress_bar") ? g.eya(c) : c.multiMarkersPlayerBarRenderer;
            if (null == c ? 0 : c.markersMap)
                for (var d, e = 0;
                    (null == (d = c) ? void 0 : d.markersMap.length) > e; e++) {
                    var f = void 0,
                        h = null == (f = c) ? void 0 : f.markersMap[e];
                    if ("ERROR_CORRECTION_MARKERS" === h.key && (f = void 0, (h = null == (f = h.value) ? void 0 : f.markers) && 0 < h.length)) return d = void 0, b.startMs = (null == (d = g.S(h[0], g.IQa)) ? void 0 : d.timeRangeStartMillis) || 0, a.qa = null, !0
                }
            return !1
        },
        g5 = function(a, b) {
            if (!igb(a, b) || jgb(a, b)) {
                var c = kgb(a, b);
                if (c) {
                    var d = {
                        vg: b,
                        KL: c.element,
                        RW: !1
                    };
                    if (!b.onClickCommand) {
                        a.isInitialized || hgb(a);
                        egb(a, b.id);
                        var e = lgb(a, d);
                        g.Rb(a.cards, e, 0, d);
                        c.Ja(a.u, e);
                        a.TF()
                    }
                    b.autoOpen ? a.addCueRange(b.startMs, 0x8000000000000, b.id, function() {
                        a.B || (a.j = d, j5(a), mgb(a, d), e5(a, "YOUTUBE_DRAWER_AUTO_OPEN", !1))
                    }) : (c = 1E3 * a.context.I.getCurrentTime(), 5E3 > c && c > b.startMs && ngb(a, d), a.addCueRange(b.startMs, b.startMs + 1, b.id, function() {
                        ngb(a, d)
                    }), j5(a))
                }
            }
        },
        kgb = function(a, b) {
            switch (b.type) {
                case "simple":
                    a = a.Ba;
                    var c = b.displayDomain ? {
                        G: "div",
                        S: "iv-card-image-text",
                        Aa: b.displayDomain
                    } : void 0;
                    var d = Wfb(b);
                    c = {
                        G: "div",
                        Ma: ["iv-card"],
                        X: [{
                            G: "a",
                            S: "iv-click-target",
                            Y: {
                                href: b.url ? X4(b.url) || "" : ""
                            },
                            X: [$4(b.imageUrl, c), {
                                G: "div",
                                S: "iv-card-content",
                                X: [Z4("h2", void 0, b.title), d]
                            }]
                        }]
                    };
                    c = new g.X(c);
                    a5(a, g.Ne("iv-click-target", c.element), b, b.url);
                    b = c;
                    break;
                case "collaborator":
                    a = a.Ba;
                    c = {
                        G: "div",
                        Ma: ["iv-card", "iv-card-channel"],
                        X: [{
                            G: "a",
                            Ma: ["iv-click-target"],
                            Y: {
                                href: X4(b.url) || "",
                                "data-ytid": b.channelId
                            },
                            X: [$4(b.rY), {
                                G: "div",
                                S: "iv-card-content",
                                X: [Ufb(b), {
                                    G: "h2",
                                    S: "iv-card-primary-link",
                                    Aa: b.title
                                }, Vfb(b)]
                            }]
                        }]
                    };
                    c = new g.X(c);
                    a5(a, g.Ne("iv-click-target", c.element), b, b.url);
                    b = c;
                    break;
                case "playlist":
                    a = a.Ba;
                    c = {
                        G: "div",
                        Ma: ["iv-card", "iv-card-playlist"],
                        X: [{
                            G: "a",
                            S: "iv-click-target",
                            Y: {
                                href: X4(b.url) || ""
                            },
                            X: [$4(b.WE, {
                                G: "div",
                                S: "iv-card-image-overlay",
                                X: [{
                                    G: "span",
                                    S: "iv-card-playlist-video-count",
                                    Aa: b.playlistVideoCount
                                }]
                            }), {
                                G: "div",
                                S: "iv-card-content",
                                X: [Ufb(b), Z4("h2", "iv-card-primary-link", b.title), Vfb(b)]
                            }]
                        }]
                    };
                    c = new g.X(c);
                    a5(a, g.Ne("iv-click-target", c.element), b, b.url);
                    b = c;
                    break;
                case "productListing":
                    a = a.Ba;
                    var e = 0 != b.offers.length;
                    c = ["iv-card"];
                    d = "";
                    var f = Wfb(b);
                    e && (c.push("iv-card-product-listing"), d = "iv-card-primary-link", f = b.offers[0], e = [], f.price && e.push({
                        G: "div",
                        S: "iv-card-offer-price",
                        Aa: f.price
                    }), f.merchant && e.push({
                        G: "div",
                        S: "iv-card-offer-merchant",
                        Aa: f.merchant
                    }), f = {
                        G: "div",
                        X: e
                    });
                    e = b.url ? X4(b.url) || "" : "";
                    c = {
                        G: "div",
                        Ma: c,
                        Y: {
                            tabindex: "0"
                        },
                        X: [{
                            G: "a",
                            Ma: ["iv-card-image", "iv-click-target"],
                            Y: {
                                style: "background-image: url(" +
                                    b.imageUrl + ");",
                                href: e,
                                "aria-hidden": "true",
                                tabindex: "-1"
                            }
                        }, {
                            G: "div",
                            S: "iv-card-content",
                            X: [b.sponsored ? {
                                G: "div",
                                S: "iv-card-sponsored",
                                X: ["Sponsored", {
                                    G: "div",
                                    S: "iv-ad-info-container",
                                    X: [{
                                        G: "div",
                                        S: "iv-ad-info",
                                        Aa: "{{adInfo}}"
                                    }, {
                                        G: "div",
                                        S: "iv-ad-info-icon-container",
                                        X: [{
                                            G: "div",
                                            S: "iv-ad-info-icon"
                                        }, {
                                            G: "div",
                                            S: "iv-ad-info-callout"
                                        }]
                                    }]
                                }]
                            } : "", {
                                G: "a",
                                S: "iv-click-target",
                                Y: {
                                    href: e
                                },
                                X: [Z4("h2", d, b.title), f]
                            }]
                        }]
                    };
                    c = new g.X(c);
                    d = g.cf("span");
                    g.tf(d, "You are seeing this product because we think it is relevant to the video. Google may be compensated by the merchant.");
                    c.qe(d, "adInfo");
                    a5(a, g.Ne("iv-click-target", c.element), b, b.url);
                    b = c;
                    break;
                case "video":
                    a = a.Ba;
                    d = b.videoDuration ? {
                        G: "span",
                        S: "iv-card-video-duration",
                        Aa: b.videoDuration
                    } : void 0;
                    f = b.isLiveNow ? {
                        G: "span",
                        Ma: ["yt-badge", "yt-badge-live"],
                        Aa: "LIVE NOW"
                    } : null;
                    e = {
                        G: "div",
                        Ma: ["iv-card", "iv-card-video"],
                        X: [{
                            G: "a",
                            S: "iv-click-target",
                            Y: {
                                href: (null == (c = b.url) ? void 0 : X4(c)) || ""
                            },
                            X: [$4(b.WE, d), {
                                G: "div",
                                S: "iv-card-content",
                                X: [Ufb(b), Z4("h2", "iv-card-primary-link", b.title), Vfb(b), f]
                            }]
                        }]
                    };
                    c = new g.X(e);
                    a5(a, g.Ne("iv-click-target",
                        c.element), b, b.url);
                    b = c;
                    break;
                default:
                    return null
            }
            return b
        },
        lgb = function(a, b) {
            if (0 === a.cards.length) return 0;
            a = g.Fb(a.cards, function(c) {
                return b.vg.startMs > c.vg.startMs || b.vg.startMs === c.vg.startMs && b.vg.timestamp >= c.vg.timestamp ? !0 : !1
            });
            return -1 === a ? 0 : a + 1
        },
        ogb = function(a) {
            if (a.j) return "productListing" === a.j.vg.type;
            if (a.I.N("enable_wn_infocards")) {
                var b;
                return !(null == (b = a.cards) || !b.length) && g.dn(a.cards, function(c) {
                    return "productListing" === c.vg.type
                })
            }
            return g.dn(a.cards, function(c) {
                return "productListing" === c.vg.type
            })
        },
        j5 = function(a) {
            g.Pq(a.I.getRootNode(), "ytp-cards-shopping-active", ogb(a))
        },
        ngb = function(a, b) {
            if (!g.Kq(a.I.getRootNode(), "ytp-cards-teaser-shown")) {
                if (a.j !== b) {
                    var c = g.mH(),
                        d = a.j ? a.j.vg.zg : a.zg;
                    c && d && g.pQ(c, [d]);
                    a.j = b;
                    j5(a)
                }(c = a.isInitialized && "none" == a.Bb().style.display) || (c = a.context.I.getPlayerState(), d = 0 === c && 0 === a.context.I.getCurrentTime(), c = !(1 === c || 3 === c || d));
                c || b.vg.teaserDurationMs && a.I.pA(!0, {
                    teaserText: b.vg.teaserText,
                    durationMs: b.vg.teaserDurationMs,
                    onClickCommand: b.vg.onClickCommand
                });
                a.sb.isActive() || ((!a.B || !a.Ga.isActive() && a.Oa) && mgb(a, b), a.sb.start(910 + b.vg.teaserDurationMs))
            }
        },
        mgb = function(a, b) {
            a.ma.Gb ? (b = new M4([0,
                a.u.scrollTop
            ], [0, b.KL.offsetTop], 600, tfb), a.context.B.Ta(b, "animate", function(c) {
                a.u.scrollTop = c.y
            }), a.context.B.Ta(b, "finish", function(c) {
                a.u.scrollTop = c.y
            }), b.play()) : (g.$Q(a.ma, !0), a.u.scrollTop = b.KL.offsetTop, g.$Q(a.ma, !1))
        },
        k5 = function(a) {
            return a.j && a.j.vg ? a.j.vg : a.cards[0] && a.cards[0].vg ? a.cards[0].vg : null
        },
        dgb = function(a, b) {
            return g.Eb(a.cards, function(c) {
                return c.vg.id === b
            })
        },
        l5 = function(a, b, c) {
            b5.call(this, a, b);
            this.annotation = c;
            this.isActive = !1
        },
        pgb = function(a) {
            var b = a.annotation.data;
            "start_ms" in b && "end_ms" in b && a.addCueRange(b.start_ms, b.end_ms, a.annotation.id, function() {
                a.show()
            }, function() {
                a.hide()
            })
        },
        m5 = function(a, b, c) {
            l5.call(this, a, b, c);
            this.u = null;
            this.K = !1;
            this.B = null;
            this.C = !1;
            this.j = this.J = this.D = null
        },
        qgb = function(a, b) {
            var c = void 0 === c ? 0 : c;
            var d = lfb(b).width;
            g.Tn(b, d);
            c = new rfb(b, [d, b.offsetTop], [d - d - c, b.offsetTop], 200, sfb);
            g.H(a, c);
            a.context.B.Ta(c, "begin", function() {
                g.no(b, !0)
            });
            c.play()
        },
        tgb = function(a, b) {
            if (b.channel_name) {
                var c = a.createElement({
                        G: "div",
                        Ma: ["iv-branding-context-name"],
                        Aa: b.channel_name
                    }),
                    d = a.createElement({
                        G: "div",
                        Ma: ["iv-branding-context-subscribe"]
                    }),
                    e = b.standalone_subscribe_button_data;
                e && (a.j = new g.JU(e.subscribeText, e.subscribeCount, e.unsubscribeText, e.unsubscribeCount, !!e.enabled, !!e.classic, b.channel_id, !!e.subscribed, e.feature, b.session_data.itct, a.context.I), a.j.Ja(d));
                var f = a.createElement({
                        G: "div",
                        Ma: ["iv-branding-context-subscribe-caret"]
                    }),
                    h = a.createElement({
                        G: "div",
                        Ma: ["branding-context-container-inner"]
                    });
                h.appendChild(f);
                h.appendChild(c);
                h.appendChild(d);
                g.no(h, !1);
                var l = a.createElement({
                    G: "div",
                    Ma: ["branding-context-container-outer"]
                });
                l.appendChild(h);
                g.Nn(l, "right", b.image_width + "px");
                g.nf(a.Bb(), l);
                a.B = new g.Dq(function() {
                    rgb(a, h, l)
                }, 500);
                g.H(a, a.B);
                a.context.j.Ta(a.Bb(), "mouseover", function() {
                    sgb(a, h, l, f, b.image_height)
                });
                a.context.j.Ta(a.Bb(), "mouseout", function() {
                    a.B.start()
                })
            }
        },
        sgb = function(a, b, c, d, e) {
            a.B.stop();
            if (!a.C) {
                var f = g.mo(b);
                a.j || (b.style.width = g.Sn(f.width, !0), c.style.width = g.Sn(f.width, !0));
                g.Nn(d, "top", f.height - Math.max(Math.min(f.height, e) / 2 + 10, 20) + "px");
                g.Nn(d, "right", "1px");
                a.C = !0;
                g.no(b, !0);
                a.D = new g.Dq(function() {
                    g.Lq(this.Bb(), "iv-branding-active")
                }, 0, a);
                a.D.start()
            }
        },
        rgb = function(a, b, c) {
            g.Nq(a.Bb(), "iv-branding-active");
            a.J = new g.Dq(function() {
                g.no(b, !1);
                a.j || (c.style.width = g.Sn(0, !0))
            }, 250);
            a.J.start();
            a.C = !1
        },
        ugb = function(a, b, c, d, e, f, h) {
            this.j = a;
            this.B = b;
            this.Z = c;
            this.videoData = d;
            this.logger = e;
            this.I = f;
            this.u = h
        },
        vgb = function(a, b, c) {
            l5.call(this, a, b, c);
            var d = this;
            this.V = this.isCollapsed = this.ma = !1;
            this.J = 5E3;
            this.u = this.B = this.j = this.C = null;
            this.K = this.createElement({
                G: "div",
                Ma: ["iv-promo-contents"]
            });
            this.D = new g.Dq(function() {
                d.j.setAttribute("aria-hidden", "true");
                g.no(d.B, !1);
                g.no(d.u, !0)
            }, 700, this);
            g.H(this, this.D)
        },
        xgb = function(a) {
            var b = a.annotation.data;
            if ("cta" === a.annotation.style) var c = 6;
            else if ("video" === a.annotation.style || "playlist" === a.annotation.style) c = 7;
            a.J = b.collapsedelay_ms || a.J;
            var d = ["iv-promo", "iv-promo-inactive"];
            a.Bb().setAttribute("aria-hidden", "true");
            a.Bb().setAttribute("aria-label", "Promotion");
            a.Bb().tabIndex = 0;
            var e = a.annotation.kf(),
                f = b.image_url;
            if (f) {
                var h = a.createElement({
                    G: "div",
                    Ma: ["iv-promo-img", "iv-click-target"]
                });
                f = a.createElement({
                    G: "img",
                    Y: {
                        src: f,
                        "aria-hidden": "true"
                    }
                });
                h.appendChild(f);
                b.video_duration && !b.is_live ?
                    (f = a.createElement({
                        G: "span",
                        S: "iv-promo-video-duration",
                        Aa: b.video_duration
                    }), h.appendChild(f)) : b.playlist_length && (f = a.createElement({
                        G: "span",
                        S: "iv-promo-playlist-length",
                        Aa: b.playlist_length.toString()
                    }), h.appendChild(f));
                e && c5(a, h, e, a.annotation.id, b.session_data, void 0, c)
            }
            e ? (f = a.createElement({
                G: "a",
                S: "iv-promo-txt"
            }), g.oe(f, X4(e)), a.j = f) : a.j = a.createElement({
                G: "div",
                S: "iv-promo-txt"
            });
            switch (a.annotation.style) {
                case "cta":
                case "website":
                    var l = a.createElement({
                        G: "p",
                        X: [{
                            G: "strong",
                            Aa: b.text_line_1
                        }]
                    });
                    var m = a.createElement({
                        G: "p",
                        X: [{
                            G: "span",
                            S: "iv-promo-link",
                            Aa: b.text_line_2
                        }]
                    });
                    if (f = b.text_line_3) {
                        d.push("iv-promo-website-card-cta-redesign");
                        var n = a.createElement({
                            G: "button",
                            Ma: ["iv-promo-round-expand-icon", "ytp-button"]
                        });
                        f = a.createElement({
                            G: "button",
                            Ma: ["iv-button", "iv-promo-button"],
                            X: [{
                                G: "span",
                                S: "iv-button-content",
                                Aa: f
                            }]
                        });
                        var p = a.createElement({
                            G: "div",
                            S: "iv-promo-button-container"
                        });
                        p.appendChild(f);
                        e && c5(a, a.Bb(), e, a.annotation.id, b.session_data, void 0, c)
                    }
                    g.Lq(a.j, "iv-click-target");
                    e && c5(a, a.j, e, a.annotation.id, b.session_data, void 0, c);
                    break;
                case "playlist":
                case "video":
                    l = a.createElement({
                        G: "p",
                        X: [{
                            G: "span",
                            Aa: b.text_line_1
                        }]
                    }), m = a.createElement({
                        G: "p",
                        X: [{
                            G: "strong",
                            Aa: b.text_line_2
                        }]
                    }), b.is_live && (l = m, m = a.createElement({
                        G: "span",
                        Ma: ["yt-badge", "iv-promo-badge-live"],
                        Aa: "LIVE NOW"
                    })), g.Lq(a.j, "iv-click-target"), e && c5(a, a.j, e, a.annotation.id, b.session_data, void 0, c), d.push("iv-promo-video")
            }
            l && a.j.appendChild(l);
            m && a.j.appendChild(m);
            a.K.appendChild(a.j);
            p && a.K.appendChild(p);
            c = a.createElement({
                G: "div",
                S: "iv-promo-actions"
            });
            a.u = a.createElement({
                G: "button",
                Ma: ["iv-promo-expand", "ytp-button"]
            });
            a.u.title = "Expand";
            a.context.j.Ta(a.u, "click", function(q) {
                wgb(a, 5E3, q)
            });
            c.appendChild(a.u);
            g.no(a.u, !1);
            a.context.j.Ta(a.Bb(), "mouseover", a.c5, a);
            a.context.j.Ta(a.Bb(), "mouseout", a.b5, a);
            a.context.j.Ta(a.Bb(), "touchend", function(q) {
                wgb(a, 5E3, q)
            });
            a.B = a.createElement({
                G: "button",
                Ma: ["iv-promo-close", "ytp-button"]
            });
            a.B.title = "Close";
            a.context.j.Ta(a.B, "click", "cta" === a.annotation.style && b.text_line_3 ? a.X4 : a.W4, a);
            c.appendChild(a.B);
            g.Mq(a.Bb(), d);
            h && (g.nf(a.Bb(), h), n && h.appendChild(n));
            g.nf(a.Bb(), a.K);
            g.nf(a.Bb(), c)
        },
        wgb = function(a, b, c) {
            c.stopPropagation();
            ygb(a);
            zgb(a, b);
            a.j.focus()
        },
        Agb = function(a) {
            a.isCollapsed || a.V || a.C || (g.Lq(a.Bb(), "iv-promo-collapsed"), a.isCollapsed = !0, a.D.start())
        },
        ygb = function(a) {
            a.D.stop();
            a.isCollapsed && (g.Oq(a.Bb(), ["iv-promo-collapsed", "iv-promo-collapsed-no-delay"]), a.isCollapsed = !1, a.j && a.j.removeAttribute("aria-hidden"), g.no(a.u, !1), g.no(a.B, !0))
        },
        zgb = function(a, b) {
            a.C || (a.C = g.cg(function() {
                Bgb(this);
                Agb(this)
            }, b, a))
        },
        Bgb = function(a) {
            a.C && (g.Pa.clearTimeout(a.C), a.C = null)
        },
        Cgb = function(a) {
            this.I = a
        },
        fgb = function(a, b, c) {
            b && (c ? n5(a, b.map(function(d) {
                return g.sq(d, c)
            })) : n5(a, b))
        },
        n5 = function(a, b, c, d) {
            var e = 1,
                f = void 0,
                h = -1;
            if (c) {
                var l = !1;
                f = function() {
                    e--;
                    e || l || (clearTimeout(h), l = !0, c())
                };
                h = setTimeout(function() {
                    l = !0;
                    c()
                }, 1E3)
            }
            b = g.u(b || []);
            for (var m = b.next(); !m.done; m = b.next()) m = m.value, e++, g.qD(m, f);
            d && (e++, 0 !== d && a.I.sendVideoStatsEngageEvent(d, f))
        },
        Dgb = function(a) {
            g.VT.call(this, a);
            var b = this;
            this.ma = this.K = !1;
            this.loadNumber = 0;
            this.J = {};
            this.logger = new Cgb(this.player);
            this.C = new g.LK(this);
            this.D = this.Ww = null;
            this.events = new g.LK(this);
            this.wh = this.V = this.j = null;
            this.oa = [];
            g.H(this, this.C);
            this.C.T(this.player, "onVideoAreaChange", function() {
                b.ra("onVideoAreaChange")
            });
            this.C.T(this.player, "onHideControls", function() {
                b.ra("onHideControls")
            });
            this.C.T(this.player, "onShowControls", function() {
                b.ra("onShowControls")
            });
            this.C.T(this.player, "resize", function(d) {
                b.ra("resize", d)
            });
            this.C.T(this.player, "presentingplayerstatechange", function(d) {
                b.ra("presentingplayerstatechange", d)
            });
            this.subscribe("presentingplayerstatechange", this.q0, this);
            this.subscribe("resize", this.fI, this);
            this.player.W().Fa.subscribe("vast_info_card_add", this.aY, this);
            g.H(this, this.events);
            this.qa = this.createElement({
                G: "div",
                S: "video-custom-annotations"
            });
            this.u = new g.X({
                G: "div",
                Ma: ["ytp-player-content", "ytp-iv-player-content"]
            });
            g.H(this, this.u);
            g.XS(this.player, this.u.element, 4);
            this.u.hide();
            this.B = new g.X({
                G: "div",
                Ma: ["ytp-iv-video-content"]
            });
            g.H(this, this.B);
            a = this.createElement({
                G: "div",
                S: "video-annotations"
            });
            a.appendChild(this.qa);
            this.B.element.appendChild(a);
            this.Nw() && this.load();
            var c = this.createElement({
                G: "style"
            });
            (g.Le("HEAD")[0] || document.body).appendChild(c);
            g.tb(this, function() {
                g.qf(c)
            });
            if (a = c.sheet) a.insertRule(".iv-promo .iv-promo-contents .iv-promo-txt .iv-promo-link:after {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUBAMAAAB/pwA+AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAHlBMVEVMaXH////////////////////////////////////Z6AnKAAAACXRSTlMA+/A2IuI1mJIldm0CAAAAAWJLR0QB/wIt3gAAAEVJREFUCNdjYGCYCQUMBJlACOIzIDElIcyZkwxgojOVWWDMSQauMKYySySUOSnBdSaUOZ0lEsac2YqwYiZ+JhwgM7E5HACgzVCI/YJ59AAAAABJRU5ErkJggg==) no-repeat center;background-size:10px;width:10px;height:10px}",
                0), a.insertRule(".iv-promo .iv-promo-actions .iv-promo-close:after {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAJBAMAAAASvxsjAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAJFBMVEVMaXH///////////////////////////////////////////9tKdXLAAAAC3RSTlMAVaQDpaimqQbl5rjXUFUAAAABYktHRAH/Ai3eAAAAPUlEQVQI12MQMmAwEmDwDmaOTmAw39663YCBuXp2MQMDQ+fOBgYG5ujVwQwMptvbgeLaxczVCQwiBgxmAgBkXg1FN5iwiAAAAABJRU5ErkJggg==) no-repeat center;background-size:9px;width:9px;height:9px}",
                0), a.insertRule(".iv-promo .iv-promo-actions .iv-promo-expand:after {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAJBAMAAADnQZCTAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAJFBMVEVMaXHMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMz////eMKB4AAAAC3RSTlMAOpE7k5Uvj5kpfRaQSaQAAAABYktHRAsf18TAAAAAHklEQVQI12MQYGBQZmBwTWCo0GSo6AKRQDZQRIABADXXA/UkIpvtAAAAAElFTkSuQmCC) no-repeat center;background-size:4px 9px;width:4px;height:9px}", 0), a.insertRule(".iv-promo-website-card-cta-redesign .iv-promo-round-expand-icon:after {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAQAAAD9CzEMAAAAAmJLR0QA/4ePzL8AAAAJcEhZcwAACxMAAAsTAQCanBgAAAAHdElNRQfgCgUUEztsNfqrAAAAXklEQVRYw+3Uuw2AQAwEUUNXfBpDIvBRMhQwJJAScNrA0r4CdiQHjjAzK4NGKucPAFmCnZcmwcTphBNO9CTGH4VB+/Zm6YlYis9fhedXz38FNvFriCCl808iw8ysrBu65gCeuV/CfgAAAABJRU5ErkJggg==) no-repeat center;background-size:18px 18px;width:18px;height:18px}",
                0), a.insertRule(".iv-card-link-icon {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASBAMAAACk4JNkAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAGFBMVEVMaXG7u7u7u7u7u7u7u7u7u7u7u7v///+WKTAlAAAABnRSTlMAFdQWbGj9GiOuAAAAAWJLR0QHFmGI6wAAAEhJREFUCNdjYACBNCBgQGMxMKrBWEJJaRAJRjVlKEsoSQDIAqtSZICwgEIQFkgIZBRECMxiBqsCsVjAqsCygQwwFgMeFgQgswBg2xjLrfC4mgAAAABJRU5ErkJggg==) no-repeat center;background-size:9px;width:9px;height:9px}", 0), a.insertRule(".iv-card-playlist-video-count:after {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYBAMAAAASWSDLAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAJFBMVEVMaXH///////////////////////////////////////////9tKdXLAAAAC3RSTlMAvDeyLvxYtDK9Ogx4T1QAAAABYktHRAH/Ai3eAAAAK0lEQVQY02NgoBjshgO8HJoYwKiAMGAD92YHJM7uMCTO9gaEHs4FlPuZAQC8Fj8x/xHjxwAAAABJRU5ErkJggg==) no-repeat center;background-size:24px;width:24px;height:24px}",
                0), a.insertRule(".iv-drawer-close-button:after {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMAgMAAAArG7R0AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACVBMVEVMaXH////////OZTV/AAAAAnRSTlMAoKBFbtAAAAABYktHRAH/Ai3eAAAAKUlEQVQI12MIYGBlSGGQBMIUBjbHCQyM0xwYGDIZwBjEBomB5EBqgGoBolQGzYuy51cAAAAASUVORK5CYII=) no-repeat center;background-size:12px;width:12px;height:12px}", 0), a.insertRule(".iv-ad-info-icon {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAALCAMAAACecocUAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAVFBMVEVMaXGUlJSYmJiZmZmYmJiXl5eZmZmZmZmWlpaVlZWOjo6ZmZmSkpKXl5eYmJiYmJiZmZmZmZmZmZmZmZmYmJiJiYmXl5eZmZmYmJiWlpaZmZn///+81lbeAAAAGnRSTlMAE5DM80DliTMMEjccWIM5p1UjaTQNgB5cLlr5mgUAAAABYktHRBsCYNSkAAAAVElEQVQI102NRw7AIBADhw7ppIf/PzQLJ/ZgWSNrFlDaWKMVcs6HmGLwTqjEME6CFDrAXBYIGhNh3TJEg02wHydctvFc7sbrvnXZV8/zfs3T+7u/P7CrAso35YfPAAAAAElFTkSuQmCC) no-repeat center;background-size:11px;width:11px;height:11px}",
                0), a.insertRule(".annotation-close-button {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQBAMAAADt3eJSAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAALVBMVEVMaXEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/Pz9aWloBAQGZmZlbW1v///+X9wUzAAAACHRSTlMANprf+g6lyRmB9hUAAAABYktHRA5vvTBPAAAAWUlEQVQI12NgYBAycVZkAIKwDiBIZWBgrQAx2gMY2DrAIIFBomPWju6VHY0MGh1rbu891dHEYNGx9+yd2x3NDB4d3XfO7uhoQTDgUnDFcO1wA+FWwC2FOQMAdKg6tUSAFEAAAAAASUVORK5CYII=) no-repeat center}", 0), a.insertRule(".annotation-link-icon {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAiCAMAAAANmfvwAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAUVBMVEVMaXH////////////////////////////////////////////////////////////////////////////////////////////////////////JzkR1AAAAGnRSTlMAfXf+c3xsdGdv/GJoXPtXXflSVk5L7DBH9VeFfsQAAAABYktHRAH/Ai3eAAAAgElEQVQ4y93SSQ6AIAwFULSOOOJs739Qf9SF0VA2uNCu+psHaQJK7cVCqY+Rg92PXA++Q84KnCR03UIRJrFEKMEgZYFQhpyzQHSBWJJAdIVUENtJ3SC0mu3EdOh7zXZiBrRdzQLJ0Y1GfOlpVstD3HaZktX9X/gvRCxvxL6FR7IBS1RTM5xIpLoAAAAASUVORK5CYII=) no-repeat center}",
                0)
        },
        Egb = function(a) {
            a = a.createElement({
                G: "div",
                Ma: ["annotation", "annotation-type-custom"]
            });
            g.no(a, !1);
            return a
        },
        Fgb = function(a, b) {
            b = !b.isCued() && !g.BP(b, 1024);
            g.$Q(a.u, b);
            g.$Q(a.B, b)
        },
        Ggb = function(a, b, c) {
            a.K = !0;
            a.D = g.bA(b, c)
        },
        Hgb = function(a, b) {
            for (var c = {}, d = g.u(b.attributes), e = d.next(); !e.done; e = d.next()) e = e.value, c[e.name] = e.nodeValue;
            for (d = 0; d < b.childNodes.length; d++)
                if (e = b.childNodes[d], g.Za(e) && 1 == e.nodeType) {
                    if (c[e.tagName]) var f = c[e.tagName];
                    else if ("data" === e.tagName) {
                        0 < e.childNodes.length && (f = e.childNodes[0].nodeValue, c[e.tagName] = "string" === typeof f ? f.trim() : f);
                        continue
                    } else f = [], c[e.tagName] = f;
                    e && "TEXT" === e.tagName ? 1 === e.childNodes.length && 3 === e.childNodes[0].nodeType ? f.push(e.childNodes[0].nodeValue) : f.push("") : e && f.push(Hgb(a, e))
                }
            return c
        },
        Lgb = function(a) {
            var b = a.player.getVideoData();
            if (b.Va) {
                var c = a.player.W().Fa.get(b.videoId);
                if (c) {
                    var d = {
                        format: "XML",
                        urlParams: {},
                        method: "POST",
                        withCredentials: !0,
                        onFinish: function(e, f, h) {
                            e = b.videoId;
                            a.loaded && a.loadNumber === a.loadNumber && a.player.getVideoData().videoId === e && (h = g.Vz(h) && h.responseXML ? h.responseXML : null) && Igb(a, h)
                        }
                    };
                    g.GB() && (d.onFinish = Jgb(a, d.onFinish));
                    d.postParams = {
                        ic_only: "1"
                    };
                    Kgb(d, c);
                    a.K = !0;
                    g.bA(b.Va, d)
                }
            }
        },
        Kgb = function(a, b) {
            a.method = "POST";
            a.postParams = a.postParams || {};
            b.OB && (a.postParams.ic_coll = b.OB);
            b.LL && (a.postParams.ic_xml = b.LL);
            b.uJ && (a.postParams.ic_track = b.uJ)
        },
        Mgb = function(a) {
            var b = new g.X({
                G: "div"
            });
            g.no(b.element, !1);
            var c = new agb(a.player, b.element, o5(a));
            g.H(c, b);
            b.Ja(a.u.element);
            c.LE();
            return c
        },
        Ogb = function(a, b) {
            var c, d;
            if (b = null == (c = b.zd) ? void 0 : null == (d = c.cards) ? void 0 : d.cardCollectionRenderer) a.ma = !0, Ngb(a, b), b.headerText && a.wh && (c = g.PG(b.headerText), a.wh.setAttribute("title", c))
        },
        o5 = function(a) {
            if (!a.V) {
                var b = new ufb(a);
                g.H(a, b);
                var c = new g.Sl(a);
                g.H(a, c);
                a.V = new ugb(b, c, a.player.W(), a.player.getVideoData(), a.logger, a.player, a.Pi)
            }
            return a.V
        },
        Igb = function(a, b) {
            var c = !1,
                d = b.getElementsByTagName("annotations");
            if (d && !(1 > d.length) && (d = d[0].getAttribute("itct"))) {
                var e = g.mH();
                if (e) {
                    var f = g.lH();
                    f && g.Hz(g.UBa)(void 0, e, f, [g.jH(d)])
                }
            }
            b = b.getElementsByTagName("annotation");
            for (d = 0; d < b.length; d++) {
                f = Hgb(a, b[d]);
                e = null;
                try {
                    if (f) {
                        var h = f.id,
                            l = /.+/;
                        var m = "string" === typeof h && null != l && null != h && h.match(l) ? h : "";
                        var n = W4(f.type, Pgb),
                            p = W4(f.style, Qgb),
                            q = Kfb(f.data),
                            r = 0 !== q.length ? JSON.parse(q) : {};
                        var v = f.action;
                        f = Qfb;
                        if (null == v) var y = null;
                        else if (g.Wa(v)) {
                            l = [];
                            for (var A = g.u(v), F = A.next(); !F.done; F = A.next()) {
                                var M = f(F.value);
                                M && l.push(M)
                            }
                            y = l
                        } else {
                            var J = f(v);
                            y = J ? [J] : []
                        }
                        e = m && n ? new Rfb(m, n, p, y, r) : null
                    } else e = null
                } catch (oa) {}
                if (e)
                    if ("branding" === e.type || "promotion" === e.type) {
                        f = a;
                        l = e;
                        var G = Egb(f),
                            U = null;
                        switch (l.type) {
                            case "branding":
                                if (f.player.W().Qd) break;
                                f.u.element.appendChild(G);
                                U = new m5(G, o5(f), l);
                                break;
                            case "promotion":
                                g.XS(f.player, G, 4), U = new vgb(G, o5(f), l)
                        }
                        U && U.LE();
                        if (f = U) g.H(a, f), a.J[e.id] = f
                    } else if ("card" === e.type || "drawer" === e.type) {
                    a.j || (a.j = Mgb(a), g.H(a, a.j));
                    if ("card" === e.type) {
                        c = a.j;
                        var Y = e && e.data && e.data.card_type;
                        f = e.data;
                        if (Y) switch (l = f.tracking || {}, l = {
                            cW: l.impression,
                            click: l.click,
                            close: l.close,
                            CZ: l.teaser_impression,
                            rJ: l.teaser_click
                        }, G = f.tracking_params || {}, U = null, Y) {
                            case "collaborator":
                                e = {
                                    id: e.id,
                                    timestamp: f.timestamp || 0,
                                    type: f.card_type,
                                    teaserText: f.teaser_text,
                                    teaserDurationMs: f.teaser_duration_ms,
                                    startMs: f.start_ms,
                                    autoOpen: f.auto_open || !1,
                                    sessionData: f.session_data || {},
                                    sponsored: f.sponsored || !1,
                                    dj: l,
                                    So: G.card ? g.jH(G.card) : null,
                                    Al: G.teaser ? g.jH(G.teaser) : null,
                                    zg: G.icon ? g.jH(G.icon) : null,
                                    channelId: f.channel_id,
                                    customMessage: f.custom_message ? f.custom_message : null,
                                    rY: f.image_url,
                                    title: f.title,
                                    metaInfo: f.meta_info,
                                    url: Y4({
                                        pause_on_navigation: f.pause_on_navigation,
                                        target: f.target || "new",
                                        value: f.url
                                    }),
                                    onClickCommand: null
                                };
                                g5(c, e);
                                break;
                            case "playlist":
                                e = {
                                    id: e.id,
                                    timestamp: f.timestamp || 0,
                                    type: f.card_type,
                                    teaserText: f.teaser_text,
                                    teaserDurationMs: f.teaser_duration_ms,
                                    startMs: f.start_ms,
                                    autoOpen: f.auto_open || !1,
                                    sessionData: f.session_data || {},
                                    sponsored: f.sponsored || !1,
                                    dj: l,
                                    So: G.card ? g.jH(G.card) : null,
                                    Al: G.teaser ?
                                        g.jH(G.teaser) : null,
                                    zg: G.icon ? g.jH(G.icon) : null,
                                    WE: f.image_url,
                                    playlistVideoCount: f.playlist_video_count,
                                    customMessage: f.custom_message ? f.custom_message : null,
                                    title: f.title,
                                    metaInfo: f.meta_info,
                                    url: Y4({
                                        pause_on_navigation: f.pause_on_navigation,
                                        target: f.target || "new",
                                        value: f.url
                                    }),
                                    onClickCommand: null
                                };
                                g5(c, e);
                                break;
                            case "productListing":
                                f.signin_url && (U = Y4({
                                    target: "current",
                                    value: f.signin_url
                                }));
                                Y = [];
                                for (var ka = f.offers || [], ua = 0; ua < ka.length; ua++) Y.push(new Xfb(g.Ee(ka[ua].merchant), g.Ee(ka[ua].price)));
                                e = {
                                    id: e.id,
                                    timestamp: f.timestamp || 0,
                                    type: f.card_type,
                                    teaserText: f.teaser_text,
                                    teaserDurationMs: f.teaser_duration_ms,
                                    startMs: f.start_ms,
                                    autoOpen: f.auto_open || !1,
                                    sessionData: f.session_data || {},
                                    sponsored: f.sponsored || !1,
                                    dj: l,
                                    So: G.card ? g.jH(G.card) : null,
                                    Al: G.teaser ? g.jH(G.teaser) : null,
                                    zg: G.icon ? g.jH(G.icon) : null,
                                    imageUrl: f.image_url,
                                    displayDomain: f.display_domain ? f.display_domain : null,
                                    showLinkIcon: !!f.show_link_icon,
                                    MB: f.button_icon_url ? f.button_icon_url : null,
                                    title: f.title,
                                    customMessage: f.custom_message ?
                                        f.custom_message : null,
                                    url: Y4({
                                        pause_on_navigation: f.pause_on_navigation,
                                        target: f.target || "new",
                                        value: f.url
                                    }),
                                    Qcb: U,
                                    Pcb: f.signin_title ? f.signin_title : void 0,
                                    Ocb: f.signin_message ? f.signin_message : void 0,
                                    offers: Y,
                                    onClickCommand: null
                                };
                                g5(c, e);
                                break;
                            case "simple":
                                e = {
                                    id: e.id,
                                    timestamp: f.timestamp || 0,
                                    type: f.card_type,
                                    teaserText: f.teaser_text,
                                    teaserDurationMs: f.teaser_duration_ms,
                                    startMs: f.start_ms,
                                    autoOpen: f.auto_open || !1,
                                    sessionData: f.session_data || {},
                                    sponsored: f.sponsored || !1,
                                    dj: l,
                                    So: G.card ? g.jH(G.card) : null,
                                    Al: G.teaser ? g.jH(G.teaser) : null,
                                    zg: G.icon ? g.jH(G.icon) : null,
                                    imageUrl: f.image_url,
                                    displayDomain: f.display_domain ? f.display_domain : null,
                                    showLinkIcon: !!f.show_link_icon,
                                    MB: f.button_icon_url ? f.button_icon_url : null,
                                    title: f.title,
                                    customMessage: f.custom_message ? f.custom_message : null,
                                    url: Y4({
                                        pause_on_navigation: f.pause_on_navigation,
                                        target: f.target || "new",
                                        value: f.url
                                    }),
                                    onClickCommand: null
                                };
                                g5(c, e);
                                break;
                            case "video":
                                e = {
                                    id: e.id,
                                    timestamp: f.timestamp || 0,
                                    type: f.card_type,
                                    teaserText: f.teaser_text,
                                    teaserDurationMs: f.teaser_duration_ms,
                                    startMs: f.start_ms,
                                    autoOpen: f.auto_open || !1,
                                    sessionData: f.session_data || {},
                                    sponsored: f.sponsored || !1,
                                    dj: l,
                                    So: G.card ? g.jH(G.card) : null,
                                    Al: G.teaser ? g.jH(G.teaser) : null,
                                    zg: G.icon ? g.jH(G.icon) : null,
                                    WE: f.image_url,
                                    videoDuration: f.video_duration || null,
                                    customMessage: f.custom_message ? f.custom_message : null,
                                    title: f.title,
                                    metaInfo: f.meta_info,
                                    isLiveNow: !!f.is_live_now,
                                    url: Y4({
                                        pause_on_navigation: f.pause_on_navigation,
                                        target: f.target || "new",
                                        value: f.url
                                    }),
                                    onClickCommand: null
                                }, g5(c, e)
                        }
                    } else bgb(a.j, e);
                    c = !0
                }
            }
            c &&
                (H4(a.player), a.fI())
        },
        Ngb = function(a, b) {
            var c = !1;
            a.j || (a.j = Mgb(a), g.H(a, a.j));
            for (var d = g.u(b.cards || []), e = d.next(); !e.done; e = d.next()) e = e.value, e.cardRenderer && (cgb(a.j, e.cardRenderer), c = !0);
            if (c) {
                var f;
                null != (f = a.player.getVideoData()) && g.MO(f) || (c = a.j, d = b.headerText ? g.PG(b.headerText) : "", g.tf(c.Yb, d), c.V && c.V.setAttribute("title", d), c.context.videoData.eventId && (c.eventId = c.context.videoData.eventId), c.Fa = b.trackingParams ? g.jH(b.trackingParams) : null, c.K = b.closeButton.infoCardIconRenderer.trackingParams ? g.jH(b.closeButton.infoCardIconRenderer.trackingParams) :
                    null, c.zg = b.icon.infoCardIconRenderer.trackingParams ? g.jH(b.icon.infoCardIconRenderer.trackingParams) : null, a.fI());
                H4(a.player)
            }
        },
        Rgb = function(a, b, c, d, e) {
            if (!a.player.W().Qd) {
                var f = [];
                b.navigationEndpoint && g.S(b.navigationEndpoint, g.z3) && g.S(b.navigationEndpoint, g.z3).browseId && f.push(new Nfb("openUrl", "click", new Lfb("/channel/" + g.S(b.navigationEndpoint, g.z3).browseId, "new", !0, !0)));
                var h = b.watermark.thumbnails[0];
                d = {
                    channel_name: b.channelName,
                    end_ms: b.endTimeMs,
                    image_height: h.height,
                    image_type: 1,
                    image_url: h.url,
                    image_width: h.width,
                    is_mobile: !1,
                    session_data: {
                        annotation_id: c,
                        ei: e,
                        feature: "iv",
                        itct: b.trackingParams,
                        src_vid: d
                    },
                    start_ms: b.startTimeMs
                };
                if (b.subscribeButton && g.S(b.subscribeButton,
                        g.FO)) {
                    d.channel_id = g.S(b.subscribeButton, g.FO).channelId;
                    var l;
                    b = g.S(b.subscribeButton, g.FO);
                    h = e = null;
                    b.subscribed ? (b.subscriberCountWithUnsubscribeText && (e = g.PG(b.subscriberCountWithUnsubscribeText)), b.subscriberCountText && (h = g.PG(b.subscriberCountText))) : (b.subscriberCountText && (e = g.PG(b.subscriberCountText)), b.subscriberCountWithSubscribeText && (h = g.PG(b.subscriberCountWithSubscribeText)));
                    var m, n = (null == (m = g.S(null == (l = b.signInEndpoint) ? void 0 : l.commandMetadata, g.A3)) ? void 0 : m.url) || "";
                    l = {
                        subscribeText: g.PG(b.unsubscribedButtonText),
                        subscribeCount: e || "",
                        unsubscribeText: g.PG(b.subscribedButtonText),
                        unsubscribeCount: h || "",
                        enabled: b.enabled || !1,
                        classic: !1,
                        subscribed: b.subscribed || !1,
                        feature: "iv",
                        signInUrl: n
                    };
                    d.standalone_subscribe_button_data = l
                }
                f = new Rfb(c, "branding", "branding", f, d);
                l = Egb(a);
                a.u.element.appendChild(l);
                f = new m5(l, o5(a), f);
                f.LE();
                g.H(f, f);
                a.J[c] = f
            }
        },
        Jgb = function(a, b) {
            return function() {
                var c = g.Ha.apply(0, arguments);
                a.isDisposed() || a.oa.push(g.vq.Ki(function() {
                    b.apply(null, g.pa(c))
                }))
            }
        },
        Sgb = function(a) {
            return "annotation-editor" === a || "live-dashboard" === a
        };
    g.PS.prototype.pA = g.da(19, function(a, b) {
        var c = g.jU(this.Fb());
        c && c.pA(a, b)
    });
    var J4 = {},
        K4 = null;
    g.ib(M4, g.Xq);
    g.k = M4.prototype;
    g.k.getDuration = function() {
        return this.duration
    };
    g.k.play = function(a) {
        if (a || 0 == this.j) this.progress = 0, this.coords = this.u;
        else if (this.rd()) return !1;
        L4(this);
        this.startTime = a = g.eb(); - 1 == this.j && (this.startTime -= this.duration * this.progress);
        this.endTime = this.startTime + this.duration;
        this.C = this.startTime;
        this.progress || this.VH();
        this.Xl("play"); - 1 == this.j && this.Xl("resume");
        this.j = 1;
        var b = g.ab(this);
        b in J4 || (J4[b] = this);
        nfb();
        ofb(this, a);
        return !0
    };
    g.k.stop = function(a) {
        L4(this);
        this.j = 0;
        a && (this.progress = 1);
        pfb(this, this.progress);
        this.Xl("stop");
        this.rr()
    };
    g.k.pause = function() {
        this.rd() && (L4(this), this.j = -1, this.Xl("pause"))
    };
    g.k.xa = function() {
        0 == this.j || this.stop(!1);
        this.Xl("destroy");
        M4.Vf.xa.call(this)
    };
    g.k.destroy = function() {
        this.dispose()
    };
    g.k.cK = function() {
        this.Xl("animate")
    };
    g.k.Xl = function(a) {
        this.dispatchEvent(new qfb(a, this))
    };
    g.ib(qfb, g.zb);
    g.ib(N4, M4);
    N4.prototype.B = function() {};
    N4.prototype.cK = function() {
        this.B();
        N4.Vf.cK.call(this)
    };
    N4.prototype.rr = function() {
        this.B();
        N4.Vf.rr.call(this)
    };
    N4.prototype.VH = function() {
        this.B();
        N4.Vf.VH.call(this)
    };
    g.ib(rfb, N4);
    rfb.prototype.B = function() {
        this.element.style.left = Math.round(this.coords[0]) + "px";
        this.element.style.top = Math.round(this.coords[1]) + "px"
    };
    g.w(ufb, g.D);
    g.k = ufb.prototype;
    g.k.Ta = function(a, b, c, d) {
        c = (0, g.bb)(c, d || this.u);
        a = g.$A(a, b, c);
        this.j.push(a);
        return a
    };
    g.k.yH = function(a, b, c, d) {
        c = (0, g.bb)(c, d || this.u);
        a = g.xna(a, b, c);
        this.j.push(a);
        return a
    };
    g.k.Mc = function(a) {
        g.aB(a);
        g.Jb(this.j, a)
    };
    g.k.Uf = function() {
        g.aB(this.j);
        this.j.length = 0
    };
    g.k.xa = function() {
        this.Uf();
        g.D.prototype.xa.call(this)
    };
    g.w(xfb, g.VT);
    g.k = xfb.prototype;
    g.k.load = function() {
        g.VT.prototype.load.call(this);
        if (!Q4(this)) {
            var a = g.Nza(this.player.getVideoData());
            a ? (a = wfb(a, yfb(this)), R4(this, a, !1)) : zfb(this)
        }
    };
    g.k.unload = function() {
        R4(this, null);
        this.B && (this.B.abort(), this.B = null);
        g.VT.prototype.unload.call(this)
    };
    g.k.Ih = function(a, b) {
        return Q4(this) ? "loadCustomEndscreenRenderer" === a ? (a = wfb(b, "new"), R4(this, a), !0) : null : null
    };
    g.k.getOptions = function() {
        return Q4(this) ? ["loadCustomEndscreenRenderer"] : []
    };
    g.k.Kb = function() {
        if (this.endscreen && this.endscreen.elements) {
            var a = this.player.getVideoContentRect();
            if (a && 0 !== a.width && 0 !== a.height) {
                var b = this.player.getPlayerSize();
                if (b && 0 !== b.width && 0 !== b.height) {
                    var c = a.width / a.height;
                    var d = 0;
                    for (var e = -1, f = 0; f < Tgb.length; f++) {
                        var h = Math.abs(b.width - Tgb[f]);
                        if (-1 === e || d >= h) e = f, d = h
                    }
                    d = Ugb[e];
                    this.u && g.Nn(this.u.element, "outline-width", Math.max(b.width, b.height) + "px");
                    for (b = 0; b < this.endscreen.elements.length; ++b)
                        if (f = this.endscreen.elements[b].id, e = this.j[f],
                            h = this.D[f], e && h) {
                            var l = h.width * c / h.aspectRatio,
                                m = Math.round(h.width * a.width);
                            f = Math.round(l * a.height);
                            var n = a.left + Math.round(h.left * a.width),
                                p = a.top + Math.round(h.top * a.height);
                            g.lo(e.element, m, f);
                            g.Tn(e.element, n, p);
                            g.Oq(e.element, Vgb);
                            256 < m || 256 < f ? g.Lq(e.element, "ytp-ce-large-round") : 96 < m || 96 < f ? g.Lq(e.element, "ytp-ce-medium-round") : g.Lq(e.element, "ytp-ce-small-round");
                            g.Oq(e.element, Wgb);
                            m = h.left + h.width / 2;
                            h = h.top + l / 2;
                            g.Lq(e.element, .5 >= m && .5 >= h ? "ytp-ce-top-left-quad" : .5 < m && .5 >= h ? "ytp-ce-top-right-quad" :
                                .5 >= m && .5 < h ? "ytp-ce-bottom-left-quad" : "ytp-ce-bottom-right-quad");
                            g.Oq(e.element, Ugb);
                            g.Lq(e.element, d);
                            (e = g.Me(document, "div", "ytp-ce-expanding-overlay-body", e.element)[0]) && g.Nn(e, "height", f + "px")
                        }
                }
            }
        }
    };
    g.k.onCueRangeEnter = function(a) {
        if (this.endscreen)
            if ("ytp-ce-in-endscreen" === a.getId()) V4(this, this.endscreen.impressionUrls), (a = g.mH()) && this.endscreen.visualElement && g.nQ(a, this.endscreen.visualElement);
            else {
                a = a.getId().substring(15);
                var b = this.j[a],
                    c = this.D[a];
                g.Lq(b.element, "ytp-ce-element-show");
                b.element.removeAttribute("aria-hidden");
                b = this.player.getRootNode();
                g.Lq(b, "ytp-ce-shown");
                V4(this, c.impressionUrls);
                (b = g.mH()) && g.nQ(b, c.visualElement);
                this.player.W().J && this.player.Qa("endscreenelementshown",
                    a)
            }
    };
    g.k.onCueRangeExit = function(a) {
        if ("ytp-ce-in-endscreen" !== a.getId()) {
            a = a.getId().substring(15);
            var b = this.j[a];
            g.Nq(b.element, "ytp-ce-element-show");
            b.element.setAttribute("aria-hidden", "true");
            b = this.player.getRootNode();
            g.Nq(b, "ytp-ce-shown");
            this.player.W().J && this.player.Qa("endscreenelementhidden", a)
        }
    };
    g.k.j9 = function(a) {
        var b = this;
        a.target === window && (new g.Dq(function() {
            for (var c = g.u(Object.values(b.j)), d = c.next(); !d.done; d = c.next()) g.Oq(d.value.element, ["ytp-ce-force-expand", "ytp-ce-element-hover", "ytp-ce-element-shadow-show"])
        }, 0)).start()
    };
    var Tgb = [346, 426, 470, 506, 570, 640, 853, 1280, 1920],
        Ugb = "ytp-ce-size-346 ytp-ce-size-426 ytp-ce-size-470 ytp-ce-size-506 ytp-ce-size-570 ytp-ce-size-640 ytp-ce-size-853 ytp-ce-size-1280 ytp-ce-size-1920".split(" "),
        Wgb = ["ytp-ce-top-left-quad", "ytp-ce-top-right-quad", "ytp-ce-bottom-left-quad", "ytp-ce-bottom-right-quad"],
        Vgb = ["ytp-ce-small-round", "ytp-ce-medium-round", "ytp-ce-large-round"];
    var Mfb = {
        cpa: "current",
        jOa: "new"
    };
    var Ofb = {
            CLOSE: "close",
            JRa: "openUrl",
            SUBSCRIBE: "subscribe"
        },
        Pfb = {
            Hna: "click",
            CLOSE: "close",
            Uza: "hidden",
            yWa: "rollOut",
            zWa: "rollOver",
            WXa: "shown"
        };
    Rfb.prototype.kf = function() {
        var a = Sfb(this, function(b) {
            return "openUrl" === b.type && null != b.url
        });
        return a ? a.url : null
    };
    var Qgb = {
            Iia: "anchored",
            F_: "branding",
            CHANNEL: "channel",
            Soa: "cta",
            Xza: "highlightText",
            VDa: "label",
            PLAYLIST: "playlist",
            dUa: "popup",
            R_a: "speech",
            SUBSCRIBE: "subscribe",
            d3a: "title",
            VIDEO: "video",
            h9a: "website"
        },
        Pgb = {
            F_: "branding",
            Dla: "card",
            Zqa: "drawer",
            Wza: "highlight",
            TJa: "marker",
            tVa: "promotion",
            TEXT: "text",
            F$a: "widget"
        };
    g.w(b5, g.D);
    g.k = b5.prototype;
    g.k.addCueRange = function(a, b, c, d, e) {
        a = new g.HG(a, b, {
            id: c,
            namespace: "annotations_module"
        });
        d && this.fb.set(a, d);
        e && this.kb.set(a, e);
        this.context.I.hf([a])
    };
    g.k.LE = function() {
        this.context.u.subscribe("resize", this.TF, this)
    };
    g.k.Bb = function() {
        return this.element
    };
    g.k.dK = function(a, b, c, d, e, f) {
        if (this.wb) return !1;
        f && (f.stopPropagation(), f.preventDefault());
        this.navigate(a, c, d, e);
        return !1
    };
    g.k.show = function() {};
    g.k.hide = function() {};
    g.k.destroy = function() {
        g.qf(this.Bb())
    };
    g.k.TF = function() {};
    g.k.navigate = function(a, b, c, d) {
        var e = this,
            f = X4(a);
        if (f) {
            var h = Zfb(f, a.target),
                l = function() {
                    a.j && e.context.I.pauseVideo();
                    var m = e.context.videoData.Ed || !1,
                        n = g.Nz(f || "");
                    m && n && (n.v || n.list) ? e.context.I.uo(n.v, b, n.list, !1) : g.vP(f || "", "current" === h ? "_top" : void 0, b)
                };
            "new" === h && (l(), l = null);
            n5(this.context.logger, c, l, d);
            Yfb(f) || (c = g.mH(), d = b.itct, c && d && g.qQ(c, g.jH(d)))
        }
    };
    g.k.xa = function() {
        this.fb.clear();
        this.kb.clear();
        g.D.prototype.xa.call(this)
    };
    g.k.createElement = function(a) {
        a = new g.X(a);
        g.H(this, a);
        return a.element
    };
    g.w(agb, b5);
    g.k = agb.prototype;
    g.k.vt = function() {
        this.qa && g5(this, this.qa)
    };
    g.k.isAvailable = function() {
        var a;
        if (a = !!this.cards.length)(a = this.I.getRootNode()) ? (a = g.mo(a), a = 173 < a.width && 173 < a.height) : a = !1;
        return a
    };
    g.k.TF = function() {
        var a = this.isAvailable();
        g.no(this.Bb(), a);
        g.Pq(this.context.I.getRootNode(), g.wX.IV_DRAWER_ENABLED, a);
        H4(this.I)
    };
    g.k.destroy = function() {
        this.I.pA(!1);
        try {
            this.I.getRootNode().removeChild(this.C)
        } catch (a) {}
        g.ID(this.oa);
        g.hB(this.Va);
        this.Ya && this.Ya.dispose();
        this.D && this.D.dispose();
        b5.prototype.destroy.call(this)
    };
    g.k.N3 = function() {
        if (this.B) {
            n5(this.context.logger, k5(this).dj.close);
            var a = g.mH();
            a && this.K && g.qQ(a, this.K);
            f5(this)
        }
    };
    g.k.g4 = function() {
        g.Pq(this.C, "iv-drawer-scrolled", 0 < this.u.scrollTop)
    };
    g.k.V5 = function() {
        var a = g.mH(),
            b = k5(this);
        b = b ? b.zg : this.zg;
        a && b && g.oQ(a, [b])
    };
    g.k.U5 = function() {
        var a = g.mH(),
            b = k5(this);
        b = b ? b.zg : this.zg;
        a && b && g.pQ(a, [b])
    };
    g.k.o0 = function() {
        var a = k5(this);
        n5(this.context.logger, a.dj.CZ);
        var b = g.mH();
        b && a && g.oQ(b, [a.Al, a.zg])
    };
    g.k.W5 = function() {
        var a = g.mH(),
            b = k5(this);
        a && b && g.pQ(a, [b.Al])
    };
    g.k.n0 = function(a) {
        var b = k5(this),
            c = g.mH();
        this.j ? a ? (a = this.context.logger, n5(a, b.dj.rJ), a.I.sendVideoStatsEngageEvent(4, void 0), c && b.Al && g.qQ(c, b.Al)) : (a = this.context.logger, n5(a, b.dj.rJ), a.I.sendVideoStatsEngageEvent(4, void 0), c && b.zg && g.qQ(c, b.zg)) : (a = this.context.logger, n5(a, b.dj.rJ), a.I.sendVideoStatsEngageEvent(4, void 0), c && this.zg && g.qQ(c, this.zg))
    };
    g.w(l5, b5);
    l5.prototype.LE = function() {
        b5.prototype.LE.call(this);
        pgb(this)
    };
    l5.prototype.show = function() {
        b5.prototype.show.call(this);
        var a = g.mH(),
            b = this.annotation.data;
        a && b && (b = b.session_data) && g.oQ(a, [g.jH(b.itct)])
    };
    l5.prototype.hide = function() {
        b5.prototype.hide.call(this);
        var a = g.mH(),
            b = this.annotation.data;
        a && b && (b = b.session_data) && g.pQ(a, [g.jH(b.itct)])
    };
    g.w(m5, l5);
    m5.prototype.show = function() {
        if (!this.isActive) {
            l5.prototype.show.call(this);
            if (!this.K) {
                g.Lq(this.Bb(), "iv-branding");
                var a = this.annotation.data;
                this.u = this.createElement({
                    G: "img",
                    Ma: ["branding-img", "iv-click-target"],
                    Y: {
                        "aria-label": "Channel watermark",
                        src: a.image_url,
                        width: a.image_width,
                        height: a.image_height
                    }
                });
                g.no(this.u, !1);
                var b = this.createElement({
                    G: "button",
                    Ma: ["branding-img-container", "ytp-button"]
                });
                b.appendChild(this.u);
                this.Bb().appendChild(b);
                var c = this.annotation.kf();
                c && c5(this, b,
                    c, this.annotation.id, a.session_data);
                tgb(this, a);
                this.K = !0
            }
            g.no(this.Bb(), !0);
            this.isActive = !0;
            this.u && (qgb(this, this.u), g.Lq(this.context.I.getRootNode(), "ytp-branding-shown"))
        }
    };
    m5.prototype.hide = function() {
        this.isActive && (l5.prototype.hide.call(this), g.no(this.Bb(), !1), this.isActive = !1, g.Nq(this.context.I.getRootNode(), "ytp-branding-shown"))
    };
    m5.prototype.destroy = function() {
        this.j && (this.j.dispose(), this.j = null);
        l5.prototype.destroy.call(this)
    };
    g.w(vgb, l5);
    g.k = vgb.prototype;
    g.k.show = function() {
        this.isActive || (l5.prototype.show.call(this), this.ma || (xgb(this), this.ma = !0), g.no(this.Bb(), !0), g.cg(function() {
            g.Nq(this.Bb(), "iv-promo-inactive")
        }, 100, this), this.Bb().removeAttribute("aria-hidden"), this.isActive = !0, Bgb(this), ygb(this), zgb(this, this.J))
    };
    g.k.hide = function() {
        this.isActive && (g.Lq(this.Bb(), "iv-promo-inactive"), this.isActive = !1, this.Bb().setAttribute("aria-hidden", "true"))
    };
    g.k.dK = function(a, b, c, d, e, f) {
        return this.isCollapsed ? !1 : l5.prototype.dK.call(this, a, b, c, d, e, f)
    };
    g.k.c5 = function(a) {
        this.V = !0;
        wgb(this, 500, a)
    };
    g.k.b5 = function() {
        this.V = !1;
        Agb(this)
    };
    g.k.W4 = function(a) {
        a.stopPropagation();
        this.hide()
    };
    g.k.X4 = function(a) {
        a.stopPropagation();
        Bgb(this);
        this.isCollapsed = !0;
        g.Lq(this.Bb(), "iv-promo-collapsed-no-delay");
        this.D.start()
    };
    g.k.destroy = function() {
        this.D.dispose();
        l5.prototype.destroy.call(this)
    };
    g.w(Dgb, g.VT);
    g.k = Dgb.prototype;
    g.k.Ih = function(a, b) {
        if (!Sgb(this.player.W().playerStyle)) return null;
        switch (a) {
            case "loadCustomAnnotationsXml":
                return (a = g.x$a(b)) && Igb(this, a), !0;
            case "removeCustomAnnotationById":
                return b && this.j && (egb(this.j, b), H4(this.player)), !0
        }
        return null
    };
    g.k.getOptions = function() {
        return Sgb(this.player.W().playerStyle) ? ["loadCustomAnnotationsXml", "removeCustomAnnotationById"] : []
    };
    g.k.Nw = function() {
        var a = this.player.W(),
            b = this.player.getVideoData(),
            c = a.annotationsLoadPolicy || b.annotationsLoadPolicy;
        return b.Ed && a.oa || g.JS(this.player.app) ? !1 : 1 === c && !b.mT || a.Fa.get(b.videoId) || g.NO(b) || g.Oza(b) ? !0 : !1
    };
    g.k.fI = function() {
        if (this.B) {
            var a = this.player.qb().getVideoContentRect(!0);
            g.lo(this.B.element, a.width, a.height);
            g.Tn(this.B.element, a.left, a.top)
        }
        if (this.j) {
            var b = this.player.Uk();
            a = this.j;
            b = b.width;
            g.Pq(a.C, "iv-drawer-small", 426 >= b);
            g.Pq(a.C, "iv-drawer-big", 1280 <= b)
        }
    };
    g.k.q0 = function(a) {
        Fgb(this, a.state);
        g.BP(a.state, 2) && (this.Lk() && this.Ro() && 2 !== this.player.getPresentingPlayerType() && this.qA(!1), this.pA(!1))
    };
    g.k.load = function() {
        function a(h) {
            var l = b.loadNumber;
            b.D = null;
            b.loaded && b.loadNumber === l && b.player.getVideoData().videoId === d && (h = g.Vz(h) && h.responseXML ? h.responseXML : null) && (Igb(b, h), g.Lq(b.player.getRootNode(), "iv-module-loaded"))
        }
        var b = this;
        g.VT.prototype.load.call(this);
        Fgb(this, this.player.Nb());
        this.loadNumber++;
        var c = this.player.getVideoData(),
            d = c.videoId;
        g.GB() && (a = Jgb(this, a));
        var e = {
            format: "XML",
            onFinish: a,
            onError: function() {
                b.D = null
            },
            urlParams: {}
        };
        c.isPharma && (e.urlParams.pharma = "1");
        e.method = "POST";
        e.withCredentials = !0;
        var f = this.player.W().Fa.get(d);
        f && Kgb(e, f);
        f = f && (f.LL || f.OB);
        if (!c.WA || f) c.Va ? Ggb(this, c.Va, e) : (this.Ww = function() {
            if (!b.K) b.onVideoDataChange(e);
            var h = b.player.getVideoData();
            (null == h ? 0 : g.MO(h)) && !b.ma && Ogb(b, h)
        }, this.player.addEventListener("videodatachange", this.Ww));
        g.XS(this.player, this.B.element, 4);
        this.fI();
        (f = g.NO(c)) && Ngb(this, f);
        (f = g.Oza(c)) && f.featuredChannel && Rgb(this, f.featuredChannel, f.annotationId || "branding", c.videoId || null, c.eventId || null);
        this.wh = g.Xe("ytp-cards-button", this.player.getRootNode());
        g.MO(c) && Ogb(this, c)
    };
    g.k.onVideoDataChange = function(a) {
        var b = this.player.getVideoData();
        b.Va && Ggb(this, b.Va, a)
    };
    g.k.unload = function() {
        this.player.Te("annotations_module");
        for (var a = g.u(Object.keys(this.J)), b = a.next(); !b.done; b = a.next()) this.J[b.value].destroy();
        this.V = null;
        this.j && (this.j.destroy(), this.j = null, H4(this.player));
        this.K = !1;
        this.D && (this.D.abort(), this.D = null);
        this.ma = !1;
        this.J = {};
        this.u.hide();
        g.VT.prototype.unload.call(this);
        this.B.detach();
        this.Ww && (this.player.removeEventListener("videodatachange", this.Ww), this.Ww = null)
    };
    g.k.aY = function(a) {
        a === this.player.getVideoData().videoId && (this.loaded ? Lgb(this) : this.load())
    };
    g.k.Lk = function() {
        var a;
        return (null == (a = this.j) ? void 0 : a.isAvailable()) || this.ma
    };
    g.k.Ro = function() {
        return !!this.j && this.j.B
    };
    g.k.qA = function(a, b, c) {
        b = void 0 === b ? !1 : b;
        this.Lk();
        this.j && (a ? c ? e5(this.j, c, b) : e5(this.j, "YOUTUBE_DRAWER_AUTO_OPEN", b) : f5(this.j))
    };
    g.k.pA = function(a, b) {
        this.player.ra(a ? "cardsteasershow" : "cardsteaserhide", b)
    };
    g.k.xa = function() {
        this.player.W().Fa.unsubscribe("vast_info_card_add", this.aY, this);
        g.Nq(this.player.getRootNode(), g.wX.IV_DRAWER_OPEN);
        for (var a = this.oa, b = g.vq, c = 0, d = a.length; c < d; c++) b.Vj(a[c]);
        this.oa.length = 0;
        g.VT.prototype.xa.call(this)
    };
    g.k.createElement = function(a) {
        a = new g.X(a);
        g.H(this, a);
        return a.element
    };
    g.UT("annotations_module", Dgb);
    g.UT("creatorendscreen", xfb);
})(_yt_player);